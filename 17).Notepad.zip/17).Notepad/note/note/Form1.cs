﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace note
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void aToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //openFileDialog1.Title="Jsquare";
            //openFileDialog1.Filter = "Textfiles(*txt)/*.txt/Doc files(*.docx)|*.docx|All files(*.*)|*.*";
            //openFileDialog1.ShowDialog();
            //TextReader tr;
            //tr = File.OpenText(openFileDialog1.FileName);
            OpenFileDialog ot = new OpenFileDialog();
            if (ot.ShowDialog ()== DialogResult.OK)
            {
                File.OpenText(ot.FileName);
                     
              }
          


           


        }
         
        private void findNextToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Text = "Notepad";
            f1.Show();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            saveFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName == "")
            {
                saveFileDialog1.Dispose();
            }
            else
            {
                TextWriter tw;
                tw = File.CreateText(saveFileDialog1.FileName);
                this.Text = saveFileDialog1.FileName;
                tw.WriteLine(richtxtbx_notepad.Text);
                tw.Dispose();
            }
            
        }














            //if (this.Text == "Notepad")
            //{
            //    saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            //    saveFileDialog1.ShowDialog();
            //    if (saveFileDialog1.FileName == "")
            //    {
            //        saveFileDialog1.Dispose();
            //    }
            //    else
            //    {
            //        TextWriter tw;
            //        tw = File.CreateText(saveFileDialog1.FileName);
            //        this.Text = saveFileDialog1.FileName;
            //        tw.WriteLine(richtxtbx_notepad.Text);
            //        tw.Dispose();
            //    }

            //}
            //else
            //{
            //    TextWriter tw1;
            //    tw1 = File.CreateText(this.Text);
            //    tw1.WriteLine(richtxtbx_notepad.Text);
            //    tw1.Dispose();
          //  }
    //
        //}

        private void saveToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text files(*.txt)|*.txt|All files(*.*)|*.*";
            saveFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName == "")
            {
                saveFileDialog1.Dispose();
            }
            else
            {
                TextWriter tw;
                tw = File.CreateText(saveFileDialog1.FileName);
                this.Text = saveFileDialog1.FileName;
                tw.WriteLine(richtxtbx_notepad.Text);
                tw.Dispose();
            }
            
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richtxtbx_notepad.Undo();
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richtxtbx_notepad.Cut();
            pasteToolStripMenuItem.Enabled = true;
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richtxtbx_notepad.Copy();
            pasteToolStripMenuItem.Enabled = true;

        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richtxtbx_notepad.Paste();

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richtxtbx_notepad.SelectedText != "")
            {
                string s1 = richtxtbx_notepad.SelectedText;
                richtxtbx_notepad.Text = richtxtbx_notepad.Text.Replace(s1, "");
            }
        }

        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void replaceToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void goToToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {

            richtxtbx_notepad.SelectAll();
        }

        private void timeDateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richtxtbx_notepad.AppendText(DateTime.Now.ToString());
        }

        private void statusToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
