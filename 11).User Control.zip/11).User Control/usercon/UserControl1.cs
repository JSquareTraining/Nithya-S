﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace usercon
{
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }


        int max;
        public int max_len
        {
            get
            {
                return max;
            }
            set
            {
                max = value;
            }
        }

        String mmax;
        public String maxtext
        {
            get
            {
                return mmax;
            }
            set
            {
                mmax = value;
            }
        }

        String max1;
        public String maxtext1
        {
            get
            {
                return max1;
            }
            set
            {
                max1 = value;
            }
        }
        String max2;
        public String maxtext2
        {
            get
            {
                return max2;
            }
            set
            {
                max2 = value;
            }
        }

        String max3;
        public String maxtext3
        {
            get
            {
                return max3;
            }
            set
            {
                max3 = value;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (listBox1.Text == "Indian Flag")
            {
                if (radioButton1.Checked == true)
                {
                    textBox1.BackColor = Color.Red;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.Green;
                    MessageBox.Show(mmax +max);
                    
                }
                if (radioButton2.Checked == true)
                {
                    textBox1.BackColor = Color.White;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.White;
                    MessageBox.Show(max1);
                  }
             }
            if (listBox1.Text == "Traffic Light")
            {
                if (radioButton1.Checked == true)
                {
                    textBox1.BackColor = Color.Red;
                    textBox2.BackColor = Color.Yellow;
                    textBox3.BackColor = Color.Green;
                    MessageBox.Show(max2 + max);
                 }
                if (radioButton2.Checked == true)
                {
                    textBox1.BackColor = Color.White;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.White;
                    MessageBox.Show(max1);
                }
            }
            if (listBox1.Text == "RGB")
            {
                if (radioButton1.Checked == true)
                {
                    textBox1.BackColor = Color.Red;
                    textBox2.BackColor = Color.Green;
                    textBox3.BackColor = Color.Blue;
                    MessageBox.Show(max3 + max);
                }
                if (radioButton2.Checked == true)
                {
                    textBox1.BackColor = Color.White;
                    textBox2.BackColor = Color.White;
                    textBox3.BackColor = Color.White;
                    MessageBox.Show(max1);
                }
            }
         }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                checkBox1.Checked = true;
            }
            else
            {
                checkBox1.Checked = false;
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
       {
       }
    }
}