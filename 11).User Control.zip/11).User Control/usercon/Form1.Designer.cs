﻿namespace usercon
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.userControl13 = new usercon.UserControl1();
            this.userControl12 = new usercon.UserControl1();
            this.userControl11 = new usercon.UserControl1();
            this.SuspendLayout();
            // 
            // userControl13
            // 
            this.userControl13.Location = new System.Drawing.Point(45, 280);
            this.userControl13.max_len = 3;
            this.userControl13.maxtext = "No of Colors Contain In Indian flag is:";
            this.userControl13.maxtext1 = "Light Off ";
            this.userControl13.maxtext2 = "No of Colors Cccontain in Traffic Light:";
            this.userControl13.maxtext3 = "No of Colors Contain in RGB:";
            this.userControl13.Name = "userControl13";
            this.userControl13.Size = new System.Drawing.Size(695, 100);
            this.userControl13.TabIndex = 2;
            // 
            // userControl12
            // 
            this.userControl12.Location = new System.Drawing.Point(45, 150);
            this.userControl12.max_len = 3;
            this.userControl12.maxtext = "No of Colors Contain In Indian flag is:";
            this.userControl12.maxtext1 = "Light Off ";
            this.userControl12.maxtext2 = "No of Colors Cccontain in Traffic Light:";
            this.userControl12.maxtext3 = "No of Colors Contain in RGB:";
            this.userControl12.Name = "userControl12";
            this.userControl12.Size = new System.Drawing.Size(695, 100);
            this.userControl12.TabIndex = 1;
            // 
            // userControl11
            // 
            this.userControl11.Location = new System.Drawing.Point(45, 23);
            this.userControl11.max_len = 3;
            this.userControl11.maxtext = "No of Colors Contain In Indian flag is:";
            this.userControl11.maxtext1 = "Light Off ";
            this.userControl11.maxtext2 = "No of Colors Contain in Traffic Light:";
            this.userControl11.maxtext3 = "No of Colors Contain in RGB:";
            this.userControl11.Name = "userControl11";
            this.userControl11.Size = new System.Drawing.Size(695, 100);
            this.userControl11.TabIndex = 0;
            this.userControl11.Load += new System.EventHandler(this.userControl11_Load);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 467);
            this.Controls.Add(this.userControl13);
            this.Controls.Add(this.userControl12);
            this.Controls.Add(this.userControl11);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private UserControl1 userControl11;
        private UserControl1 userControl12;
        private UserControl1 userControl13;
    }
}

