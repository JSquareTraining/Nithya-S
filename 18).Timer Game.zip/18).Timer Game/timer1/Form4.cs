﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace timer1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        int t = 30;
        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {
           
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
            if (progressBar1.Value < 1000)
            {
                progressBar1.Value = 100;
                timer2.Start();
            }

            else
            {

                this.Close();
            }
           
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
               
            

            //int  time = 10;
            //time = time - 1;
            //if (time == 0)
            //{
            //    Form1 f1 = new Form1();
            //    f1.ShowDialog();
            //    timer2.Interval = 100;
            // }
            //else
            //{
                
            //    this.Close();
            //}

            t = t - 1;

            if (t >= 0)
            {
                if (t == 0)
                {
                    Form1 f1 = new Form1();
                    f1.ShowDialog();
                }
            }
            else
            {
                timer1.Stop();


            }
           










            }
        
        }
    }

