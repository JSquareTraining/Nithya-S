﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace timer1
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        int i = DateTime.Now.Second;
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            timer1.Interval = 10;
            timer1.Start();
        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.Text = DateTime.Now.ToString();
            // label29.Text = "WAIT FOR FEW MINUTES";
            if (i + 1 == DateTime.Now.Second)
            {
                label28.Text = "Wait pannu pa...";
                label1.Visible = true;
            }
            if (i + 2 == DateTime.Now.Second)
            {
                label2.Visible = true;
                label28.Text = "";
                //label28.Text = " .....";
            }
            if (i + 3 == DateTime.Now.Second)
            {
                label3.Visible = true;
                label28.Text = "";
                label28.Text = "Adi Sagu.....";

            }
            if (i + 4 == DateTime.Now.Second)
            {
                label4.Visible = true;

            }
            if (i + 5 == DateTime.Now.Second)
            {
                label5.Visible = true;

            }
            if (i + 6 == DateTime.Now.Second)
            {
                label6.Visible = true;
                label28.Text = "Thiruba thiruba.....";
            }
            if (i + 7 == DateTime.Now.Second)
            {
                label7.Visible = true;

            }
            if (i + 8 == DateTime.Now.Second)
            {
                label8.Visible = true;

            }
            if (i + 9 == DateTime.Now.Second)
            {
                label9.Visible = true;

            }
            if (i + 10 == DateTime.Now.Second)
            {
                label10.Visible = true;
                label28.Text = "";
                label28.Text = " Unnoda peru solli yena kupadraga....";
            }
            if (i + 11 == DateTime.Now.Second)
            {
                label11.Visible = true;
            }
            if (i + 12 == DateTime.Now.Second)
            {
                label12.Visible = true;
            }
            if (i + 13 == DateTime.Now.Second)
            {


                label13.Visible = true;
            }
            if (i + 14 == DateTime.Now.Second)
            {

                label14.Visible = true;

            }
            if (i + 15 == DateTime.Now.Second)
            {
                label15.Visible = true;
                label28.Text = "yenna parkara neu nanu onna?";
            }
            if (i + 16 == DateTime.Now.Second)
            {
                label16.Visible = true;
            }
            if (i + 17 == DateTime.Now.Second)
            {
                label17.Visible = true;
            }
            if (i + 18 == DateTime.Now.Second)
            {
                label28.Text = "Thiruba varaya?";
                label18.Visible = true;

            }
            if (i + 19 == DateTime.Now.Second)
            {
                label19.Visible = true;
            }
            if (i + 20 == DateTime.Now.Second)
            {
                label20.Visible = true;
                label28.Text = "close paniruven Gundu";
            }
            if (i + 21 == DateTime.Now.Second)
            {
                label21.Visible = true;
            }
            if (i + 22 == DateTime.Now.Second)
            {
                label22.Visible = true;
                label28.Text = "Unna aparama Vechukaren....";
            }
            if (i + 23 == DateTime.Now.Second)
            {
                label23.Visible = true;
            }
            if (i + 24 == DateTime.Now.Second)
            {

                label24.Visible = true;
            }
            if (i + 25 == DateTime.Now.Second)
            {
                label25.Visible = true;
                label28.Text = "Unna aparama Vechukaren....";
            }
            if (i + 26 == DateTime.Now.Second)
            {
                label26.Visible = true;
            }
            if (label26.Visible == true)
            {
                label28.Text = "Ai Bulb proof Pannita da Ball Mella Irruku da";

                label28.Enabled = false;
            }

            //int n = DateTime.Now.Second;
           // {
               // if (n == 60)
               // {
                   // MessageBox.Show("Time over");
                   // timer1.Stop();
                   // this.Close();
                //}

                if (gettxt.Text == "A")
                {
                    label1.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "B")
                {
                    label2.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "C")
                {
                    label3.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "D")
                {
                    label4.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "E")
                {
                    label5.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "F")
                {
                    label6.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "G")
                {
                    label7.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "H")
                {
                    label8.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "I")
                {
                    label9.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "J")
                {
                    label10.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "K")
                {
                    label11.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "L")
                {
                    label12.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "M")
                {
                    label13.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "N")
                {
                    label14.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "O")
                {
                    label15.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "P")
                {
                    label16.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "Q")
                {
                    label17.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "R")
                {
                    label18.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "S")
                {
                    label19.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "T")
                {
                    label20.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "U")
                {
                    label21.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "V")
                {
                    label22.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "W")
                {
                    label23.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "X")
                {
                    label24.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "Y")
                {
                    label25.Visible = false;
                    gettxt.Text = "";
                }
                if (gettxt.Text == "Z")
                {
                    label26.Visible = false;
                    gettxt.Text = "";
                }


            
        }
        

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            int t = 60;

            if (t >= 0)
            {
                label21.Text = t.ToString();
                if (t == 0)
                {
                    Form5 f5 = new Form5();
                    f5.ShowDialog();
                }
                else
                {
                    timer1.Stop();

                }
            }
        }
    }
}
