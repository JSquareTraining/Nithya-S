﻿namespace timer1
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            this.lbl_one = new System.Windows.Forms.Label();
            this.lbl_two = new System.Windows.Forms.Label();
            this.lbl3_three = new System.Windows.Forms.Label();
            this.lbl_four = new System.Windows.Forms.Label();
            this.lbl_five = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_one
            // 
            this.lbl_one.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_one.ForeColor = System.Drawing.Color.DarkViolet;
            this.lbl_one.Image = ((System.Drawing.Image)(resources.GetObject("lbl_one.Image")));
            this.lbl_one.Location = new System.Drawing.Point(20, 9);
            this.lbl_one.Name = "lbl_one";
            this.lbl_one.Size = new System.Drawing.Size(208, 205);
            this.lbl_one.TabIndex = 0;
            this.lbl_one.Text = "9 + 17";
            this.lbl_one.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_one.Click += new System.EventHandler(this.lbl_one_Click);
            // 
            // lbl_two
            // 
            this.lbl_two.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_two.ForeColor = System.Drawing.Color.Red;
            this.lbl_two.Image = ((System.Drawing.Image)(resources.GetObject("lbl_two.Image")));
            this.lbl_two.Location = new System.Drawing.Point(20, 6);
            this.lbl_two.Name = "lbl_two";
            this.lbl_two.Size = new System.Drawing.Size(186, 181);
            this.lbl_two.TabIndex = 1;
            this.lbl_two.Text = "6 / 1";
            this.lbl_two.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl3_three
            // 
            this.lbl3_three.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3_three.ForeColor = System.Drawing.Color.Green;
            this.lbl3_three.Image = ((System.Drawing.Image)(resources.GetObject("lbl3_three.Image")));
            this.lbl3_three.Location = new System.Drawing.Point(20, 6);
            this.lbl3_three.Name = "lbl3_three";
            this.lbl3_three.Size = new System.Drawing.Size(185, 196);
            this.lbl3_three.TabIndex = 2;
            this.lbl3_three.Text = "8 * 3";
            this.lbl3_three.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl3_three.Click += new System.EventHandler(this.lbl3_three_Click);
            // 
            // lbl_four
            // 
            this.lbl_four.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_four.ForeColor = System.Drawing.Color.Blue;
            this.lbl_four.Image = ((System.Drawing.Image)(resources.GetObject("lbl_four.Image")));
            this.lbl_four.Location = new System.Drawing.Point(12, 2);
            this.lbl_four.Name = "lbl_four";
            this.lbl_four.Size = new System.Drawing.Size(215, 204);
            this.lbl_four.TabIndex = 3;
            this.lbl_four.Text = "13+7";
            this.lbl_four.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_four.Click += new System.EventHandler(this.lbl_four_Click);
            // 
            // lbl_five
            // 
            this.lbl_five.Font = new System.Drawing.Font("Times New Roman", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_five.ForeColor = System.Drawing.Color.OrangeRed;
            this.lbl_five.Image = ((System.Drawing.Image)(resources.GetObject("lbl_five.Image")));
            this.lbl_five.Location = new System.Drawing.Point(20, 2);
            this.lbl_five.Name = "lbl_five";
            this.lbl_five.Size = new System.Drawing.Size(197, 204);
            this.lbl_five.TabIndex = 4;
            this.lbl_five.Text = "8 - 1";
            this.lbl_five.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(345, 66);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(110, 35);
            this.textBox1.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(359, 115);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(531, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 32);
            this.label1.TabIndex = 8;
            this.label1.Text = "Score";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(513, 66);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 35);
            this.textBox3.TabIndex = 9;
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1137, 490);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lbl_five);
            this.Controls.Add(this.lbl_four);
            this.Controls.Add(this.lbl3_three);
            this.Controls.Add(this.lbl_two);
            this.Controls.Add(this.lbl_one);
            this.ForeColor = System.Drawing.Color.Coral;
            this.Name = "Form5";
            this.Text = "Form5";
            this.Load += new System.EventHandler(this.Form5_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_one;
        private System.Windows.Forms.Label lbl_two;
        private System.Windows.Forms.Label lbl3_three;
        private System.Windows.Forms.Label lbl_four;
        private System.Windows.Forms.Label lbl_five;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox3;
    }
}