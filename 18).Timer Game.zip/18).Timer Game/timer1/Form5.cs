﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace timer1
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            lbl_one.Visible = false;
            lbl_two.Visible = false;
            lbl3_three.Visible = false;
            lbl_four.Visible = false;
            lbl_five.Visible = false;

            timer1.Interval = 1000;
            timer1.Start();
        }
        int time = 80;
        int clik = 1;
        int clik1 = 1;
        int clik2 = 1;
        int clik3 = 1;
        int clik4 = 1;
        int score = 0;
        Properties.Settings ps = new Properties.Settings();

        private void timer1_Tick(object sender, EventArgs e)
        {
            time = time - 1;
            if (time > 0)
            {
                timer2.Interval = 10;
            }
            else
            {
                this.Close();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (clik == 1)
            {
                int x = lbl_one.Location.X;
                int y = lbl_one.Location.Y;
                x = x + 1;
                y = y + 1;
                if (time > 70)
                {
                    lbl_one.Show();
                    lbl_one.Location = new Point(x, y);
                }
                else
                {
                    lbl_one.Visible = false;

                }
            }

            if (clik1 == 1)
            {
                int x1 = lbl_two.Location.X;
                int y1 = lbl_two.Location.Y;
                x1 = x1 + 2;
                y1 = y1 + 2;
                if (time >= 65 && time <= 70)
                {
                    lbl_two.Show();
                    lbl_two.Location = new Point(x1, y1);
                }
                else
                {
                    lbl_two.Visible = false;
                }
            }
            if (clik2 == 1)
            {
                int x2 = lbl3_three.Location.X;
                int y2 = lbl3_three.Location.Y;
                x2 = x2 + 3;
                y2 = y2 + 3;
                if (time >= 60 && time <= 65)
                {
                    lbl3_three.Show();
                    lbl3_three.Location = new Point(x2, y2);
                }
                else
                {
                    lbl3_three.Visible = false;
                }
            }
            if (clik3 == 1)
            {
                int x3 = lbl_four.Location.X;
                int y3 = lbl_four.Location.Y;
                x3 = x3 + 4;
                y3 = y3 + 4;
                if (time >= 55 && time <= 60)
                {
                    lbl_four.Show();
                    lbl_four.Location = new Point(x3, y3);
                }
                else
                {
                    lbl_four.Visible = false;
                }
            }
            if (clik4 == 1)
            {
                int x4 = lbl_five.Location.X;
                int y4 = lbl_five.Location.Y;
                x4 = x4 + 5;
                y4 = y4 + 5;
                if (time >= 50 && time <= 55)
                {
                    lbl_five.Show();
                    lbl_five.Location = new Point(x4, y4);
                }
                else
                {
                    lbl_five.Visible = false;
                }
            }

        }





        private void lbl_one_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (clik == 1)
            {
                if (time > 70)
                {
                    if (textBox1.Text == "26")
                    {
                        lbl_one.Visible = false;
                        score =score +1;
                        ps.score1 = score.ToString();
                        ps.Save();
                        textBox3.Text = score.ToString();
                        textBox1.Text = "";
                        textBox3.Text = score.ToString();
                    }

                    else
                    {
                        lbl_one.Visible = false;
                        MessageBox.Show("Wrong Answer");
                    }
                    clik1 = clik1 - 1;
                }
            }
            if (clik1 == 1)
            {
                if (time >= 65 && time <= 70)
                {
                    if (textBox1.Text == "1")
                    {
                        score =score +1;
                        ps.score1 = score.ToString();
                        ps.Save();
                        textBox3.Text = score.ToString();
                        lbl_two.Visible = false;
                        textBox1.Text = "";
                        textBox3.Text = score.ToString();
                    }
                    else
                    {
                        lbl_two.Visible = false;
                    }
                    clik1 = clik1 - 1;
                }
            }


            if (clik2 == 1)
            {
                if (time >= 60 && time <= 65)
                {
                    if (textBox1.Text == "24")
                    {
                        score =score +1;
                        ps.score1 = score.ToString();
                        ps.Save();
                        textBox3.Text = score.ToString();
                        lbl_one.Visible = false;
                        textBox1.Text = "";
                        textBox3.Text = score.ToString();
                    }
                    else
                    {
                        lbl_one.Visible = false;
                    }
                    clik1 = clik1 - 1;
                }
            }
            if (clik3 == 1)
            {
                if (time >= 55 && time <= 60)
                {
                    if (textBox1.Text == "20")
                    {
                        score =score +1;
                        ps.score1 = score.ToString();
                        ps.Save();
                        textBox3.Text = score.ToString();
                        lbl_one.Visible = false;
                        textBox1.Text = "";
                        textBox3.Text = score.ToString();
                    }
                    else
                    {
                        lbl_one.Visible = false;
                    }
                    clik1 = clik1 - 1;
                }
            }

            if (clik4 == 1)
            {
                if (time >= 50 && time <= 55)
                {
                    if (textBox1.Text == "7")
                    {
                        score =score +1;
                        ps.score1 = score.ToString();
                        ps.Save();
                        textBox3.Text = score.ToString();
                        lbl_one.Visible = false;
                        textBox1.Text = "";
                        textBox3.Text = score.ToString();
                    }
                    else
                    {
                        lbl_one.Visible = false;
                    }
                }
                clik1 = clik1 - 1;
            }







        }

        private void lbl3_three_Click(object sender, EventArgs e)
        {

        }

        private void lbl_four_Click(object sender, EventArgs e)
        {

        }




    }
}
    
