﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace timer1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int i;
        int t = 360;
        Point po = new Point();
        Point po1 = new Point();
        Point po2 = new Point();
        Point po3 = new Point();
        Point po4 = new Point();
        Point po5 = new Point();
        Point po6 = new Point();
        Point po7 = new Point();
        Point po8 = new Point();
        Point po9 = new Point();
        Point po10 = new Point();
        Point po11 = new Point();
        Point po12 = new Point();
        Point po13 = new Point();
        Point po14 = new Point();
        Point po15 = new Point();
        Point po16 = new Point();
        Point po17 = new Point();
        Point po18 = new Point();
        Point po19 = new Point();
        Point po20 = new Point();

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
                            

            if (po.Y > 1)
            {
                po.X += 0;
                po.Y += -1;
                label1.Location = po;
            }
            else
            {
                po.X = 200;
                po.Y = 700;
                label1.Visible = true;
            }
            
            if (po1.Y > 1)
            {
                po1.X += 0;
                po1.Y += -1;
                label2.Location = po1;
            }
            else
            {
                po1.X = 400;
                po1.Y = 950;
                label2.Visible = true;
            }


            if (po2.Y > 1)
            {
                po2.X += 0;
                po2.Y += -1;
                label3.Location = po2;
            }
            else
            {
                po2.X = 300;
                po2.Y = 800;
                label3.Visible = true;
            }
            if (po3.Y > 1)
            {
                po3.X += 0;
                po3.Y += -1;
                label4.Location = po3;
            }
            else
            {
                po3.X = 800;
                po3.Y = 550;
                label4.Visible = true;
            }


            if (po4.Y > 1)
            {
                po4.X += 0;
                po4.Y += -1;
                label5.Location = po4;
            }
            else
            {
                po4.X = 500;
                po4.Y = 700;
                label5.Visible = true;
            }




            if (po5.Y > 1)
            {
                po5.X += 0;
                po5.Y += -1;
                label6.Location = po5;
            }
            else
            {
                po5.X = 600;
                po5.Y = 1400;
                label6.Visible = true;
            }

            if (po6.Y > 1)
            {
                po6.X += 0;
                po6.Y += -1;
                label7.Location = po6;
            }
            else
            {
                po6.X = 100;
                po6.Y = 600;
                label7.Visible = true;
            }


            if (po7.Y > 1)
            {
                po7.X += 0;
                po7.Y += -1;
                label8.Location = po7;
            }
            else
            {
                po7.X = 700;
                po7.Y = 800;
                label8.Visible = true;
            }


            if (po8.Y > 1)
            {
                po8.X += 0;
                po8.Y += -1;
                label9.Location = po8;
            }
            else
            {
                po8.X = 900;
                po8.Y = 800;
                label9.Visible = true;
            }



            if (po9.X > 1)
            {
                po9.X += 0;
                po9.Y += -1;
                label10.Location = po9;
            }
            else
            {
                po9.X = 1000;
                po9.Y = 700;
                label10.Visible = true;
            }

            if (po10.X > 1)
            {
                po10.X += 0;
                po10.Y += -1;
                label11.Location = po10;
            }
            else
            {
                po10.X = 250;
                po10.Y = 700;
                label11.Visible = true;
            }

            if (po11.X > 1)
            {
                po11.X += 0;
                po11.Y += -1;
                label11.Location = po11;
            }
            else
            {
                po11.X = 350;
                po11.Y = 600;
                label11.Visible = true;
            }

            if (po12.X > 1)
            {
                po12.X += 0;
                po12.Y += -1;
                label12.Location = po11;
            }
            else
            {
                po12.X = 850;
                po12.Y = 600;
                label12.Visible = true;
            }

            if (po13.X > 1)
            {
                po13.X += 0;
                po13.Y += -1;
                label13.Location = po13;
            }
            else
            {
                po13.X = 500;
                po13.Y = 300;
                label13.Visible = true;
            }

            if (po14.X > 1)
            {
                po14.X += 0;
                po14.Y += -1;
                label14.Location = po14;
            }
            else
            {
                po14.X = 100;
                po14.Y = 900;
                label14.Visible = true;
            }


            if (po15.X > 1)
            {
                po15.X += 0;
                po15.Y += -1;
                label15.Location = po15;
            }
            else
            {
                po15.X = 760;
                po15.Y = 950;
                label15.Visible = true;
            }

            if (po16.X > 1)
            {
                po16.X += 0;
                po16.Y += -1;
                label16.Location = po16;
            }
            else
            {
                po16.X = 500;
                po16.Y = 900;
                label16.Visible = true;
            }

            if (po17.X > 1)
            {
                po17.X += 0;
                po17.Y += -1;
                label17.Location = po17;
            }
            else
            {
                po17.X = 650;
                po17.Y = 700;
                label17.Visible = true;
            }

            if (po18.X > 1)
            {
                po18.X += 0;
                po18.Y += -1;
                label18.Location = po18;
            }
            else
            {
                po18.X = 800;
                po18.Y = 900;
                label18.Visible = true;
            }

            if (po19.X > 1)
            {
                po19.X += 0;
                po19.Y += -1;
                label19.Location = po19;
            }
            else
            {
                po19.X = 300;
                po19.Y = 700;
                label19.Visible = true;
            }
            if (po20.X > 1)
            {
                po20.X += 0;
                po20.Y += -1;
                label20.Location = po20;
            }
            else
            {
                po20.X = 650;
                po20.Y = 500;
                label20.Visible = true;
            }


        }

          
        
        private void Form1_Load(object sender, EventArgs e)
        {
            //label1.Visible = true;
        }

        private void label2_Click(object sender, EventArgs e)
        {


        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
           if (i == 40)
           {
               DialogResult dr = new DialogResult();
               dr= MessageBox.Show("Congradulation You Won The Game", "game", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
               if (dr == DialogResult.OK)
               {
                   timer1.Stop();
                   Form1 f1 = new Form1();
                   f1.Close();
                   this.Close();
               }

           }
        
           if (label1.Text == textBox1.Text)
           {
               i++;
               label1.Visible = false;
               textBox1.Text = "";
           }
           if (label2.Text == textBox1.Text)
           {
               i++;
               label2.Visible = false;
               textBox1.Text = "";
           }
           if (label3.Text == textBox1.Text)
           {
               i++;
               label3.Visible = false;
               textBox1.Text = "";
           }
           if (label4.Text == textBox1.Text)
           {
               i++;
               label4.Visible = false;
               textBox1.Text = "";
           }
           if (label5.Text == textBox1.Text)
           {
               i++;
               label5.Visible = false;
               textBox1.Text = "";
           }
           if (label6.Text == textBox1.Text)
           {
               i++;
               label6.Visible = false;
               textBox1.Text = "";
           }
           if (label7.Text == textBox1.Text)
           {
               i++;
               label7.Visible = false;
               textBox1.Text = "";
           }
           if (label8.Text == textBox1.Text)
           {
               i++;
               label8.Visible = false;
               textBox1.Text = "";
           }
           if (label9.Text == textBox1.Text)
           {
               i++;
               label9.Visible = false;
               textBox1.Text = "";
           }
           if (label10.Text == textBox1.Text)
           {
               i++;
               label10.Visible = false;
               textBox1.Text = "";
           }
           if (label11.Text == textBox1.Text)
           {
               i++;
               label11.Visible = false;
               textBox1.Text = "";
           }
           if (label12.Text == textBox1.Text)
           {
               i++;
               label12.Visible = false;
               textBox1.Text = "";
           }
           if (label13.Text == textBox1.Text)
           {
               i++;
               label13.Visible = false;
               textBox1.Text = "";
           }
           if (label14.Text == textBox1.Text)
           {
               i++;
               label14.Visible = false;
               textBox1.Text = "";
           }
           if (label15.Text == textBox1.Text)
           {
               i++;
               label15.Visible = false;
               textBox1.Text = "";
           }
           if (label16.Text == textBox1.Text)
           {
               i++;
               label16.Visible = false;
               textBox1.Text = "";
           }
           if (label17.Text == textBox1.Text)
           {
               i++;
               label17.Visible = false;
               textBox1.Text = "";
           }
           if (label18.Text == textBox1.Text)
           {
               i++;
               label18.Visible = false;
               textBox1.Text = "";
           }
           if (label19.Text == textBox1.Text)
           {
               i++;
               label19.Visible = false;
               textBox1.Text = "";
           }
           if (label20.Text == textBox1.Text)
           {
               i++;
               label20.Visible = false;
               textBox1.Text = "";
           }

           //if (i >= 20)
           //{
           //    MessageBox.Show("game over");
           //}






        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            t = t - 1;

            if (t >= 0)
            {
                label21.Text = t.ToString();
                if (t == 0)
                {
                    MessageBox.Show("Time Up U Lost");
                    Form3 f3 = new Form3();
                    f3.ShowDialog();
                }
            }
            else
            {
             timer1.Stop();
            }
        }
        private void label21_Click(object sender, EventArgs e)
        {

        }
    }
}
