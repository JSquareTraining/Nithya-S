﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;



namespace timer1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        Point po = new Point();
        Point po1 = new Point();
        private void Form2_Load(object sender, EventArgs e)
        {
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            //   if (po.Y > 1)
            //   {
            ////       po.X += 1;
            ////       po.Y += -10;
            //       label1.Location = po;
            //       label1.Text = "1+2";
            //       label1.Visible = true;
            //   }
            //   else
            //   {
            //       po.X = 300;
            //       po.Y = 600;
            //   }

            //   if (po1.Y > 10)
            //   {
            //       po1.X += 1;
            //       po1.Y += -10;
            //       label3.Location = po1;
            //       label3.Text = "1-2";
            //       label3.Visible = true;
            //       label1.Visible = false;
            //   }
            //   else
            //   {
            //       po1.X = 300;
            //       po1.Y = 999;
            //   }
            //}  

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
