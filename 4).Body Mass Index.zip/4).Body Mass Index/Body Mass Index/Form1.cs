﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Body_Mass_Index
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            Double i = Convert.ToDouble(txt1.Text);
            Double j = Convert.ToDouble(txt2.Text);
            Double k = Convert.ToDouble(txt3.Text);
           // Double l = Convert.ToDouble(txt4.Text);

            Double inc=i*12;
            Double or = inc + j;
            Double cm=or*2.540;
            Double me=cm/100;
            Double po = k / 2;
            Double l = (po/(me*me));
            txt4.Text = Convert.ToString(l);

                     
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Double l = Convert.ToDouble(txt4.Text);
            if (l < (18.5))
            {
                txt5.Text = "UnderWeight";
            }
            else if (l >= 18.5 && l < 24.9)
            {
                txt5.Text = "Normal Weight";
            }
            else if (l >= 25 && l < 29.9)
            {
                txt5.Text = "Over Weight";
            }
            else if (l > 30)
            {
                txt5.Text = "Obesity";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            txt1.Text = "";
            txt2.Text = "";
            txt3.Text = "";
            txt4.Text = "";
            txt5.Text = "";
                    }
    }
}
