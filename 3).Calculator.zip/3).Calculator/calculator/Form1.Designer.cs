﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt1_data = new System.Windows.Forms.TextBox();
            this.txt2_data = new System.Windows.Forms.TextBox();
            this.txt3_data = new System.Windows.Forms.TextBox();
            this.lb1_data = new System.Windows.Forms.Label();
            this.lb2_data = new System.Windows.Forms.Label();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn_dot = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.btn_equal = new System.Windows.Forms.Button();
            this.btn_sub = new System.Windows.Forms.Button();
            this.btn_multi = new System.Windows.Forms.Button();
            this.btn_div = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.clear_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt1_data
            // 
            this.txt1_data.BackColor = System.Drawing.Color.Silver;
            this.txt1_data.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt1_data.Location = new System.Drawing.Point(7, 31);
            this.txt1_data.Name = "txt1_data";
            this.txt1_data.Size = new System.Drawing.Size(50, 20);
            this.txt1_data.TabIndex = 0;
            // 
            // txt2_data
            // 
            this.txt2_data.BackColor = System.Drawing.Color.Silver;
            this.txt2_data.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt2_data.Location = new System.Drawing.Point(119, 31);
            this.txt2_data.Name = "txt2_data";
            this.txt2_data.Size = new System.Drawing.Size(50, 20);
            this.txt2_data.TabIndex = 1;
            // 
            // txt3_data
            // 
            this.txt3_data.BackColor = System.Drawing.Color.Silver;
            this.txt3_data.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt3_data.Location = new System.Drawing.Point(231, 31);
            this.txt3_data.Name = "txt3_data";
            this.txt3_data.Size = new System.Drawing.Size(50, 20);
            this.txt3_data.TabIndex = 2;
            // 
            // lb1_data
            // 
            this.lb1_data.BackColor = System.Drawing.Color.Silver;
            this.lb1_data.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb1_data.Location = new System.Drawing.Point(63, 31);
            this.lb1_data.Name = "lb1_data";
            this.lb1_data.Size = new System.Drawing.Size(50, 20);
            this.lb1_data.TabIndex = 3;
            this.lb1_data.Click += new System.EventHandler(this.lab_click);
            // 
            // lb2_data
            // 
            this.lb2_data.BackColor = System.Drawing.Color.Silver;
            this.lb2_data.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb2_data.Location = new System.Drawing.Point(175, 31);
            this.lb2_data.Name = "lb2_data";
            this.lb2_data.Size = new System.Drawing.Size(50, 20);
            this.lb2_data.TabIndex = 4;
            this.lb2_data.Click += new System.EventHandler(this.eql_click);
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(28, 308);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(50, 29);
            this.btn0.TabIndex = 5;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.click);
            // 
            // btn_dot
            // 
            this.btn_dot.Location = new System.Drawing.Point(84, 308);
            this.btn_dot.Name = "btn_dot";
            this.btn_dot.Size = new System.Drawing.Size(50, 29);
            this.btn_dot.TabIndex = 6;
            this.btn_dot.Text = ".";
            this.btn_dot.UseVisualStyleBackColor = true;
            this.btn_dot.Click += new System.EventHandler(this.click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(140, 308);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(50, 29);
            this.btn_add.TabIndex = 7;
            this.btn_add.Text = "+";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.lab_click);
            // 
            // btn_equal
            // 
            this.btn_equal.Location = new System.Drawing.Point(196, 254);
            this.btn_equal.Name = "btn_equal";
            this.btn_equal.Size = new System.Drawing.Size(50, 83);
            this.btn_equal.TabIndex = 8;
            this.btn_equal.Text = "=";
            this.btn_equal.UseVisualStyleBackColor = true;
            this.btn_equal.Click += new System.EventHandler(this.eql_click);
            // 
            // btn_sub
            // 
            this.btn_sub.Location = new System.Drawing.Point(140, 254);
            this.btn_sub.Name = "btn_sub";
            this.btn_sub.Size = new System.Drawing.Size(50, 29);
            this.btn_sub.TabIndex = 9;
            this.btn_sub.Text = "-";
            this.btn_sub.UseVisualStyleBackColor = true;
            this.btn_sub.Click += new System.EventHandler(this.lab_click);
            // 
            // btn_multi
            // 
            this.btn_multi.Location = new System.Drawing.Point(84, 254);
            this.btn_multi.Name = "btn_multi";
            this.btn_multi.Size = new System.Drawing.Size(50, 29);
            this.btn_multi.TabIndex = 10;
            this.btn_multi.Text = "*";
            this.btn_multi.UseVisualStyleBackColor = true;
            this.btn_multi.Click += new System.EventHandler(this.lab_click);
            // 
            // btn_div
            // 
            this.btn_div.Location = new System.Drawing.Point(28, 254);
            this.btn_div.Name = "btn_div";
            this.btn_div.Size = new System.Drawing.Size(50, 29);
            this.btn_div.TabIndex = 11;
            this.btn_div.Text = "/";
            this.btn_div.UseVisualStyleBackColor = true;
            this.btn_div.Click += new System.EventHandler(this.lab_click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(28, 204);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(50, 29);
            this.btn4.TabIndex = 12;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(84, 204);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(50, 29);
            this.btn3.TabIndex = 13;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(140, 204);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(50, 29);
            this.btn2.TabIndex = 14;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.click);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(196, 204);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(50, 29);
            this.btn1.TabIndex = 15;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(28, 153);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(50, 29);
            this.btn5.TabIndex = 16;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(84, 153);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(50, 29);
            this.btn6.TabIndex = 17;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(140, 153);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(50, 29);
            this.btn7.TabIndex = 18;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.click);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(196, 153);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(50, 29);
            this.btn8.TabIndex = 19;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.click);
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(28, 94);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(100, 35);
            this.btn9.TabIndex = 20;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.click);
            // 
            // clear_btn
            // 
            this.clear_btn.Location = new System.Drawing.Point(140, 94);
            this.clear_btn.Name = "clear_btn";
            this.clear_btn.Size = new System.Drawing.Size(100, 35);
            this.clear_btn.TabIndex = 21;
            this.clear_btn.Text = "A/C";
            this.clear_btn.UseVisualStyleBackColor = true;
            this.clear_btn.Click += new System.EventHandler(this.clear_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(284, 373);
            this.Controls.Add(this.clear_btn);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn_div);
            this.Controls.Add(this.btn_multi);
            this.Controls.Add(this.btn_sub);
            this.Controls.Add(this.btn_equal);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.btn_dot);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.lb2_data);
            this.Controls.Add(this.lb1_data);
            this.Controls.Add(this.txt3_data);
            this.Controls.Add(this.txt2_data);
            this.Controls.Add(this.txt1_data);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "CALCULATOR";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt1_data;
        private System.Windows.Forms.TextBox txt2_data;
        private System.Windows.Forms.TextBox txt3_data;
        private System.Windows.Forms.Label lb1_data;
        private System.Windows.Forms.Label lb2_data;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn_dot;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Button btn_equal;
        private System.Windows.Forms.Button btn_sub;
        private System.Windows.Forms.Button btn_multi;
        private System.Windows.Forms.Button btn_div;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button clear_btn;
    }
}

