﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void click(object sender, EventArgs e)
        {

            if (lb1_data.Text == "")
            {
                 Button btn = (Button)sender;
                 txt1_data.Text += ActiveControl.Text;
            }
                      
            if (lb1_data.Text != "" && txt1_data.Text != "")
            {
                Button btn1 = (Button)sender;
                txt2_data.Text += ActiveControl.Text;
            }
       }
        
        private void lab_click(object sender, EventArgs e)
        {
                Button btn2 = (Button)sender;
                lb1_data.Text = btn2.Text;
        }

        private void eql_click(object sender, EventArgs e)
        {
            if (txt2_data.Text != "")
            {
                lb2_data.Text = "=";
            }
            if (lb2_data.Text == "=")
            {

                
                Double i = Convert .ToDouble (txt1_data.Text);
                Double j = Convert .ToDouble ( txt2_data.Text);
                           
                if (lb1_data.Text == "+")
                {
                    Double k = i + j;
                    txt3_data.Text = Convert.ToString(k);
                }
                else if (lb1_data.Text == "-")
                {
                    Double k = i - j;
                    txt3_data.Text = Convert.ToString(k);
                }
                else if (lb1_data.Text == "*")
                {
                    Double k = i * j;
                    txt3_data.Text = Convert.ToString(k);
                }
                else if (lb1_data.Text == "/")
                {
                    Double k = i / j;
                    txt3_data.Text = Convert.ToString(k);
                }

            }

        }

        private void clear_Click(object sender, EventArgs e)
        {
            txt1_data.Text = "";
            txt2_data.Text = "";
            lb1_data.Text = "";
            lb2_data.Text = "";
            txt3_data.Text = "";
        }
}

}


//    private void click(object sender, EventArgs e)
    //    {
            
    //            Button btn = (Button)sender;
    //            txt1_data.Text += ActiveControl.Text;
    //        }

    //        if (lb1_data.Text == "")
    //        {
    //            Label lb = (Label)sender;
    //            lb1_data.Text += lb.Text;
    //        }
    //        if (lb1_data.Text != "")
    //        {
    //            Button btn1 = (Button)sender;
    //            txt2_data.Text += ActiveControl.Text;

    //        }

        
        

    //    private void click1(object sender, EventArgs e)
    //    {
    //        //{

    //        //    Label lb = (Label)sender;
    //        //    lb1_data.Text += lb.Text;
    //        //} 
             
    //        if (lb1_data.Text != "")
    //        {
    //            Button btn1 = (Button)sender;
    //            txt2_data.Text += ActiveControl.Text;

    //        }
    //    }
    //    private void click2(object sender, EventArgs e)
    //    {
    //        if (txt2_data.Text != "")
    //        {
    //            lb2_data.Text = "=";
    //        }
    //        if (lb2_data.Text != "")
    //        {
    //            int i = Convert.ToInt16(txt1_data);

    //            int j = Convert.ToInt16(txt2_data);


    //            if (lb1_data.Text == "+")
    //            {
    //                int k = i + j;
    //                txt3_data.Text = Convert.ToString(k);
    //            }
    //            else if (lb1_data.Text == "-")
    //            {
    //                int k = i - j;
    //                txt3_data.Text = Convert.ToString(k);
    //            }
    //            else if (lb1_data.Text == "*")
    //            {
    //                int k = i * j;
    //                txt3_data.Text = Convert.ToString(k);
    //            }
    //            else if (lb1_data.Text == "/")
    //            {
    //                int k = i / j;
    //                txt3_data.Text = Convert.ToString(k);

    //            }
    //        }
    //    }
    //}

            //Label lb = (Label)sender;
            //lb1_data.Text += lb.Text;

            //Button btn1 = (Button)sender;
            //txt2_data.Text += ActiveControl.Text;

            //Label lb2 = (Label)sender;
            //lb2_data.Text += lb2.Text;

                    

            //lb1_data.Text += ActiveControl.Text;
            //txt2_data.Text += ActiveControl.Text;


           // lb1_data.Text = lb1.Text;
            //lbl_main.BackColor = lbll.BackColor;




//        private void click2(object sender, EventArgs e)
//        {
//            Button btn1 = (Button)sender;
//            lb1_data.Text = btn1.Text;
//                  }


//        private void click(object sender, EventArgs e)
//        {
//            Button btn1 = (Button)sender;
//            txt2_data.Text += ActiveControl.Text;
//        }

//        private void click4(object sender, EventArgs e)
//        {
//            Button btn1 = (Button)sender;
//            lb2_data.Text = btn1.Text;

//            }


//        }

//        private void click5(object sender, EventArgs e)
//        {
//            int i = Convert.ToInt16(txt1_data);

//            int j = Convert.ToInt16(txt2_data);

//             if (lb1_data.Text == "+")
//             {
//              int k=i+j;
//              txt3_data.Text = Convert.ToString(k);
//             }
//             else if(lb1_data.Text=="-")
//             {
//              int k=i-j;
//              txt3_data.Text = Convert.ToString(k);
//             }
//             else if(lb1_data.Text=="*")
//             {
//              int k=i*j;
//              txt3_data.Text = Convert.ToString(k);
//             }
//             else if (lb1_data.Text == "/")
//             {
//              int k = i / j;
//              txt3_data.Text = Convert.ToString(k);

//             }
//        }

//        private void click3(object sender, EventArgs e)
//        {

//        }

//        private void txt1_data_TextChanged(object sender, EventArgs e)
//        {

//        }


//}