﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace webbrows
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TextReader tr;
            tr = File.OpenText(@"S:\nithya\project\book.txt");
            richTextBox1.Text = tr.ReadToEnd();
            tr.Dispose();
            tr.Close();
        }
    }
}
