﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_clr(object sender, EventArgs e)
        {
            Label lbll = (Label)sender;
            lbl_color.BackColor = lbll.BackColor;
            lbl_main.BackColor = lbll.BackColor;
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void lbl_gold_Click(object sender, EventArgs e)
        {

        }

        private void lbl_color_Click(object sender, EventArgs e)
        {

        }

        //private void label4_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_red.BackColor;
        //    lbl_main.BackColor = lbl_red.BackColor;
        //}

        //private void label5_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_green.BackColor;
        //    lbl_main.BackColor = lbl_green.BackColor;
        //}

        //private void label6_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_blue.BackColor;
        //    lbl_main.BackColor = lbl_blue.BackColor;
        //}

        //private void label7_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_orange.BackColor;
        //    lbl_main.BackColor = lbl_orange.BackColor;
        //}

        //private void Form1_Load(object sender, EventArgs e)
        //{

        //}

        //private void label2_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_pink.BackColor;
        //    lbl_main.BackColor = lbl_pink.BackColor; 
        //}

        //private void lbl_brown_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_brown.BackColor;
        //    lbl_main.BackColor = lbl_brown.BackColor;
        //}

        //private void lbl_silver_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_silver.BackColor;
        //    lbl_main.BackColor = lbl_silver.BackColor;
        //}

        //private void lbl_black_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_black.BackColor;
        //    lbl_main.BackColor = lbl_black.BackColor;
        //}

        //private void lbl_white_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_white.BackColor;
        //    lbl_main.BackColor = lbl_white.BackColor;
        //}

        //private void lbl_wheat_Click(object sender, EventArgs e)
        //{
        //    lbl_color.BackColor = lbl_wheat.BackColor;
        //    lbl_main.BackColor = lbl_wheat.BackColor;
        //}
    }
}
