﻿namespace WindowsFormsApplication1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_wheat = new System.Windows.Forms.Label();
            this.lbl_brown = new System.Windows.Forms.Label();
            this.lbl_silver = new System.Windows.Forms.Label();
            this.lbl_white = new System.Windows.Forms.Label();
            this.lbl_black = new System.Windows.Forms.Label();
            this.lbl_pink = new System.Windows.Forms.Label();
            this.lbl_orange = new System.Windows.Forms.Label();
            this.lbl_blue = new System.Windows.Forms.Label();
            this.lbl_green = new System.Windows.Forms.Label();
            this.lbl_red = new System.Windows.Forms.Label();
            this.lbl_color = new System.Windows.Forms.Label();
            this.lbl_main = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_wheat
            // 
            this.lbl_wheat.BackColor = System.Drawing.Color.Wheat;
            this.lbl_wheat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_wheat.Location = new System.Drawing.Point(299, 54);
            this.lbl_wheat.Name = "lbl_wheat";
            this.lbl_wheat.Size = new System.Drawing.Size(18, 18);
            this.lbl_wheat.TabIndex = 24;
            this.lbl_wheat.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_brown
            // 
            this.lbl_brown.BackColor = System.Drawing.Color.Brown;
            this.lbl_brown.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_brown.Location = new System.Drawing.Point(275, 54);
            this.lbl_brown.Name = "lbl_brown";
            this.lbl_brown.Size = new System.Drawing.Size(18, 18);
            this.lbl_brown.TabIndex = 23;
            this.lbl_brown.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_silver
            // 
            this.lbl_silver.BackColor = System.Drawing.Color.Silver;
            this.lbl_silver.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_silver.Location = new System.Drawing.Point(249, 54);
            this.lbl_silver.Name = "lbl_silver";
            this.lbl_silver.Size = new System.Drawing.Size(18, 18);
            this.lbl_silver.TabIndex = 22;
            this.lbl_silver.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_white
            // 
            this.lbl_white.BackColor = System.Drawing.Color.White;
            this.lbl_white.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_white.Location = new System.Drawing.Point(220, 54);
            this.lbl_white.Name = "lbl_white";
            this.lbl_white.Size = new System.Drawing.Size(18, 18);
            this.lbl_white.TabIndex = 21;
            this.lbl_white.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_black
            // 
            this.lbl_black.BackColor = System.Drawing.Color.Black;
            this.lbl_black.Location = new System.Drawing.Point(195, 54);
            this.lbl_black.Name = "lbl_black";
            this.lbl_black.Size = new System.Drawing.Size(18, 18);
            this.lbl_black.TabIndex = 20;
            this.lbl_black.Text = "label2";
            this.lbl_black.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_pink
            // 
            this.lbl_pink.BackColor = System.Drawing.Color.Pink;
            this.lbl_pink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_pink.Location = new System.Drawing.Point(299, 27);
            this.lbl_pink.Name = "lbl_pink";
            this.lbl_pink.Size = new System.Drawing.Size(18, 18);
            this.lbl_pink.TabIndex = 19;
            this.lbl_pink.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_orange
            // 
            this.lbl_orange.BackColor = System.Drawing.Color.Orange;
            this.lbl_orange.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_orange.Location = new System.Drawing.Point(275, 26);
            this.lbl_orange.Name = "lbl_orange";
            this.lbl_orange.Size = new System.Drawing.Size(18, 18);
            this.lbl_orange.TabIndex = 18;
            this.lbl_orange.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_blue
            // 
            this.lbl_blue.BackColor = System.Drawing.Color.Blue;
            this.lbl_blue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_blue.Location = new System.Drawing.Point(246, 27);
            this.lbl_blue.Name = "lbl_blue";
            this.lbl_blue.Size = new System.Drawing.Size(18, 18);
            this.lbl_blue.TabIndex = 17;
            this.lbl_blue.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_green
            // 
            this.lbl_green.BackColor = System.Drawing.Color.Green;
            this.lbl_green.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_green.Location = new System.Drawing.Point(220, 27);
            this.lbl_green.Name = "lbl_green";
            this.lbl_green.Size = new System.Drawing.Size(18, 18);
            this.lbl_green.TabIndex = 16;
            this.lbl_green.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_red
            // 
            this.lbl_red.BackColor = System.Drawing.Color.Red;
            this.lbl_red.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_red.Location = new System.Drawing.Point(195, 27);
            this.lbl_red.Name = "lbl_red";
            this.lbl_red.Size = new System.Drawing.Size(18, 18);
            this.lbl_red.TabIndex = 15;
            this.lbl_red.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_color
            // 
            this.lbl_color.BackColor = System.Drawing.Color.White;
            this.lbl_color.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_color.Location = new System.Drawing.Point(139, 26);
            this.lbl_color.Name = "lbl_color";
            this.lbl_color.Size = new System.Drawing.Size(38, 67);
            this.lbl_color.TabIndex = 14;
//            this.lbl_color.Click += new System.EventHandler(this.lbl_color_Click);
            // 
            // lbl_main
            // 
            this.lbl_main.BackColor = System.Drawing.Color.White;
            this.lbl_main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_main.Location = new System.Drawing.Point(148, 130);
            this.lbl_main.Name = "lbl_main";
            this.lbl_main.Size = new System.Drawing.Size(205, 142);
            this.lbl_main.TabIndex = 25;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(509, 338);
            this.Controls.Add(this.lbl_main);
            this.Controls.Add(this.lbl_wheat);
            this.Controls.Add(this.lbl_brown);
            this.Controls.Add(this.lbl_silver);
            this.Controls.Add(this.lbl_white);
            this.Controls.Add(this.lbl_black);
            this.Controls.Add(this.lbl_pink);
            this.Controls.Add(this.lbl_orange);
            this.Controls.Add(this.lbl_blue);
            this.Controls.Add(this.lbl_green);
            this.Controls.Add(this.lbl_red);
            this.Controls.Add(this.lbl_color);
            this.Name = "Form2";
            this.Text = "colors";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_wheat;
        private System.Windows.Forms.Label lbl_brown;
        private System.Windows.Forms.Label lbl_silver;
        private System.Windows.Forms.Label lbl_white;
        private System.Windows.Forms.Label lbl_black;
        private System.Windows.Forms.Label lbl_pink;
        private System.Windows.Forms.Label lbl_orange;
        private System.Windows.Forms.Label lbl_blue;
        private System.Windows.Forms.Label lbl_green;
        private System.Windows.Forms.Label lbl_red;
        private System.Windows.Forms.Label lbl_color;
        private System.Windows.Forms.Label lbl_main;
    }
}