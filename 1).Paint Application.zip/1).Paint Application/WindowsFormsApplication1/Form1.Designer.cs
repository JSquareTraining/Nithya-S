﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbl_color = new System.Windows.Forms.Label();
            this.lbl_main = new System.Windows.Forms.Label();
            this.lbl_red = new System.Windows.Forms.Label();
            this.lbl_green = new System.Windows.Forms.Label();
            this.lbl_blue = new System.Windows.Forms.Label();
            this.lbl_orange = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_pink = new System.Windows.Forms.Label();
            this.lbl_black = new System.Windows.Forms.Label();
            this.lbl_white = new System.Windows.Forms.Label();
            this.lbl_silver = new System.Windows.Forms.Label();
            this.lbl_brown = new System.Windows.Forms.Label();
            this.lbl_wheat = new System.Windows.Forms.Label();
            this.lbl_gold = new System.Windows.Forms.Label();
            this.lbl_tan = new System.Windows.Forms.Label();
            this.lbl_lime = new System.Windows.Forms.Label();
            this.lbl_cyan = new System.Windows.Forms.Label();
            this.lbl_navy = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_color
            // 
            this.lbl_color.BackColor = System.Drawing.Color.White;
            this.lbl_color.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_color.Location = new System.Drawing.Point(691, 21);
            this.lbl_color.Name = "lbl_color";
            this.lbl_color.Size = new System.Drawing.Size(57, 80);
            this.lbl_color.TabIndex = 1;
            this.lbl_color.Click += new System.EventHandler(this.lbl_color_Click);
            // 
            // lbl_main
            // 
            this.lbl_main.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl_main.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_main.Location = new System.Drawing.Point(26, 142);
            this.lbl_main.Name = "lbl_main";
            this.lbl_main.Size = new System.Drawing.Size(829, 317);
            this.lbl_main.TabIndex = 2;
            // 
            // lbl_red
            // 
            this.lbl_red.BackColor = System.Drawing.Color.Red;
            this.lbl_red.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_red.Location = new System.Drawing.Point(754, 34);
            this.lbl_red.Name = "lbl_red";
            this.lbl_red.Size = new System.Drawing.Size(18, 18);
            this.lbl_red.TabIndex = 3;
            this.lbl_red.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_green
            // 
            this.lbl_green.BackColor = System.Drawing.Color.Green;
            this.lbl_green.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_green.Location = new System.Drawing.Point(778, 34);
            this.lbl_green.Name = "lbl_green";
            this.lbl_green.Size = new System.Drawing.Size(18, 18);
            this.lbl_green.TabIndex = 4;
            this.lbl_green.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_blue
            // 
            this.lbl_blue.BackColor = System.Drawing.Color.Blue;
            this.lbl_blue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_blue.Location = new System.Drawing.Point(802, 34);
            this.lbl_blue.Name = "lbl_blue";
            this.lbl_blue.Size = new System.Drawing.Size(18, 18);
            this.lbl_blue.TabIndex = 5;
            this.lbl_blue.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_orange
            // 
            this.lbl_orange.BackColor = System.Drawing.Color.Orange;
            this.lbl_orange.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_orange.Location = new System.Drawing.Point(826, 34);
            this.lbl_orange.Name = "lbl_orange";
            this.lbl_orange.Size = new System.Drawing.Size(18, 18);
            this.lbl_orange.TabIndex = 6;
            this.lbl_orange.Click += new System.EventHandler(this.lbl_clr);
            // 
            // label1
            // 
            this.label1.Image = ((System.Drawing.Image)(resources.GetObject("label1.Image")));
            this.label1.Location = new System.Drawing.Point(23, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(662, 105);
            this.label1.TabIndex = 7;
            // 
            // lbl_pink
            // 
            this.lbl_pink.BackColor = System.Drawing.Color.Pink;
            this.lbl_pink.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_pink.Location = new System.Drawing.Point(850, 34);
            this.lbl_pink.Name = "lbl_pink";
            this.lbl_pink.Size = new System.Drawing.Size(18, 18);
            this.lbl_pink.TabIndex = 8;
            this.lbl_pink.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_black
            // 
            this.lbl_black.BackColor = System.Drawing.Color.Black;
            this.lbl_black.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_black.Location = new System.Drawing.Point(754, 56);
            this.lbl_black.Name = "lbl_black";
            this.lbl_black.Size = new System.Drawing.Size(18, 18);
            this.lbl_black.TabIndex = 9;
            this.lbl_black.Text = "label2";
            this.lbl_black.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_white
            // 
            this.lbl_white.BackColor = System.Drawing.Color.White;
            this.lbl_white.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_white.Location = new System.Drawing.Point(778, 56);
            this.lbl_white.Name = "lbl_white";
            this.lbl_white.Size = new System.Drawing.Size(18, 18);
            this.lbl_white.TabIndex = 10;
            this.lbl_white.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_silver
            // 
            this.lbl_silver.BackColor = System.Drawing.Color.Silver;
            this.lbl_silver.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_silver.Location = new System.Drawing.Point(802, 56);
            this.lbl_silver.Name = "lbl_silver";
            this.lbl_silver.Size = new System.Drawing.Size(18, 18);
            this.lbl_silver.TabIndex = 11;
            this.lbl_silver.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_brown
            // 
            this.lbl_brown.BackColor = System.Drawing.Color.Brown;
            this.lbl_brown.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_brown.Location = new System.Drawing.Point(826, 56);
            this.lbl_brown.Name = "lbl_brown";
            this.lbl_brown.Size = new System.Drawing.Size(18, 18);
            this.lbl_brown.TabIndex = 12;
            this.lbl_brown.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_wheat
            // 
            this.lbl_wheat.BackColor = System.Drawing.Color.Wheat;
            this.lbl_wheat.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_wheat.Location = new System.Drawing.Point(850, 56);
            this.lbl_wheat.Name = "lbl_wheat";
            this.lbl_wheat.Size = new System.Drawing.Size(18, 18);
            this.lbl_wheat.TabIndex = 13;
            this.lbl_wheat.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_gold
            // 
            this.lbl_gold.BackColor = System.Drawing.Color.Gold;
            this.lbl_gold.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_gold.Location = new System.Drawing.Point(754, 83);
            this.lbl_gold.Name = "lbl_gold";
            this.lbl_gold.Size = new System.Drawing.Size(18, 18);
            this.lbl_gold.TabIndex = 14;
            this.lbl_gold.Click += new System.EventHandler(this.lbl_gold_Click);
            // 
            // lbl_tan
            // 
            this.lbl_tan.BackColor = System.Drawing.Color.Tan;
            this.lbl_tan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_tan.Location = new System.Drawing.Point(778, 83);
            this.lbl_tan.Name = "lbl_tan";
            this.lbl_tan.Size = new System.Drawing.Size(18, 18);
            this.lbl_tan.TabIndex = 15;
            this.lbl_tan.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_lime
            // 
            this.lbl_lime.BackColor = System.Drawing.Color.Lime;
            this.lbl_lime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_lime.Location = new System.Drawing.Point(802, 83);
            this.lbl_lime.Name = "lbl_lime";
            this.lbl_lime.Size = new System.Drawing.Size(18, 18);
            this.lbl_lime.TabIndex = 16;
            this.lbl_lime.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_cyan
            // 
            this.lbl_cyan.BackColor = System.Drawing.Color.Cyan;
            this.lbl_cyan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_cyan.Location = new System.Drawing.Point(826, 83);
            this.lbl_cyan.Name = "lbl_cyan";
            this.lbl_cyan.Size = new System.Drawing.Size(18, 18);
            this.lbl_cyan.TabIndex = 17;
            this.lbl_cyan.Click += new System.EventHandler(this.lbl_clr);
            // 
            // lbl_navy
            // 
            this.lbl_navy.BackColor = System.Drawing.Color.Navy;
            this.lbl_navy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_navy.Location = new System.Drawing.Point(850, 83);
            this.lbl_navy.Name = "lbl_navy";
            this.lbl_navy.Size = new System.Drawing.Size(18, 18);
            this.lbl_navy.TabIndex = 18;
            this.lbl_navy.Click += new System.EventHandler(this.lbl_clr);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Lavender;
            this.label2.Location = new System.Drawing.Point(775, 110);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 14);
            this.label2.TabIndex = 19;
            this.label2.Text = "   colors";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1033, 503);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_navy);
            this.Controls.Add(this.lbl_cyan);
            this.Controls.Add(this.lbl_lime);
            this.Controls.Add(this.lbl_tan);
            this.Controls.Add(this.lbl_gold);
            this.Controls.Add(this.lbl_wheat);
            this.Controls.Add(this.lbl_brown);
            this.Controls.Add(this.lbl_silver);
            this.Controls.Add(this.lbl_white);
            this.Controls.Add(this.lbl_black);
            this.Controls.Add(this.lbl_pink);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lbl_orange);
            this.Controls.Add(this.lbl_blue);
            this.Controls.Add(this.lbl_green);
            this.Controls.Add(this.lbl_red);
            this.Controls.Add(this.lbl_main);
            this.Controls.Add(this.lbl_color);
            this.Name = "Form1";
            this.Text = "paint";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Click += new System.EventHandler(this.lbl_clr);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_color;
        private System.Windows.Forms.Label lbl_main;
        private System.Windows.Forms.Label lbl_red;
        private System.Windows.Forms.Label lbl_green;
        private System.Windows.Forms.Label lbl_blue;
        private System.Windows.Forms.Label lbl_orange;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_pink;
        private System.Windows.Forms.Label lbl_black;
        private System.Windows.Forms.Label lbl_white;
        private System.Windows.Forms.Label lbl_silver;
        private System.Windows.Forms.Label lbl_brown;
        private System.Windows.Forms.Label lbl_wheat;
        private System.Windows.Forms.Label lbl_gold;
        private System.Windows.Forms.Label lbl_tan;
        private System.Windows.Forms.Label lbl_lime;
        private System.Windows.Forms.Label lbl_cyan;
        private System.Windows.Forms.Label lbl_navy;
        private System.Windows.Forms.Label label2;
    }
}

