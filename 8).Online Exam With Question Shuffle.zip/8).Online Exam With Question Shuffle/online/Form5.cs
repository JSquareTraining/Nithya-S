﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace online
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {

        }
        //if (checkBox16.Checked == true && checkBox17.Checked == true && checkBox18.Checked != true)
        //{
        //    if (checkBox1.Checked == true)
        //    {
        //        lbl5.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl5.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox2.Checked == true)
        //    {
        //        lbl6.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl6.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox3.Checked == true)
        //    {
        //        lbl7.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl7.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox4.Checked == true)
        //    {
        //        lbl8.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl8.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox5.Checked == true)
        //    {
        //        lbl9.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl9.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox6.Checked == true)
        //    {
        //        lbl10.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl10.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox7.Checked == true)
        //    {
        //        lbl11.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl11.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox8.Checked == true)
        //    {
        //        lbl12.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl12.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox9.Checked == true)
        //    {
        //        lbl13.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl13.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox10.Checked == true)
        //    {
        //        lbl14.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl14.BackColor = System.Drawing.Color.Red;
        //    }
        //}
        //if (checkBox16.Checked != true && checkBox17.Checked == true && checkBox18.Checked == true)
        //{
        //    if (checkBox6.Checked == true)
        //    {
        //        lbl10.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl10.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox7.Checked == true)
        //    {
        //        lbl11.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl11.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox8.Checked == true)
        //    {
        //        lbl12.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl12.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox9.Checked == true)
        //    {
        //        lbl13.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl13.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox10.Checked == true)
        //    {
        //        lbl14.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl14.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox11.Checked == true)
        //    {
        //        lbl15.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl15.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox12.Checked == true)
        //    {
        //        lbl16.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl16.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox13.Checked == true)
        //    {
        //        lbl17.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl17.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox14.Checked == true)
        //    {
        //        lbl18.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl18.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox15.Checked == true)
        //    {
        //        lbl19.BackColor = System.Drawing.Color.Green;
        //    }
        //    else
        //    {
        //        lbl19.BackColor = System.Drawing.Color.Red;
        //    }
        //    if (checkBox16.Checked = true && checkBox17.Checked == true && checkBox18.Checked == true)
        //    {
        //        if (checkBox1.Checked == true)
        //        {
        //            lbl5.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl5.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox2.Checked == true)
        //        {
        //            lbl6.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl6.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox3.Checked == true)
        //        {
        //            lbl7.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl7.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox4.Checked == true)
        //        {
        //            lbl8.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl8.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox5.Checked == true)
        //        {
        //            lbl9.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl9.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox6.Checked == true)
        //        {
        //            lbl10.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl10.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox7.Checked == true)
        //        {
        //            lbl11.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl11.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox8.Checked == true)
        //        {
        //            lbl12.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl12.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox9.Checked == true)
        //        {
        //            lbl13.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl13.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox10.Checked == true)
        //        {
        //            lbl14.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl14.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox11.Checked == true)
        //        {
        //            lbl15.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl15.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox12.Checked == true)
        //        {
        //            lbl16.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl16.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox13.Checked == true)
        //        {
        //            lbl17.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl17.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox14.Checked == true)
        //        {
        //            lbl18.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl18.BackColor = System.Drawing.Color.Red;
        //        }
        //        if (checkBox15.Checked == true)
        //        {
        //            lbl19.BackColor = System.Drawing.Color.Green;
        //        }
        //        else
        //        {
        //            lbl19.BackColor = System.Drawing.Color.Red;
        //        }











        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

            if (checkBox16.Checked == true && checkBox17.Checked != true && checkBox18.Checked != true)
            {
                if (checkBox1.Checked == true)
                {
                    lbl5.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl5.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox2.Checked == true)
                {
                    lbl6.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl6.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox3.Checked == true)
                {
                    lbl7.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl7.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox4.Checked == true)
                {
                    lbl8.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl8.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox5.Checked == true)
                {
                    lbl9.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl9.BackColor = System.Drawing.Color.Red;
                }
            }
            if (checkBox16.Checked != true && checkBox17.Checked == true && checkBox18.Checked != true)
            {
                if (checkBox6.Checked == true)
                {
                    lbl10.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl10.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox7.Checked == true)
                {
                    lbl11.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl11.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox8.Checked == true)
                {
                    lbl12.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl12.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox9.Checked == true)
                {
                    lbl13.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl13.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox10.Checked == true)
                {
                    lbl14.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl14.BackColor = System.Drawing.Color.Red;
                }
            }
            if (checkBox16.Checked != true && checkBox17.Checked != true && checkBox18.Checked == true)
            {
                if (checkBox11.Checked == true)
                {
                    lbl15.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl15.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox12.Checked == true)
                {
                    lbl16.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl16.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox13.Checked == true)
                {
                    lbl17.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl17.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox14.Checked == true)
                {
                    lbl18.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl18.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox15.Checked == true)
                {
                    lbl19.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl19.BackColor = System.Drawing.Color.Red;
                }
            }
            if (checkBox16.Checked == true && checkBox17.Checked == true && checkBox18.Checked != true)
            {
                if (checkBox1.Checked == true)
                {
                    lbl5.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl5.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox2.Checked == true)
                {
                    lbl6.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl6.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox3.Checked == true)
                {
                    lbl7.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl7.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox4.Checked == true)
                {
                    lbl8.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl8.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox5.Checked == true)
                {
                    lbl9.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl9.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox6.Checked == true)
                {
                    lbl10.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl10.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox7.Checked == true)
                {
                    lbl11.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl11.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox8.Checked == true)
                {
                    lbl12.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl12.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox9.Checked == true)
                {
                    lbl13.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl13.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox10.Checked == true)
                {
                    lbl14.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl14.BackColor = System.Drawing.Color.Red;
                }
            }
            if (checkBox16.Checked != true && checkBox17.Checked == true && checkBox18.Checked == true)
            {
                if (checkBox6.Checked == true)
                {
                    lbl10.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl10.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox7.Checked == true)
                {
                    lbl11.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl11.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox8.Checked == true)
                {
                    lbl12.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl12.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox9.Checked == true)
                {
                    lbl13.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl13.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox10.Checked == true)
                {
                    lbl14.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl14.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox11.Checked == true)
                {
                    lbl15.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl15.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox12.Checked == true)
                {
                    lbl16.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl16.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox13.Checked == true)
                {
                    lbl17.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl17.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox14.Checked == true)
                {
                    lbl18.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl18.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox15.Checked == true)
                {
                    lbl19.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl19.BackColor = System.Drawing.Color.Red;
                }
            }
           if (checkBox16.Checked == true && checkBox17.Checked != true && checkBox18.Checked == true)
            {
                if (checkBox1.Checked == true)
                {
                    lbl5.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl5.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox2.Checked == true)
                {
                    lbl6.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl6.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox3.Checked == true)
                {
                    lbl7.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl7.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox4.Checked == true)
                {
                    lbl8.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl8.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox5.Checked == true)
                {
                    lbl9.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl9.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox11.Checked == true)
                {
                    lbl15.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl15.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox12.Checked == true)
                {
                    lbl16.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl16.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox13.Checked == true)
                {
                    lbl17.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl17.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox14.Checked == true)
                {
                    lbl18.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl18.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox15.Checked == true)
                {
                    lbl19.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl19.BackColor = System.Drawing.Color.Red;
                }
            }
            if (checkBox16.Checked == true && checkBox17.Checked == true && checkBox18.Checked == true)
            {
                if (checkBox1.Checked == true)
                {
                    lbl5.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl5.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox2.Checked == true)
                {
                    lbl6.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl6.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox3.Checked == true)
                {
                    lbl7.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl7.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox4.Checked == true)
                {
                    lbl8.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl8.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox5.Checked == true)
                {
                    lbl9.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl9.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox6.Checked == true)
                {
                    lbl10.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl10.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox7.Checked == true)
                {
                    lbl11.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl11.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox8.Checked == true)
                {
                    lbl12.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl12.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox9.Checked == true)
                {
                    lbl13.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl13.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox10.Checked == true)
                {
                    lbl14.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl14.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox11.Checked == true)
                {
                    lbl15.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl15.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox12.Checked == true)
                {
                    lbl16.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl16.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox13.Checked == true)
                {
                    lbl17.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl17.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox14.Checked == true)
                {
                    lbl18.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl18.BackColor = System.Drawing.Color.Red;
                }
                if (checkBox15.Checked == true)
                {
                    lbl19.BackColor = System.Drawing.Color.Green;
                }
                else
                {
                    lbl19.BackColor = System.Drawing.Color.Red;
                }
            }
            
        }

     
    }
}

            
        
    
