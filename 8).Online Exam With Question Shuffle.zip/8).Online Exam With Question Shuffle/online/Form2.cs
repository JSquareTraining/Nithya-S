﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;

namespace online
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

              
        Properties.Settings ps = new Properties.Settings();
        ResourceManager or = new ResourceManager("online.Properties.Resources", Assembly.GetExecutingAssembly());


        private void Form2_Load(object sender, EventArgs e)
        {
            if (ps.couple == 1)
            {
                groupBox1.Text = or.GetString("q1");
                radioButton1.Text = or.GetString("r1");
                radioButton2.Text = or.GetString("r2");
                radioButton3.Text = or.GetString("r3");
                radioButton4.Text = or.GetString("r4");
                groupBox2.Text = or.GetString("q2");
                radioButton5.Text = or.GetString("r5");
                radioButton6.Text = or.GetString("r6");
                radioButton7.Text = or.GetString("r7");
                radioButton8.Text = or.GetString("r8");
                groupBox3.Text = or.GetString("q3");
                radioButton9.Text = or.GetString("r9");
                radioButton10.Text = or.GetString("r10");
                radioButton11.Text = or.GetString("r11");
                radioButton12.Text = or.GetString("r12");
                groupBox4.Text = or.GetString("q4");
                radioButton13.Text = or.GetString("r13");
                radioButton14.Text = or.GetString("r14");
                radioButton15.Text = or.GetString("r15");
                radioButton16.Text = or.GetString("r16");
                groupBox5.Text = or.GetString("q5");
                radioButton17.Text = or.GetString("r17");
                radioButton18.Text = or.GetString("r18");
                radioButton19.Text = or.GetString("r19");
                radioButton20.Text = or.GetString("r20");
                               
            }
            else if (ps.couple == 2)
            {
                groupBox1.Text = or.GetString("q6");
                radioButton1.Text = or.GetString("r21");
                radioButton2.Text = or.GetString("r22");
                radioButton3.Text = or.GetString("r23");
                radioButton4.Text = or.GetString("r24");
                groupBox2.Text = or.GetString("q7");
                radioButton5.Text = or.GetString("r25");
                radioButton6.Text = or.GetString("r26");
                radioButton7.Text = or.GetString("r27");
                radioButton8.Text = or.GetString("r28");
                groupBox3.Text = or.GetString("q8");
                radioButton9.Text = or.GetString("r29");
                radioButton10.Text = or.GetString("r30");
                radioButton11.Text = or.GetString("r31");
                radioButton12.Text = or.GetString("r32");
                groupBox4.Text = or.GetString("q9");
                radioButton13.Text = or.GetString("r33");
                radioButton14.Text = or.GetString("r34");
                radioButton15.Text = or.GetString("r35");
                radioButton16.Text = or.GetString("r36");
                groupBox5.Text = or.GetString("q10");
                radioButton17.Text = or.GetString("r37");
                radioButton18.Text = or.GetString("r38");
                radioButton19.Text = or.GetString("r39");
                radioButton20.Text = or.GetString("r40");
                             
            }
            else if (ps.couple == 3)
            {
                groupBox1.Text = or.GetString("q11");
                radioButton1.Text = or.GetString("r41");
                radioButton2.Text = or.GetString("r42");
                radioButton3.Text = or.GetString("r43");
                radioButton4.Text = or.GetString("r44");
                groupBox2.Text = or.GetString("q12");
                radioButton5.Text = or.GetString("r45");
                radioButton6.Text = or.GetString("r46");
                radioButton7.Text = or.GetString("r47");
                radioButton8.Text = or.GetString("r48");
                groupBox3.Text = or.GetString("q13");
                radioButton9.Text = or.GetString("r49");
                radioButton10.Text = or.GetString("r50");
                radioButton11.Text = or.GetString("r51");
                radioButton12.Text = or.GetString("r52");
                 groupBox4.Text = or.GetString("q14");
                radioButton13.Text = or.GetString("r53");
                radioButton14.Text = or.GetString("r54");
                radioButton15.Text = or.GetString("r55");
                radioButton16.Text = or.GetString("r56");
                groupBox5.Text = or.GetString("q15");
                radioButton17.Text = or.GetString("r57");
                radioButton18.Text = or.GetString("r58");
                radioButton19.Text = or.GetString("r59");
                radioButton20.Text = or.GetString("r60");


                
               // ps.couple = 1;
               // ps.Save();
            }

                        

        }


        private void btn2_Click(object sender, EventArgs e)
        {

            {
                if (radioButton1.Checked != true && radioButton2.Checked != true && radioButton3.Checked != true && radioButton4.Checked != true)
                {
                    MessageBox.Show("please answer question no 1");
                }


                if (radioButton5.Checked != true && radioButton6.Checked != true && radioButton7.Checked != true && radioButton8.Checked != true)
                {
                    MessageBox.Show("please answer question no 2");


                }


                if (radioButton9.Checked != true && radioButton10.Checked != true && radioButton11.Checked != true && radioButton12.Checked != true)
                {
                    MessageBox.Show("please answer question no 3");

                }

                if (radioButton13.Checked != true && radioButton14.Checked != true && radioButton15.Checked != true && radioButton16.Checked != true)
                {
                    MessageBox.Show("please answer question no 4");

                }
                if (radioButton17.Checked != true && radioButton18.Checked != true && radioButton19.Checked != true && radioButton20.Checked != true)
                {
                    MessageBox.Show("please answer question no 5");
                }

            }

            if (ps.couple == 1)
            {
                foreach (RadioButton rdb1 in groupBox1.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r1"))
                        {
                            checkBox4.Checked = true;
                        }
                        else
                        {
                            checkBox4.Checked = false;
                        }
                    }
                }

                foreach (RadioButton rdb1 in groupBox2.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r6"))
                        {
                            checkBox5.Checked = true;
                        }
                        else
                        {
                            checkBox5.Checked = false;
                        }
                    }
                }


                foreach (RadioButton rdb1 in groupBox3.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r11"))
                        {
                            checkBox6.Checked = true;
                        }
                        else
                        {
                            checkBox6.Checked = false;
                        }
                    }
                }

                foreach (RadioButton rdb1 in groupBox4.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r14"))
                        {
                            checkBox7.Checked = true;
                        }
                        else
                        {
                            checkBox7.Checked = false;
                        }
                    }
                }




                foreach (RadioButton rdb1 in groupBox5.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r17"))
                        {
                            checkBox8.Checked = true;
                        }
                        else
                        {
                            checkBox8.Checked = false;
                        }
                    }
                }
                ps.couple = 2;
                ps.Save();
            }
            else if (ps.couple == 2)
            {
                foreach (RadioButton rdb1 in groupBox1.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r21"))
                        {
                            checkBox4.Checked = true;
                        }
                        else
                        {
                            checkBox4.Checked = false;
                        }
                    }
                }


                foreach (RadioButton rdb1 in groupBox2.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r27"))
                        {
                            checkBox5.Checked = true;
                        }
                        else
                        {
                            checkBox5.Checked = false;
                        }
                    }
                }

                foreach (RadioButton rdb1 in groupBox3.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r29"))
                        {
                            checkBox6.Checked = true;
                        }
                        else
                        {
                            checkBox6.Checked = false;
                        }
                    }
                }

                foreach (RadioButton rdb1 in groupBox4.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r33"))
                        {
                            checkBox7.Checked = true;
                        }
                        else
                        {
                            checkBox7.Checked = false;
                        }
                    }
                }


                foreach (RadioButton rdb1 in groupBox5.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r38"))
                        {
                            checkBox8.Checked = true;
                        }
                        else
                        {
                            checkBox8.Checked = false;
                        }
                    }
                }

                ps.couple = 3;
                ps.Save();


            }
            else if (ps.couple == 3)
            {
                foreach (RadioButton rdb1 in groupBox1.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r44"))
                        {
                            checkBox4.Checked = true;
                        }
                        else
                        {
                            checkBox4.Checked = false;
                        }
                    }
                }

                foreach (RadioButton rdb1 in groupBox2.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r45"))
                        {
                            checkBox5.Checked = true;
                        }
                        else
                        {
                            checkBox5.Checked = false;
                        }
                    }
                }

                foreach (RadioButton rdb1 in groupBox3.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r51"))
                        {
                            checkBox6.Checked = true;
                        }
                        else
                        {
                            checkBox6.Checked = false;
                        }
                    }
                }

                foreach (RadioButton rdb1 in groupBox4.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r54"))
                        {
                            checkBox7.Checked = true;
                        }
                        else
                        {
                            checkBox7.Checked = false;
                        }
                    }
                }

                foreach (RadioButton rdb1 in groupBox5.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == or.GetString("r58"))
                        {
                            checkBox8.Checked = true;
                        }
                        else
                        {
                            checkBox8.Checked = false;
                        }
                    }
                }
                ps.couple = 1;
                ps.Save();
            }

            if (checkBox1.Checked == true && checkBox2.Checked != true && checkBox3.Checked != true)
            {
                Form5 f3 = new Form5();
                f3.textBox1.Text = textBox1.Text;
                f3.checkBox16.Checked = checkBox1.Checked;
                f3.checkBox17.Checked = checkBox2.Checked;
                f3.checkBox18.Checked = checkBox3.Checked;
                f3.checkBox1.Checked = checkBox4.Checked;
                f3.checkBox2.Checked = checkBox5.Checked;
                f3.checkBox3.Checked = checkBox6.Checked;
                f3.checkBox4.Checked = checkBox7.Checked;
                f3.checkBox5.Checked = checkBox8.Checked;
                f3.ShowDialog();

            }
            if (checkBox1.Checked != true && checkBox2.Checked != true && checkBox3.Checked == true)
            {
                Form4 f3 = new Form4();
                f3.textBox1.Text = textBox1.Text;
                f3.checkBox1.Checked = checkBox1.Checked;
                f3.checkBox2.Checked = checkBox2.Checked;
                f3.checkBox3.Checked = checkBox3.Checked;
                //f3.checkBox9.Checked = checkBox4.Checked;
                //f3.checkBox10.Checked = checkBox5.Checked;
                //f3.checkBox11.Checked = checkBox6.Checked;
                //f3.checkBox12.Checked = checkBox7.Checked;
                //f3.checkBox13.Checked = checkBox8.Checked;
                f3.ShowDialog();
            }
            //if (checkBox2.Checked == true && checkBox1.Checked != true && checkBox3.Checked != true)
            //{
            //    Form3 f3 = new Form3();
            //    f3.textBox1.Text = textBox1.Text;
            //    f3.checkBox9.Checked = checkBox4.Checked;
            //    f3.checkBox10.Checked = checkBox5.Checked;
            //    f3.checkBox11.Checked = checkBox6.Checked;
            //    f3.checkBox12.Checked = checkBox7.Checked;
            //    f3.checkBox13.Checked = checkBox8.Checked;
            //    f3.ShowDialog();

            // }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked != true)
            {
                Form3 f4 = new Form3();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.checkBox9.Checked = checkBox4.Checked;
                f4.checkBox10.Checked = checkBox5.Checked;
                f4.checkBox11.Checked = checkBox6.Checked;
                f4.checkBox12.Checked = checkBox7.Checked;
                f4.checkBox13.Checked = checkBox8.Checked;
                f4.ShowDialog();
                f4.Close();


            }
            if (checkBox1.Checked == true && checkBox2.Checked != true && checkBox3.Checked == true)
            {
                Form4 f4 = new Form4();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.checkBox9.Checked = checkBox4.Checked;
                f4.checkBox10.Checked = checkBox5.Checked;
                f4.checkBox11.Checked = checkBox6.Checked;
                f4.checkBox12.Checked = checkBox7.Checked;
                f4.checkBox13.Checked = checkBox8.Checked;
                f4.ShowDialog();
                f4.Close();
            }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                Form3 f4 = new Form3();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.checkBox9.Checked = checkBox4.Checked;
                f4.checkBox10.Checked = checkBox5.Checked;
                f4.checkBox11.Checked = checkBox6.Checked;
                f4.checkBox12.Checked = checkBox7.Checked;
                f4.checkBox13.Checked = checkBox8.Checked;
                f4.ShowDialog();
                f4.Close();
            }
            if (checkBox1.Checked != true && checkBox2.Checked == true && checkBox3.Checked != true)
            {
                Form3 f3 = new Form3();
                f3.textBox1.Text = textBox1.Text;
                f3.checkBox1.Checked = checkBox1.Checked;
                f3.checkBox2.Checked = checkBox2.Checked;
                f3.checkBox3.Checked = checkBox3.Checked;
                f3.ShowDialog();
            }
            if (checkBox1.Checked != true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                Form3 f3 = new Form3();
                f3.textBox1.Text = textBox1.Text;
                f3.checkBox1.Checked = checkBox1.Checked;
                f3.checkBox2.Checked = checkBox2.Checked;
                f3.checkBox3.Checked = checkBox3.Checked;
                f3.ShowDialog();


            }

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

    }
  }
        
    






    

