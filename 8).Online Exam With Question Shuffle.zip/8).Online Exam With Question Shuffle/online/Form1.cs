﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace online
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btn1_Click(object sender, EventArgs e)
        { 
            if (textBox1.Text == "")
            {
                MessageBox.Show("enter your name");
                Form1 nn = new Form1();
                nn.ShowDialog();
            }
            if (textBox1.Text != "")
            {
                Form5 f5 = new Form5();
                f5.textBox1.Text = textBox1.Text;

            }
            
             if ((checkBox1.CheckState != CheckState.Checked && checkBox2.CheckState != CheckState.Checked && checkBox3.CheckState != CheckState.Checked))
            {
                MessageBox.Show("please select any subject");
            }
            
            if (checkBox1.Checked == true && checkBox2.Checked != true && checkBox3.Checked != true)
            {
                Form2 f2 = new Form2();
                f2.textBox1.Text = textBox1.Text;
                f2.checkBox1.Checked = checkBox1.Checked;
                f2.checkBox2.Checked = checkBox2.Checked;
                f2.checkBox3.Checked = checkBox3.Checked;
                f2.ShowDialog();
                f2.Close();
            }
            if (checkBox2.Checked == true && checkBox1.Checked!= true && checkBox3.Checked!= true)
            {
                Form3 f3 = new Form3();
                f3.textBox1.Text = textBox1.Text;
                f3.checkBox1.Checked = checkBox1.Checked;
                f3.checkBox2.Checked = checkBox2.Checked;
                f3.checkBox3.Checked = checkBox3.Checked;
                f3.ShowDialog();
                f3.Close();
            }
            if (checkBox3.Checked == true && checkBox1.Checked != true && checkBox2.Checked != true)
            {
                Form4 f4 = new Form4();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.ShowDialog();
                f4.Close();
            }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked != true)
            {
                Form2 f4 = new Form2();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.ShowDialog();
                f4.Close();
            }
            if (checkBox1.Checked == true && checkBox2.Checked != true && checkBox3.Checked == true)
            {
                Form2 f4 = new Form2();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.ShowDialog();
                f4.Close();
            }
            if (checkBox1.Checked != true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                Form3 f4 = new Form3();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.ShowDialog();
                f4.Close();
            }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                Form2 f4 = new Form2();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.ShowDialog();
                f4.Close();
            }
           this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("ALL THE BEST FOR YOUR ONLINE EXAMINATION");
        }
  }
 }

