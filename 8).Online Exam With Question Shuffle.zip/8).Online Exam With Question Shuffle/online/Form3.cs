﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;


namespace online
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        Properties.Settings pp = new Properties.Settings();
        ResourceManager r = new ResourceManager("online.f2", Assembly.GetExecutingAssembly());


        private void Form3_Load(object sender, EventArgs e)
        {
            if (pp.sub == 1)
            {
                groupBox1.Text = r.GetString("q1");
                radioButton1.Text = r.GetString("r1");
                radioButton2.Text = r.GetString("r2");
                radioButton3.Text = r.GetString("r3");
                radioButton4.Text = r.GetString("r4");


                groupBox2.Text = r.GetString("q2");
                radioButton5.Text = r.GetString("r5");
                radioButton6.Text = r.GetString("r6");
                radioButton7.Text = r.GetString("r7");
                radioButton8.Text = r.GetString("r8");

                groupBox3.Text = r.GetString("q3");
                radioButton9.Text = r.GetString("r9");
                radioButton10.Text = r.GetString("r10");
                radioButton11.Text = r.GetString("r11");
                radioButton12.Text = r.GetString("r12");

                groupBox4.Text = r.GetString("q4");
                radioButton13.Text = r.GetString("r13");
                radioButton14.Text = r.GetString("r14");
                radioButton15.Text = r.GetString("r15");
                radioButton16.Text = r.GetString("r16");


                groupBox5.Text = r.GetString("q5");
                radioButton17.Text = r.GetString("r17");
                radioButton18.Text = r.GetString("r18");
                radioButton19.Text = r.GetString("r19");
                radioButton20.Text = r.GetString("r20");
           }
            else if (pp.sub == 2)
            {
                groupBox1.Text = r.GetString("q6");
                radioButton1.Text = r.GetString("r21");
                radioButton2.Text = r.GetString("r22");
                radioButton3.Text = r.GetString("r23");
                radioButton4.Text = r.GetString("r24");


                groupBox2.Text = r.GetString("q7");
                radioButton5.Text = r.GetString("r25");
                radioButton6.Text = r.GetString("r26");
                radioButton7.Text = r.GetString("r27");
                radioButton8.Text = r.GetString("r28");

                groupBox3.Text = r.GetString("q8");
                radioButton9.Text = r.GetString("r29");
                radioButton10.Text = r.GetString("r30");
                radioButton11.Text = r.GetString("r31");
                radioButton12.Text = r.GetString("r32");

                groupBox4.Text = r.GetString("q9");
                radioButton13.Text = r.GetString("r33");
                radioButton14.Text = r.GetString("r34");
                radioButton15.Text = r.GetString("r35");
                radioButton16.Text = r.GetString("r36");

                groupBox5.Text = r.GetString("q10");
                radioButton17.Text = r.GetString("r37");
                radioButton18.Text = r.GetString("r38");
                radioButton19.Text = r.GetString("r39");
                radioButton20.Text = r.GetString("r40");

            }
            else if (pp.sub == 3)
            {
                groupBox1.Text = r.GetString("q11");
                radioButton1.Text = r.GetString("r41");
                radioButton2.Text = r.GetString("r42");
                radioButton3.Text = r.GetString("r43");
                radioButton4.Text = r.GetString("r44");

                groupBox2.Text = r.GetString("q12");
                radioButton5.Text = r.GetString("r45");
                radioButton6.Text = r.GetString("r46");
                radioButton7.Text = r.GetString("r47");
                radioButton8.Text = r.GetString("r48");

                groupBox3.Text = r.GetString("q13");
                radioButton9.Text = r.GetString("r49");
                radioButton10.Text = r.GetString("r50");
                radioButton11.Text = r.GetString("r51");
                radioButton12.Text = r.GetString("r52");

                groupBox4.Text = r.GetString("q14");
                radioButton13.Text = r.GetString("r53");
                radioButton14.Text = r.GetString("r54");
                radioButton15.Text = r.GetString("r55");
                radioButton16.Text = r.GetString("r56");

                groupBox5.Text = r.GetString("q15");
                radioButton17.Text = r.GetString("r57");
                radioButton18.Text = r.GetString("r58");
                radioButton19.Text = r.GetString("r59");
                radioButton20.Text = r.GetString("r60");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {


                if (radioButton1.Checked != true && radioButton2.Checked != true && radioButton3.Checked != true && radioButton4.Checked != true)
                {
                    MessageBox.Show("please answer question no 1");
                }


                if (radioButton5.Checked != true && radioButton6.Checked != true && radioButton7.Checked != true && radioButton8.Checked != true)
                {
                    MessageBox.Show("please answer question no 2");

                }


                if (radioButton9.Checked != true && radioButton10.Checked != true && radioButton11.Checked != true && radioButton12.Checked != true)
                {
                    MessageBox.Show("please answer question no 3");

                }

                if (radioButton13.Checked != true && radioButton14.Checked != true && radioButton15.Checked != true && radioButton16.Checked != true)
                {
                    MessageBox.Show("please answer question no 4");

                }
                if (radioButton17.Checked != true && radioButton18.Checked != true && radioButton19.Checked != true && radioButton20.Checked != true)
                {
                    MessageBox.Show("please answer question no 5");

                }
            }
                
             
               if (pp.sub == 1)
                {
                    foreach (RadioButton rdb1 in groupBox1.Controls)
                    {
                        if (rdb1.Checked == true)
                        {
                            if (rdb1.Text == r.GetString("r1"))
                            {
                                checkBox4.Checked = true;
                            }
                            else
                            {
                                checkBox4.Checked = false;
                            }
                        }
                    }



                    foreach (RadioButton rdb2 in groupBox2.Controls)
                    {
                        if (rdb2.Checked == true)
                        {
                            if (rdb2.Text == r.GetString("r5"))
                            {
                                checkBox5.Checked = true;
                            }
                            else
                            {
                                checkBox5.Checked = false;
                            }
                        }

                    }



                    foreach (RadioButton rdb3 in groupBox3.Controls)
                    {
                        if (rdb3.Checked == true)
                        {
                            if (rdb3.Text == r.GetString("r11"))
                            {
                                checkBox6.Checked = true;
                            }
                            else
                            {
                                checkBox6.Checked = false;
                            }
                        }
                    }




                    foreach (RadioButton rdb4 in groupBox4.Controls)
                    {
                        if (rdb4.Checked == true)
                        {
                            if (rdb4.Text == r.GetString("r14"))
                            {
                                checkBox7.Checked = true;
                            }
                            else
                            {
                                checkBox7.Checked = false;
                            }
                        }

                    }


                    foreach (RadioButton rdb5 in groupBox5.Controls)
                    {
                        if (rdb5.Checked == true)
                        {
                            if (rdb5.Text == r.GetString("r18"))
                            {
                                checkBox8.Checked = true;
                            }
                            else
                            {
                                checkBox8.Checked = false;
                            }

                        }

                    }
                    pp.sub = 2;
                    pp.Save();

                }

                else if (pp.sub == 2)
                {
                    foreach (RadioButton rdb1 in groupBox1.Controls)
                    {
                        if (rdb1.Checked == true)
                        {
                            if (rdb1.Text == r.GetString("r22"))
                            {
                                checkBox4.Checked = true;
                            }
                            else
                            {
                                checkBox4.Checked = false;
                            }

                        }

                    }

                    foreach (RadioButton rdb2 in groupBox2.Controls)
                    {
                        if (rdb2.Checked == true)
                        {
                            if (rdb2.Text == r.GetString("r26"))
                            {
                                checkBox5.Checked = true;
                            }
                            else
                            {
                                checkBox5.Checked = false;
                            }

                        }

                    }
                    foreach (RadioButton rdb3 in groupBox3.Controls)
                    {
                        if (rdb3.Checked == true)
                        {
                            if (rdb3.Text == r.GetString("r31"))
                            {
                                checkBox6.Checked = true;
                            }
                            else
                            {
                                checkBox6.Checked = false;
                            }

                        }

                    }


                    foreach (RadioButton rdb4 in groupBox4.Controls)
                    {
                        if (rdb4.Checked == true)
                        {
                            if (rdb4.Text == r.GetString("r33"))
                            {
                                checkBox7.Checked = true;
                            }
                            else
                            {
                                checkBox7.Checked = false;
                            }

                        }

                    }

                    foreach (RadioButton rdb5 in groupBox5.Controls)
                    {
                        if (rdb5.Checked == true)
                        {
                            if (rdb5.Text == r.GetString("r37"))
                            {
                                checkBox8.Checked = true;
                            }
                            else
                            {
                                checkBox8.Checked = false;
                            }

                        }

                    }
                    pp.sub = 3;
                    pp.Save();
                }
                else if (pp.sub == 3)
                {
                    foreach (RadioButton rdb1 in groupBox1.Controls)
                    {
                        if (rdb1.Checked == true)
                        {
                            if (rdb1.Text == r.GetString("r42"))
                            {
                                checkBox4.Checked = true;
                            }
                            else
                            {
                                checkBox4.Checked = false;
                            }

                        }

                    }
                    foreach (RadioButton rdb2 in groupBox2.Controls)
                    {
                        if (rdb2.Checked == true)
                        {
                            if (rdb2.Text == r.GetString("r45"))
                            {
                                checkBox5.Checked = true;
                            }
                            else
                            {
                                checkBox5.Checked = false;
                            }

                        }

                    }
                    foreach (RadioButton rdb3 in groupBox3.Controls)
                    {
                        if (rdb3.Checked == true)
                        {
                            if (rdb3.Text == r.GetString("r51"))
                            {
                                checkBox6.Checked = true;
                            }
                            else
                            {
                                checkBox6.Checked = false;
                            }

                        }

                    }
                    foreach (RadioButton rdb4 in groupBox4.Controls)
                    {
                        if (rdb4.Checked == true)
                        {
                            if (rdb4.Text == r.GetString("r54"))
                            {
                                checkBox7.Checked = true;
                            }
                            else
                            {
                                checkBox7.Checked = false;
                            }

                        }

                    }
                    foreach (RadioButton rdb5 in groupBox5.Controls)
                    {
                        if (rdb5.Checked == true)
                        {
                            if (rdb5.Text == "r58")
                            {
                                checkBox8.Checked = true;
                            }
                            else
                            {
                                checkBox8.Checked = false;
                            }

                        }

                    }

                    pp.sub = 1;
                    pp.Save();
                }
    
            if (checkBox1.Checked != true && checkBox2.Checked == true && checkBox3.Checked != true)
            {
                Form5 f5 = new Form5();
                f5.textBox1.Text = textBox1.Text;
                f5.checkBox16.Checked = checkBox1.Checked;
                f5.checkBox17.Checked = checkBox2.Checked;
                f5.checkBox18.Checked = checkBox3.Checked;
                f5.checkBox6.Checked = checkBox4.Checked;
                f5.checkBox7.Checked = checkBox5.Checked;
                f5.checkBox8.Checked = checkBox6.Checked;
                f5.checkBox9.Checked = checkBox7.Checked;
                f5.checkBox10.Checked = checkBox8.Checked;
                f5.ShowDialog();
                f5.Close();
            }

            if (checkBox1.Checked != true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                Form4 f4 = new Form4();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.checkBox14.Checked = checkBox4.Checked;
                f4.checkBox15.Checked = checkBox5.Checked;
                f4.checkBox16.Checked = checkBox6.Checked;
                f4.checkBox17.Checked = checkBox7.Checked;
                f4.checkBox18.Checked = checkBox8.Checked;
                f4.ShowDialog();
                f4.Close();
            }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                Form4 f4 = new Form4();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.checkBox9.Checked = checkBox9.Checked;
                f4.checkBox10.Checked = checkBox10.Checked;
                f4.checkBox11.Checked = checkBox11.Checked;
                f4.checkBox12.Checked = checkBox12.Checked;
                f4.checkBox13.Checked = checkBox13.Checked;
                f4.checkBox14.Checked = checkBox4.Checked;
                f4.checkBox15.Checked = checkBox5.Checked;
                f4.checkBox16.Checked = checkBox6.Checked;
                f4.checkBox17.Checked = checkBox7.Checked;
                f4.checkBox18.Checked = checkBox8.Checked;
                f4.ShowDialog();
                f4.Close();
            }

            if (checkBox1.Checked == true && checkBox2.Checked != true && checkBox3.Checked == true)
            {
                Form4 f4 = new Form4();
                f4.textBox1.Text = textBox1.Text;
                f4.checkBox1.Checked = checkBox1.Checked;
                f4.checkBox2.Checked = checkBox2.Checked;
                f4.checkBox3.Checked = checkBox3.Checked;
                f4.checkBox9.Checked = checkBox9.Checked;
                f4.checkBox10.Checked = checkBox10.Checked;
                f4.checkBox11.Checked = checkBox11.Checked;
                f4.checkBox12.Checked = checkBox12.Checked;
                f4.checkBox13.Checked = checkBox13.Checked;
                f4.ShowDialog();
                f4.Close();
            }

            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked != true)
            {
                Form5 f5 = new Form5();
                f5.textBox1.Text = textBox1.Text;
                f5.checkBox16.Checked = checkBox1.Checked;
                f5.checkBox17.Checked = checkBox2.Checked;
                f5.checkBox18.Checked = checkBox3.Checked;
                f5.checkBox1.Checked = checkBox9.Checked;
                f5.checkBox2.Checked = checkBox10.Checked;
                f5.checkBox3.Checked = checkBox11.Checked;
                f5.checkBox4.Checked = checkBox12.Checked;
                f5.checkBox5.Checked = checkBox13.Checked;
                f5.checkBox6.Checked = checkBox4.Checked;
                f5.checkBox7.Checked = checkBox5.Checked;
                f5.checkBox8.Checked = checkBox6.Checked;
                f5.checkBox9.Checked = checkBox7.Checked;
                f5.checkBox10.Checked = checkBox8.Checked;
                f5.ShowDialog();
                f5.Close();

            }
           // this.Close();
        
        }
        

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

       
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
            
           
   }
    

       
