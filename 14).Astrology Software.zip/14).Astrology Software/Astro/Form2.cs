﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Resources;
using System.Reflection;

namespace Astro
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        ResourceManager a = new ResourceManager("Astro.Age18Resource4", Assembly.GetExecutingAssembly());
        ResourceManager agm = new ResourceManager("Astro.studentResource2", Assembly.GetExecutingAssembly());
        ResourceManager agf = new ResourceManager("Astro.faResource1", Assembly.GetExecutingAssembly());
        private void Form2_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (rasibalan.Text == "")
            {
                if (rasi.Text == "ரிஷப ராசி")
                {
                    rasibalan.Text = agm.GetString("mesa");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\b.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\1.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "மேஷ ராசி")
                {
                    rasibalan.Text = agm.GetString("risi");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\a.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\2.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "மிதுன  ராசி")
                {
                    rasibalan.Text = agm.GetString("mithu");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\c.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\3.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "சிம்ம  ராசி")
                {
                    rasibalan.Text = agm.GetString("simma");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\d.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\4.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "கடக ராசி")
                {
                    rasibalan.Text = agm.GetString("kadaka");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\e.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\5.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "கன்னி ராசி")
                {
                    rasibalan.Text = agm.GetString("kani");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\f.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\6.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "துலாம்  ராசி")
                {
                    rasibalan.Text = agm.GetString("thula");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\g.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\7.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "விருச்சிக ராசி")
                {
                    rasibalan.Text = agm.GetString("viru");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\h.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\8.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "தனுசு  ராசி")
                {
                    rasibalan.Text = agm.GetString("dhanu");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\i.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\9.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "மகர ராசி")
                {
                    rasibalan.Text = agm.GetString("mahara");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\j.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\10.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "கும்ப  ராசி")
                {
                    rasibalan.Text = agm.GetString("kumba");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\k.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\11.jpg");
                    t1.Dispose();
                }
                else if (rasi.Text == "மீனராசி")
                {
                    rasibalan.Text = agm.GetString("mina");
                    TextReader t1;
                    t1 = File.OpenText(@"S:astro\img.jpg");
                    rasiimage.Image = Image.FromFile(@"S:astro\jj\l.jpg");
                    stoneimage.Image = Image.FromFile(@"S:astro\jj\12.jpg");
                    t1.Dispose();
                }


            }
            if (starbalan.Text == "")
            {


                if (star.Text == "அசுவினி")
                {
                    starbalan.Text = agf.GetString("ashvi");
                }
                else if (star.Text == "பரணி")
                {
                    starbalan.Text = agf.GetString("barani");
                }
                else if (star.Text == "கிருத்திகை")
                {
                    starbalan.Text = agf.GetString("kiruthikai");
                }

                else if (star.Text == "ரோகிணி")
                {
                    starbalan.Text = agf.GetString("rokini");
                }
                else if (star.Text == "மிருகசிரீஷம்")
                {
                    starbalan.Text = agf.GetString("mirusakam");
                }
                else if (star.Text == "திருவாதிரை")
                {
                    starbalan.Text = agf.GetString("thiru");
                }
                else if (star.Text == "புனர்பூசம்")
                {
                    starbalan.Text = agf.GetString("punar");
                }
                else if (star.Text == "பூசம்")
                {
                    starbalan.Text = agf.GetString("pusam");
                }
                else if (star.Text == "ஆயில்யம்")
                {
                    starbalan.Text = agf.GetString("ayl");
                }
                else if (star.Text == "மகம்")
                {
                    starbalan.Text = agf.GetString("mahakam");
                }
                else if (star.Text == "பூரம்")
                {
                    starbalan.Text = agf.GetString("puram");
                }
                if (star.Text == "உத்திரம்")
                {
                    starbalan.Text = agf.GetString("uthi");
                }
                else if (star.Text == "ஹஸ்தம்")
                {
                    starbalan.Text = agf.GetString("hash");
                }
                else if (star.Text == "சித்திரை")
                {
                    starbalan.Text = agf.GetString("sithi");
                }
                if (star.Text == "சுவாதி")
                {
                    starbalan.Text = agf.GetString("swa");
                }
                else if (star.Text == "விசாகம்")
                {
                    starbalan.Text = agf.GetString("vish");
                }
                else if (star.Text == "அனுஷம்")
                {
                    starbalan.Text = agf.GetString("anush");

                }
                else if (star.Text == "கேட்டை")
                {
                    starbalan.Text = agf.GetString("keta");
                }
                else if (star.Text == "முலம்")
                {
                    starbalan.Text = agf.GetString("mula");
                }
                else if (star.Text == "பூராடம்")
                {
                    starbalan.Text = agf.GetString("puradam");
                }
                else if (star.Text == "உத்திராடம்")
                {
                    starbalan.Text = agf.GetString("uthuradam");
                }
                else if (star.Text == "திருவோணம்")
                {
                    starbalan.Text = agf.GetString("thiruonam");
                }
                else if (star.Text == "அவிட்டம்")
                {
                    starbalan.Text = agf.GetString("avita");
                }
                else if (star.Text == "சதயம்	")
                {
                    starbalan.Text = agf.GetString("sathayam");
                }
                else if (star.Text == "பூரட்டாதி")
                {
                    starbalan.Text = agf.GetString("puratathi");
                }
                else if (star.Text == "உத்திரட்டாதி")
                {
                    starbalan.Text = agf.GetString("uthiratathi");
                }
                else if (star.Text == "ரேவதி")
                {
                    starbalan.Text = agf.GetString("reva");
                }
            }

        }
























        

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
