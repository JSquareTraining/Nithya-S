﻿namespace Astro
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.rasiimage = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.rasibalan = new System.Windows.Forms.RichTextBox();
            this.starbalan = new System.Windows.Forms.RichTextBox();
            this.stoneimage = new System.Windows.Forms.PictureBox();
            this.age = new System.Windows.Forms.TextBox();
            this.rasi = new System.Windows.Forms.TextBox();
            this.star = new System.Windows.Forms.TextBox();
            this.stone = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.rasiimage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoneimage)).BeginInit();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(600, 369);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(164, 43);
            this.button1.TabIndex = 1;
            this.button1.Text = "எதிர்கால பலன்";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rasiimage
            // 
            this.rasiimage.Location = new System.Drawing.Point(12, 80);
            this.rasiimage.Name = "rasiimage";
            this.rasiimage.Size = new System.Drawing.Size(162, 173);
            this.rasiimage.TabIndex = 2;
            this.rasiimage.TabStop = false;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(557, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "வயது";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(180, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(170, 29);
            this.label3.TabIndex = 5;
            this.label3.Text = "ராசி பலன்";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(181, 209);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(169, 29);
            this.label4.TabIndex = 6;
            this.label4.Text = "நட்சத்திரம் பலன்";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(181, 320);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(169, 29);
            this.label6.TabIndex = 7;
            this.label6.Text = "ராசி கல்";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(247, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(208, 42);
            this.label5.TabIndex = 8;
            this.label5.Text = "ஜோதிடம்";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // rasibalan
            // 
            this.rasibalan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rasibalan.Location = new System.Drawing.Point(356, 81);
            this.rasibalan.Name = "rasibalan";
            this.rasibalan.Size = new System.Drawing.Size(585, 101);
            this.rasibalan.TabIndex = 9;
            this.rasibalan.Text = "";
            // 
            // starbalan
            // 
            this.starbalan.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.starbalan.Location = new System.Drawing.Point(356, 210);
            this.starbalan.Name = "starbalan";
            this.starbalan.Size = new System.Drawing.Size(585, 104);
            this.starbalan.TabIndex = 10;
            this.starbalan.Text = "";
            // 
            // stoneimage
            // 
            this.stoneimage.Location = new System.Drawing.Point(356, 333);
            this.stoneimage.Name = "stoneimage";
            this.stoneimage.Size = new System.Drawing.Size(217, 153);
            this.stoneimage.TabIndex = 11;
            this.stoneimage.TabStop = false;
            // 
            // age
            // 
            this.age.Location = new System.Drawing.Point(657, 33);
            this.age.Multiline = true;
            this.age.Name = "age";
            this.age.Size = new System.Drawing.Size(136, 29);
            this.age.TabIndex = 12;
            this.age.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // rasi
            // 
            this.rasi.Location = new System.Drawing.Point(12, 2);
            this.rasi.Name = "rasi";
            this.rasi.Size = new System.Drawing.Size(100, 20);
            this.rasi.TabIndex = 13;
            this.rasi.Visible = false;
            this.rasi.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // star
            // 
            this.star.Location = new System.Drawing.Point(12, 28);
            this.star.Name = "star";
            this.star.Size = new System.Drawing.Size(100, 20);
            this.star.TabIndex = 14;
            this.star.Visible = false;
            // 
            // stone
            // 
            this.stone.Location = new System.Drawing.Point(12, 54);
            this.stone.Name = "stone";
            this.stone.Size = new System.Drawing.Size(100, 20);
            this.stone.TabIndex = 15;
            this.stone.Visible = false;
            this.stone.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Pink;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1246, 498);
            this.Controls.Add(this.stone);
            this.Controls.Add(this.star);
            this.Controls.Add(this.rasi);
            this.Controls.Add(this.age);
            this.Controls.Add(this.stoneimage);
            this.Controls.Add(this.starbalan);
            this.Controls.Add(this.rasibalan);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rasiimage);
            this.Controls.Add(this.button1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.rasiimage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stoneimage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox rasiimage;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RichTextBox rasibalan;
        private System.Windows.Forms.RichTextBox starbalan;
        private System.Windows.Forms.PictureBox stoneimage;
        public System.Windows.Forms.TextBox rasi;
        public System.Windows.Forms.TextBox star;
        public System.Windows.Forms.TextBox stone;
        public System.Windows.Forms.TextBox age;
    }
}