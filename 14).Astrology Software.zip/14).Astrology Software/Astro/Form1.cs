﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.Resources;
using System.IO;

namespace Astro
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public String s4, s2, s3;
       
        
        //TextWriter otw;
        ResourceManager r = new ResourceManager("Astro.18abResource3", Assembly.GetExecutingAssembly());
        ResourceManager a = new ResourceManager("Astro.Age18Resource4", Assembly.GetExecutingAssembly());
        ResourceManager c = new ResourceManager("Astro.colorResource1", Assembly.GetExecutingAssembly());
        ResourceManager ag18 = new ResourceManager("Astro.RasiResource5", Assembly.GetExecutingAssembly());
        ResourceManager agm = new ResourceManager("Astro.studentResource2", Assembly.GetExecutingAssembly());
        ResourceManager agf = new ResourceManager("Astro.faResource1", Assembly.GetExecutingAssembly());


        private void button1_Click(object sender, EventArgs e)
        {
            s2 = rasi.SelectedItem.ToString();
            s3 = star.SelectedItem.ToString();
            s4 = color.SelectedItem.ToString();
            
            //TextWriter otw;
            //otw = File.CreateText(@"D:\nithya.s\ast2.txt");
            //otw.WriteLine(String.Concat(label2.Text ,textBox1.Text));
            //if (radioButton1.Checked == true)
            //{

            //    otw.WriteLine(String.Concat(label3.Text, "ஆண்"));
            //}
            //else
            //{
            //    otw.WriteLine(String.Concat(label3.Text, "பெண்"));
            //}
            //TextWriter otw1;
            //otw1 = File.CreateText(@"D:\nithya.s\ast2.txt");
            
             //otw.WriteLine(String.Concat(label2.Text, textBox1.Text));
             //otw.WriteLine(String.Concat(label4.Text, dtpicker.Value.ToString()));
             //otw.WriteLine(String.Concat(label5.Text, rasi.SelectedItem));
             //otw.WriteLine(String.Concat(label6.Text, rasi.SelectedItem));
             //otw.WriteLine(String.Concat(label7.Text, rasi.SelectedItem));
             //otw.Dispose();

             int da, age,ct;
             ct = textBox1.Text.Length;
             da = DateTime.Now.Year;
             age = da - dtpicker.Value.Year;

             String s = age.ToString();


             Form2 f2 = new Form2();

             f2.rasi.Text = s2;
             f2.star.Text = s3;
             f2.stone.Text = s4;
             f2.age.Text = s;
             if (s=="0")
             {
                 MessageBox.Show("New Born Baby");
                 f2.age.Text = "New Born Baby";
             }


             f2.ShowDialog();
            
             

             

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
                     
            if (rasi.SelectedItem.ToString() == "மேஷ ராசி")
            {
                TextWriter tw;
                tw = File.CreateText(@"S:\astro\jj\as.txt");
                tw.WriteLine(r.GetString("mesa"));
                tw.Dispose();
               
                TextWriter t;
                t = File.CreateText(@"S:\astro\jj\img.jpg");
                t.WriteLine(@"S:\nithya\jj\a.jpg");
                t.Dispose();

            }
            else if (rasi.SelectedItem.ToString() == "ரிஷப ராசி")
            {
                TextWriter tw1;
                tw1 = File.CreateText(@"S:\astro\jj\as.txt");
                tw1.WriteLine(r.GetString("risi"));
                tw1.Dispose();
            }
            else if (rasi.SelectedItem.ToString() == "மிதுன  ராசி")
            {
                TextWriter tw2;
                tw2 = File.CreateText(@"S:\nithya\as.txt");
                tw2.WriteLine(r.GetString("mithu"));
                tw2.Dispose();
            }
            else if (rasi.SelectedItem.ToString() == "சிம்ம  ராசி")
            {
                TextWriter tw3;
                tw3 = File.CreateText(@"S:\nithya\as.txt");
                tw3.WriteLine(r.GetString("simma"));
                tw3.Dispose();
            }
            else if (rasi.SelectedItem.ToString() == "கடக ராசி")
            {
                TextWriter tw4;
                tw4 = File.CreateText(@"S:\nithya\as.txt");
                tw4.WriteLine(r.GetString("kadaka"));
                tw4.Dispose();
                
            }
            else if (rasi.SelectedItem.ToString() == "கன்னி ராசி")
            {
                TextWriter tw5;
                tw5 = File.CreateText(@"S:\nithya\ast1.txt");
                tw5.WriteLine(r.GetString("kani"));
                tw5.Dispose();
            }
            else if (rasi.SelectedItem.ToString() == "துலாம்  ராசி")
            {
                TextWriter tw6;
                tw6 = File.CreateText(@"S:\nithya\as.txt");
                tw6.WriteLine(r.GetString("thula"));
                tw6.Dispose();
            }
            else if (rasi.SelectedItem.ToString() == "விருச்சிக ராசி")
            {
                TextWriter tw7;
                tw7 = File.CreateText(@"S:\nithya\as.txt");
                tw7.WriteLine(r.GetString("viru"));
                tw7.Dispose();
            }
            else if (rasi.SelectedItem.ToString() == "தனுசு  ராசி")
            {
                TextWriter tw8;
                tw8 = File.CreateText(@"S:\nithya\as.txt");
                tw8.WriteLine(r.GetString("dhanu"));
                tw8.Dispose();
            }
            else if (rasi.SelectedItem.ToString() == "மகர ராசி")
            {
                TextWriter tw9;
                tw9 = File.CreateText(@"S:\nithya\as.txt");
                tw9.WriteLine(r.GetString("mahara"));
                tw9.Dispose();
            }
            else if (rasi.SelectedItem.ToString() == "கும்ப  ராசி")
            {
                TextWriter tw10;
                tw10 = File.CreateText(@"S:\nithya\as.txt");
                tw10.WriteLine(r.GetString("kumba"));
                tw10.Dispose();
            }
            else if (rasi.SelectedItem.ToString() == "மீனராசி")
            {
                TextWriter tw11;
                tw11 = File.CreateText(@"S:\nithya\as.txt");
                tw11.WriteLine(r.GetString("mina"));
                tw11.Dispose();
            }
        

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void star_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
