﻿using System;
using System.Windows.Forms;


namespace product
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
        }
        /// <summary>
        /// Data collection
        /// add data
        /// suggestAppend style for data display in TextBox
        /// CustomSource used to perfrom Autocomplete
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            AutoCompleteStringCollection asc = new AutoCompleteStringCollection();
            asc.Add("RIN");
            asc.Add("ARASAN");
            asc.Add("RINMA");
            asc.Add("PONVANDU");
            tb1_getdata.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            tb1_getdata.AutoCompleteSource = AutoCompleteSource.CustomSource;
            tb1_getdata.AutoCompleteCustomSource = asc;
            AutoCompleteStringCollection asc1 = new AutoCompleteStringCollection();
            asc1.Add("IR20");
            asc1.Add("IC20");
            asc1.Add("PONNI");
            tb2_getdata.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            tb2_getdata.AutoCompleteSource = AutoCompleteSource.CustomSource;
            tb2_getdata.AutoCompleteCustomSource = asc1;
            AutoCompleteStringCollection asc2 = new AutoCompleteStringCollection();
            asc2.Add("OIL COCONUT");
            asc2.Add("OIL GROUNDNUT");
            asc2.Add("OIL NEEM");
            asc2.Add("OIL DEEPAM");
            tb3_getdata.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            tb3_getdata.AutoCompleteSource = AutoCompleteSource.CustomSource;
            tb3_getdata.AutoCompleteCustomSource = asc2;
            AutoCompleteStringCollection asc3 = new AutoCompleteStringCollection();
            asc3.Add("PASTE CLOSE UP");
            asc3.Add("PASTE COLGATE");
            asc3.Add("PASTE PEPSUDANT");
            asc3.Add("PASTE VICO");
            tb4_getdata.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            tb4_getdata.AutoCompleteSource = AutoCompleteSource.CustomSource;
            tb4_getdata.AutoCompleteCustomSource = asc3;
        }

        private void tb2_getdata_TextChanged(object sender, EventArgs e)
        {
            if (tb2_getdata.Text == "IR20")
            {
                tb6_getdata.Text = "70";
            }
            else if (tb2_getdata.Text == "IC20")
            {
                tb6_getdata.Text = "60";
            }
            else if (tb2_getdata.Text == "PONNI")
            {
                tb6_getdata.Text = "80";
            }

        }
        private void tb3_getdata_TextChanged(object sender, EventArgs e)
        {

            if (tb3_getdata.Text == "OIL COCONUT")
            {
                tb7_getdata.Text = "80";
            }
            else if (tb3_getdata.Text == "OIL GROUNDNUT")
            {
                tb7_getdata.Text = "90";
            }
            else if (tb3_getdata.Text == "OIL NEEM")
            {
                tb7_getdata.Text = "70";
            }
            else if (tb3_getdata.Text == "OIL DEEPAM")
            {
                tb7_getdata.Text = "85";
            }

        }

        private void tb4_getdata_TextChanged(object sender, EventArgs e)
        {

            if (tb4_getdata.Text == "PASTE CLOSE UP")
            {
                tb8_getdata.Text = "20";
            }
            else if (tb4_getdata.Text == "PASTE COLGATE")
            {
                tb8_getdata.Text = "15";
            }
            else if (tb4_getdata.Text == "PASTE PEPSUDANT")
            {
                tb8_getdata.Text = "18";
            }
            else if (tb4_getdata.Text == "PASTE VICO")
            {
                tb8_getdata.Text = "16";
            }

        }
      
        private void tb1_getdata_TextChanged(object sender, EventArgs e)
        {

            if (tb1_getdata.Text == "RIN")
            {
                tb5_getdata.Text = "10";
            }
            else if (tb1_getdata.Text == "ARASAN")
            {
                tb5_getdata.Text = "15";
            }
            else if (tb1_getdata.Text == "RINMA")
            {
                tb5_getdata.Text = "12";
            }
            else if (tb1_getdata.Text == "PONVANDU")
            {
                tb5_getdata.Text = "16";
            }

        }

        private void tb9_getdata_TextChanged(object sender, EventArgs e)
        {
                 int i = Convert.ToInt32(tb5_getdata.Text);
                int j = Convert.ToInt32(tb9_getdata.Text);
                int k = i * j;
                tb13_getdata.Text = Convert.ToString(k);
                tb17_nettotal.Text = Convert.ToString(k);
         }


        private void tb10_getdata_TextChanged(object sender, EventArgs e)
        {
            
                int l = Convert.ToInt32(tb6_getdata.Text);
                int m = Convert.ToInt32(tb10_getdata.Text);
                int n = l * m;
                tb14_getdata.Text = Convert.ToString(n);
                int x = Convert.ToInt32(tb13_getdata.Text);
                int z = x + n;
                tb17_nettotal.Text = Convert.ToString(z);
            
        }

        private void tb11_getdata_TextChanged(object sender, EventArgs e)
        {
           
                int o = Convert.ToInt32(tb7_getdata.Text);
                int p = Convert.ToInt32(tb11_getdata.Text);
                int q = o * p;
                tb15_getdata.Text = Convert.ToString(q);
                int u = Convert.ToInt32(tb13_getdata.Text);
                int v = Convert.ToInt32(tb14_getdata.Text);
                int w = Convert.ToInt32(tb15_getdata.Text);
                int a = u + v + w;
                tb17_nettotal.Text = Convert.ToString(a);
           
        }


        private void tb12_getdata_TextChanged(object sender, EventArgs e)
        {
                       
                int r = Convert.ToInt32(tb8_getdata.Text);
                int s = Convert.ToInt32(tb12_getdata.Text);
                int t = r * s;
                tb16_getdata.Text = Convert.ToString(t);
                int b = Convert.ToInt32(tb13_getdata.Text);
                int c = Convert.ToInt32(tb14_getdata.Text);
                int d = Convert.ToInt32(tb15_getdata.Text);
                int p = Convert.ToInt32(tb16_getdata.Text);
                int f = b + c + d + p;
                tb17_nettotal.Text = Convert.ToString(f);
            
        }
           
       
        private void tb18_discount_TextChanged(object sender, EventArgs e)
        { 
            if (tb18_discount.Text != "")
            {
                int g = Convert.ToInt32(tb17_nettotal.Text);
                int h = Convert.ToInt32(tb18_discount.Text);
                int i = (g * h / 100);
                tb19_Discount.Text = Convert.ToString(i);
                int k = g - i;
                tb20_total.Text = Convert.ToString(k);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void tb8_getdata_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb19_Discount_TextChanged(object sender, EventArgs e)
        {

        }

        private void tb13_getdata_TextChanged(object sender, EventArgs e)
        {

        }
     }
}