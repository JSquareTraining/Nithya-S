﻿namespace product
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb1_getdata = new System.Windows.Forms.TextBox();
            this.tb2_getdata = new System.Windows.Forms.TextBox();
            this.tb3_getdata = new System.Windows.Forms.TextBox();
            this.tb4_getdata = new System.Windows.Forms.TextBox();
            this.tb5_getdata = new System.Windows.Forms.TextBox();
            this.tb6_getdata = new System.Windows.Forms.TextBox();
            this.tb7_getdata = new System.Windows.Forms.TextBox();
            this.tb8_getdata = new System.Windows.Forms.TextBox();
            this.tb9_getdata = new System.Windows.Forms.TextBox();
            this.tb10_getdata = new System.Windows.Forms.TextBox();
            this.tb11_getdata = new System.Windows.Forms.TextBox();
            this.tb12_getdata = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tb17_nettotal = new System.Windows.Forms.TextBox();
            this.tb18_discount = new System.Windows.Forms.TextBox();
            this.tb19_Discount = new System.Windows.Forms.TextBox();
            this.tb20_total = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.tb13_getdata = new System.Windows.Forms.TextBox();
            this.tb14_getdata = new System.Windows.Forms.TextBox();
            this.tb15_getdata = new System.Windows.Forms.TextBox();
            this.tb16_getdata = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(116, 107);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(138, 43);
            this.label1.TabIndex = 0;
            this.label1.Text = "     Product";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(345, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 43);
            this.label2.TabIndex = 1;
            this.label2.Text = "Quantity/price";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(564, 107);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(141, 43);
            this.label3.TabIndex = 2;
            this.label3.Text = "No Of Units";
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(788, 107);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 43);
            this.label4.TabIndex = 3;
            this.label4.Text = "     Total";
            // 
            // tb1_getdata
            // 
            this.tb1_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb1_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb1_getdata.Location = new System.Drawing.Point(121, 193);
            this.tb1_getdata.Name = "tb1_getdata";
            this.tb1_getdata.Size = new System.Drawing.Size(133, 31);
            this.tb1_getdata.TabIndex = 4;
            this.tb1_getdata.TextChanged += new System.EventHandler(this.tb1_getdata_TextChanged);
            // 
            // tb2_getdata
            // 
            this.tb2_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb2_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb2_getdata.Location = new System.Drawing.Point(121, 258);
            this.tb2_getdata.Name = "tb2_getdata";
            this.tb2_getdata.Size = new System.Drawing.Size(133, 31);
            this.tb2_getdata.TabIndex = 5;
            this.tb2_getdata.TextChanged += new System.EventHandler(this.tb2_getdata_TextChanged);
            // 
            // tb3_getdata
            // 
            this.tb3_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb3_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb3_getdata.Location = new System.Drawing.Point(121, 321);
            this.tb3_getdata.Name = "tb3_getdata";
            this.tb3_getdata.Size = new System.Drawing.Size(133, 31);
            this.tb3_getdata.TabIndex = 6;
            this.tb3_getdata.TextChanged += new System.EventHandler(this.tb3_getdata_TextChanged);
            // 
            // tb4_getdata
            // 
            this.tb4_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb4_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb4_getdata.Location = new System.Drawing.Point(121, 392);
            this.tb4_getdata.Name = "tb4_getdata";
            this.tb4_getdata.Size = new System.Drawing.Size(133, 31);
            this.tb4_getdata.TabIndex = 7;
            this.tb4_getdata.TextChanged += new System.EventHandler(this.tb4_getdata_TextChanged);
            // 
            // tb5_getdata
            // 
            this.tb5_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb5_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb5_getdata.Location = new System.Drawing.Point(379, 193);
            this.tb5_getdata.Name = "tb5_getdata";
            this.tb5_getdata.ReadOnly = true;
            this.tb5_getdata.Size = new System.Drawing.Size(77, 31);
            this.tb5_getdata.TabIndex = 8;
            // 
            // tb6_getdata
            // 
            this.tb6_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb6_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb6_getdata.Location = new System.Drawing.Point(379, 258);
            this.tb6_getdata.Name = "tb6_getdata";
            this.tb6_getdata.ReadOnly = true;
            this.tb6_getdata.Size = new System.Drawing.Size(77, 31);
            this.tb6_getdata.TabIndex = 9;
            // 
            // tb7_getdata
            // 
            this.tb7_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb7_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb7_getdata.Location = new System.Drawing.Point(379, 321);
            this.tb7_getdata.Name = "tb7_getdata";
            this.tb7_getdata.ReadOnly = true;
            this.tb7_getdata.Size = new System.Drawing.Size(77, 31);
            this.tb7_getdata.TabIndex = 10;
            // 
            // tb8_getdata
            // 
            this.tb8_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb8_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb8_getdata.Location = new System.Drawing.Point(379, 392);
            this.tb8_getdata.Name = "tb8_getdata";
            this.tb8_getdata.ReadOnly = true;
            this.tb8_getdata.Size = new System.Drawing.Size(77, 31);
            this.tb8_getdata.TabIndex = 11;
            this.tb8_getdata.TextChanged += new System.EventHandler(this.tb8_getdata_TextChanged);
            // 
            // tb9_getdata
            // 
            this.tb9_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb9_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb9_getdata.Location = new System.Drawing.Point(581, 193);
            this.tb9_getdata.Name = "tb9_getdata";
            this.tb9_getdata.Size = new System.Drawing.Size(91, 31);
            this.tb9_getdata.TabIndex = 12;
            this.tb9_getdata.TextChanged += new System.EventHandler(this.tb9_getdata_TextChanged);
            // 
            // tb10_getdata
            // 
            this.tb10_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb10_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb10_getdata.Location = new System.Drawing.Point(582, 258);
            this.tb10_getdata.Name = "tb10_getdata";
            this.tb10_getdata.Size = new System.Drawing.Size(90, 31);
            this.tb10_getdata.TabIndex = 13;
            this.tb10_getdata.TextChanged += new System.EventHandler(this.tb10_getdata_TextChanged);
            // 
            // tb11_getdata
            // 
            this.tb11_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb11_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb11_getdata.Location = new System.Drawing.Point(582, 321);
            this.tb11_getdata.Name = "tb11_getdata";
            this.tb11_getdata.Size = new System.Drawing.Size(91, 31);
            this.tb11_getdata.TabIndex = 14;
            this.tb11_getdata.TextChanged += new System.EventHandler(this.tb11_getdata_TextChanged);
            this.tb11_getdata.Enter += new System.EventHandler(this.Form1_Load);
            // 
            // tb12_getdata
            // 
            this.tb12_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb12_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb12_getdata.Location = new System.Drawing.Point(582, 392);
            this.tb12_getdata.Name = "tb12_getdata";
            this.tb12_getdata.Size = new System.Drawing.Size(91, 31);
            this.tb12_getdata.TabIndex = 15;
            this.tb12_getdata.TextChanged += new System.EventHandler(this.tb12_getdata_TextChanged);
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.LightGray;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(434, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(405, 33);
            this.label5.TabIndex = 20;
            this.label5.Text = "Product Billing Management System ";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Silver;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(565, 469);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(108, 25);
            this.label6.TabIndex = 21;
            this.label6.Text = "Net Total";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Silver;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(569, 523);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 25);
            this.label7.TabIndex = 22;
            this.label7.Text = "Discount";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Silver;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(576, 587);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 25);
            this.label8.TabIndex = 23;
            this.label8.Text = "TOTAL";
            // 
            // tb17_nettotal
            // 
            this.tb17_nettotal.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb17_nettotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb17_nettotal.Location = new System.Drawing.Point(736, 466);
            this.tb17_nettotal.Multiline = true;
            this.tb17_nettotal.Name = "tb17_nettotal";
            this.tb17_nettotal.ReadOnly = true;
            this.tb17_nettotal.Size = new System.Drawing.Size(121, 39);
            this.tb17_nettotal.TabIndex = 24;
            // 
            // tb18_discount
            // 
            this.tb18_discount.AutoCompleteCustomSource.AddRange(new string[] {
            "",
            "",
            "",
            ""});
            this.tb18_discount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.tb18_discount.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb18_discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb18_discount.Location = new System.Drawing.Point(736, 521);
            this.tb18_discount.Multiline = true;
            this.tb18_discount.Name = "tb18_discount";
            this.tb18_discount.Size = new System.Drawing.Size(38, 31);
            this.tb18_discount.TabIndex = 25;
            this.tb18_discount.TextChanged += new System.EventHandler(this.tb18_discount_TextChanged);
            // 
            // tb19_Discount
            // 
            this.tb19_Discount.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb19_Discount.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb19_Discount.Location = new System.Drawing.Point(817, 521);
            this.tb19_Discount.Multiline = true;
            this.tb19_Discount.Name = "tb19_Discount";
            this.tb19_Discount.Size = new System.Drawing.Size(40, 31);
            this.tb19_Discount.TabIndex = 26;
            this.tb19_Discount.TextChanged += new System.EventHandler(this.tb19_Discount_TextChanged);
            // 
            // tb20_total
            // 
            this.tb20_total.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb20_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb20_total.Location = new System.Drawing.Point(736, 567);
            this.tb20_total.Multiline = true;
            this.tb20_total.Name = "tb20_total";
            this.tb20_total.Size = new System.Drawing.Size(121, 37);
            this.tb20_total.TabIndex = 27;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(780, 523);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(31, 27);
            this.label9.TabIndex = 28;
            this.label9.Text = "%";
            // 
            // tb13_getdata
            // 
            this.tb13_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb13_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb13_getdata.Location = new System.Drawing.Point(810, 193);
            this.tb13_getdata.Name = "tb13_getdata";
            this.tb13_getdata.Size = new System.Drawing.Size(83, 31);
            this.tb13_getdata.TabIndex = 29;
            this.tb13_getdata.TextChanged += new System.EventHandler(this.tb13_getdata_TextChanged);
            // 
            // tb14_getdata
            // 
            this.tb14_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb14_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb14_getdata.Location = new System.Drawing.Point(810, 258);
            this.tb14_getdata.Name = "tb14_getdata";
            this.tb14_getdata.Size = new System.Drawing.Size(83, 31);
            this.tb14_getdata.TabIndex = 30;
            // 
            // tb15_getdata
            // 
            this.tb15_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb15_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb15_getdata.Location = new System.Drawing.Point(810, 321);
            this.tb15_getdata.Name = "tb15_getdata";
            this.tb15_getdata.Size = new System.Drawing.Size(83, 31);
            this.tb15_getdata.TabIndex = 31;
            // 
            // tb16_getdata
            // 
            this.tb16_getdata.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.tb16_getdata.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb16_getdata.Location = new System.Drawing.Point(810, 392);
            this.tb16_getdata.Name = "tb16_getdata";
            this.tb16_getdata.Size = new System.Drawing.Size(83, 31);
            this.tb16_getdata.TabIndex = 32;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Violet;
            this.ClientSize = new System.Drawing.Size(1281, 621);
            this.Controls.Add(this.tb16_getdata);
            this.Controls.Add(this.tb15_getdata);
            this.Controls.Add(this.tb14_getdata);
            this.Controls.Add(this.tb13_getdata);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.tb20_total);
            this.Controls.Add(this.tb19_Discount);
            this.Controls.Add(this.tb18_discount);
            this.Controls.Add(this.tb17_nettotal);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.tb12_getdata);
            this.Controls.Add(this.tb11_getdata);
            this.Controls.Add(this.tb10_getdata);
            this.Controls.Add(this.tb9_getdata);
            this.Controls.Add(this.tb8_getdata);
            this.Controls.Add(this.tb7_getdata);
            this.Controls.Add(this.tb6_getdata);
            this.Controls.Add(this.tb5_getdata);
            this.Controls.Add(this.tb4_getdata);
            this.Controls.Add(this.tb3_getdata);
            this.Controls.Add(this.tb2_getdata);
            this.Controls.Add(this.tb1_getdata);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            this.Text = "Billig";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb2_getdata;
        private System.Windows.Forms.TextBox tb3_getdata;
        private System.Windows.Forms.TextBox tb4_getdata;
        private System.Windows.Forms.TextBox tb5_getdata;
        private System.Windows.Forms.TextBox tb6_getdata;
        private System.Windows.Forms.TextBox tb7_getdata;
        private System.Windows.Forms.TextBox tb8_getdata;
        private System.Windows.Forms.TextBox tb9_getdata;
        private System.Windows.Forms.TextBox tb10_getdata;
        private System.Windows.Forms.TextBox tb11_getdata;
        private System.Windows.Forms.TextBox tb12_getdata;
       // private System.Windows.Forms.TextBox tb13_getdata;
        //private System.Windows.Forms.TextBox tb14_getdata;
        //private System.Windows.Forms.TextBox tb15_getdata;
        //private System.Windows.Forms.TextBox tb16_getdata;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb17_nettotal;
        private System.Windows.Forms.TextBox tb18_discount;
        private System.Windows.Forms.TextBox tb19_Discount;
        private System.Windows.Forms.TextBox tb20_total;
        public System.Windows.Forms.TextBox tb1_getdata;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox tb13_getdata;
        private System.Windows.Forms.TextBox tb14_getdata;
        private System.Windows.Forms.TextBox tb15_getdata;
        private System.Windows.Forms.TextBox tb16_getdata;
    }
}

