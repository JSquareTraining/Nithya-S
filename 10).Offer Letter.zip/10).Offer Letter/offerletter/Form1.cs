﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace offerletter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //String s;

        private void button1_Click(object sender, EventArgs e)
        {
            {

                {
                    StringBuilder stb = new StringBuilder();
                    stb.Append(textBox13.Text);
                    label11.Text = stb.ToString();
                    StringBuilder stbb = new StringBuilder();
                    stbb.Append(textBox3.Text);
                    label10.Text = stbb.ToString();
                    StringBuilder stbb1 = new StringBuilder();
                    stbb1.Append(textBox4.Text);
                    label13.Text = stbb.ToString();
                    StringBuilder stb1 = new StringBuilder();
                    stb1.Append(textBox2.Text);
                    label12.Text = stb1.ToString();
                    StringBuilder stb2 = new StringBuilder();
                    stb2.Append(textBox5.Text);
                    label14.Text = stb2.ToString();

                    StringBuilder stb3 = new StringBuilder();
                    stb3.Append(textBox6.Text);
                    label19.Text = stb3.ToString();

                    StringBuilder stb4 = new StringBuilder();
                    stb4.Append(textBox7.Text);
                    label20.Text = stb4.ToString();

                    StringBuilder stb5 = new StringBuilder();
                    stb5.Append(textBox8.Text);
                    label15.Text = stb5.ToString();

                    StringBuilder stb6 = new StringBuilder();
                    stb6.Append(textBox9.Text);
                    label16.Text = stb6.ToString();

                    StringBuilder stb7 = new StringBuilder();
                    stb7.Append(textBox10.Text);
                    label17.Text = stb7.ToString();

                    StringBuilder stb8 = new StringBuilder();
                    stb8.Append(textBox11.Text);
                    label18.Text = stb8.ToString();

                    StringBuilder stb9 = new StringBuilder();
                    stb9.Append(textBox12.Text);
                    label21.Text = stb9.ToString();

                    StringBuilder stb10 = new StringBuilder();
                    stb10.Append(textBox13.Text);
                    label24.Text = stb10.ToString();

                    StringBuilder stb11 = new StringBuilder();
                    stb11.Append(textBox2.Text);
                    label22.Text = stb11.ToString();

                    StringBuilder stb12 = new StringBuilder();
                    stb12.Append(textBox4.Text);
                    label23.Text = stb12.ToString();
                }
                if (radioButton1.Checked == true)
                {
                    radioButton3.Visible = true;
                    radioButton4.Visible = false;
                }
                else
                {
                    radioButton3.Visible = false;
                    radioButton4.Visible = true;
                }

            
            if (checkBox1.Checked == true)
            {
                checkBox3.Visible= true;
               // checkBox3.Checked = true;
                checkBox4.Visible = false;
                checkBox3.Checked = true;
            }
            else
            {
                checkBox3.Visible = false;
                //checkBox4.Checked = true;
                checkBox4.Visible = true;
                checkBox4.Checked = true;
            }
            }
            
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
        
        }

                 //MessageBox.Show(stb.ToString());

              
        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {




        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
            
            
      
            
            
            
            
            
            //String s = textBox13.Text;
            //textBox13.Text=(s.Insert(s,for label11.Text);









           // StringBuilder osb = new StringBuilder();
            //osb.Append("hi welcome");
            //osb.Append(textBox13.Text);
           // label11.Text = osb.ToString();

            //osb.Append("to");
            //osb.Append(textBox2.Text);
            //osb.Append("hi welcome");
            //osb.Append("v r happy 2 join with u");
            //osb.AppendLine();
            //osb.AppendFormat("Hi welcome Mr.{0} to {1}.v r happy 2 join with u", textBox1.Text, textBox2.Text);
            //MessageBox.Show(osb.ToString());

        }
    

}