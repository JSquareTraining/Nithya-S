﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace gmailsn
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            TextReader tr1;
            tr1 = File.OpenText("S:\\Gmail\\" + textBox1.Text + "\\Trash\\" + listBox1.SelectedItem);
            label1.Text = tr1.ReadToEnd();
            tr1.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                File.Delete("S:\\Gmail\\" + textBox1.Text + "\\Trash\\" + listBox1.SelectedItem);
                DirectoryInfo dft = new DirectoryInfo("S:\\Gmail\\" + textBox1.Text + "\\Trash");
               // listBox1.Items.Clear();
                foreach (object o in dft.GetFiles())
                {
                    listBox1.Items.Remove(listBox1.SelectedItems.ToString());
                }

                label1.Text = "";
                checkBox1.Checked = false;

                this.Close();
                
                //listBox1.SelectedItems.Remove();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
