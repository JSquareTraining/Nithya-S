﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace gmailsn
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            TextReader tr2;
            tr2 = File.OpenText("S:\\Gmail\\" + textBox1.Text + "\\Sent Items\\" + listBox1.SelectedItem);
            label1.Text = tr2.ReadToEnd();
            tr2.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                File.Move("S:\\Gmail\\" + textBox1.Text + "\\Sent Items\\" + listBox1.SelectedItem, "S:\\Gmail\\" + textBox1.Text + "\\Trash\\" + listBox1.SelectedItem);
                DirectoryInfo dft = new DirectoryInfo("S:\\Gmail\\" + textBox1.Text + "\\Sent Items");
                listBox1.Items.Clear();
                foreach (object o in dft.GetFiles())
                {
                    listBox1.Items.Add(o);

                }
                label1.Text = "";
                checkBox1.Checked = false;
            }
        }
    }
}
