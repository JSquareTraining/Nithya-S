﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;



namespace gmailsn
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lbl_account_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (File.Exists(@"S:\Gmail\" + textBox1.Text + @"\" + textBox1.Text + ".txt") == true)
            {
                TextReader tr;
                tr = File.OpenText(@"S:\Gmail\" + textBox1.Text + "\\" + textBox1.Text + ".txt");
                String s = tr.ReadToEnd();
                string[] s1 = s.Split(',');
                string a = string.Format("{0}", s1);
                string b = string.Format("{1}", s1);
                if (textBox1.Text == a && textBox2.Text == b)
                {
                    MessageBox.Show("Loading....................");
                    Form3 f3 = new Form3();
                    f3.textBox2.Text = textBox1.Text;
                    f3.ShowDialog();
                }
            }
            else if (textBox1.Text == "" && textBox2.Text == "")
            {

                MessageBox.Show("Enter user name and password");

            }
            else if (textBox1.Text == "" || textBox2.Text == "")
            {

                MessageBox.Show("Enter user name and password");

            }
            else
            {
                MessageBox.Show("user name and password is incorrect");

            }
           
            

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

       

      

        
    }
}
