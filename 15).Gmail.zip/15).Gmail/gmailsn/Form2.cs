﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace gmailsn
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                label8.Text = "Fill the name";
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                label8.Text = "Fill the name";
            }
            if (textBox3.Text == "")
            {
                label9.Text = "Fill Username";
            }

        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                label8.Text = "Fill the name";
            }
            if (textBox3.Text == "")
            {
                label9.Text = "Fill Username";
            }
            //if (textBox5.Text == "")
            //{
            //    label10.Text = "Fill password";
            //}
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                label8.Text = "Fill the name";
            }
            if (textBox3.Text == "")
            {
                label9.Text = "Fill Username";
            }
            if (textBox5.Text == "")
            {
                label10.Text = "Fill password";
            }
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (textBox1.Text == "" && textBox2.Text == "")
            {
                label8.Text = "Fill the name";
            }
            if (textBox3.Text == "")
            {
                label9.Text = "Fill Username";
            }
            if (textBox5.Text == "")
            {
                label10.Text = "Fill password";
            }
            if (textBox6.Text == "")
            {
                label11.Text = "Fill password";
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

            if (textBox1.Text == "" && textBox2.Text == "")
            {
                label8.Text = "Fill the name";
            }
            if (textBox3.Text == "")
            {
                label9.Text = "Fill Username";
            }
            if (textBox5.Text == "")
            {
                label10.Text = "Fill password";
            }
            if (textBox6.Text == "")
            {
                label11.Text = "Fill password";
            }
            if (comboBox3.Text == "")
            {
                label13.Text = "fill Gender";
            }
            //if (comboBox1.Text == "" || comboBox2.Text == "" || comboBox4.Text == "")
            //{
            //    label12.Text = "Fill Date Of Birth";
            //}
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" && textBox2.Text == "")
            {
                label8.Text = "Fill the name";
            }
            if (textBox3.Text == "")
            {
                label9.Text = "Fill Username";
            }
            if (textBox5.Text == "")
            {
                label10.Text = "Fill password";
            }
            if (textBox6.Text == "")
            {
                label11.Text = "Fill password";
            }
            //if (comboBox1.Text == "" || comboBox2.Text == "" || comboBox4.Text == "")
            //{
            //    label12.Text = "Fill Date Of Birth";
            //}
        }

        private void comboBox3_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || comboBox2.Text == "" || comboBox4.Text == "")
            {
                label12.Text = "Fill Date Of Birth";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "" && textBox2.Text == "")
            {
                label8.Text = "Fill the name";
                MessageBox.Show("Fill the name");
            }
            if (textBox3.Text == "")
            {
                label9.Text = "Fill Username";
                MessageBox.Show("Fill the Username");
            }
            if (textBox5.Text == "")
            {
                label10.Text = "Fill password";
                MessageBox.Show("Fill the Password");
            }
            if (textBox6.Text == "")
            {
                label11.Text = "Fill password";
                MessageBox.Show("Fill the password");
            }
            if (comboBox1.Text == "" || comboBox2.Text == "" || comboBox4.Text == "")
            {
                label12.Text = "Fill Date Of Birth";
                MessageBox.Show("Fill the DOB");
            }
            if (comboBox3.Text == "")
            {
                label14.Text = "Fill Gender";
                MessageBox.Show("Fill the Gender");
            }
            if (textBox9.Text == "")
            {
                label14.Text = "Fill phone number";
                MessageBox.Show("Fill the Phone no");
            }
            if (checkBox1.Checked != true)
            {
                label15.Text = "Are You Agree the terms and conditions?";
                MessageBox.Show("Are U Agree Or Not");
            }
            
            //TextWriter tw;
            //tw = File.CreateText(@"D:\Gmail\" + textBox3.Text + ".txt");
            //tw.WriteAsync(textBox3.Text + "," + textBox5.Text + ",");
            //tw.Dispose();

            if (textBox5.Text == textBox6.Text)
            {
                if (Directory.Exists(@"S:\Gmail\" + textBox3.Text) == false)
                {
                    Directory.CreateDirectory(@"S:\Gmail\" + textBox3.Text);
                    Directory.CreateDirectory(@"S:\Gmail\" + textBox3.Text + @"\Inbox");
                    Directory.CreateDirectory(@"S:\Gmail\" + textBox3.Text + @"\Sent Items");
                    Directory.CreateDirectory(@"S:\Gmail\" + textBox3.Text + @"\Draft");
                    Directory.CreateDirectory(@"S:\Gmail\" + textBox3.Text + @"\Trash");
                    TextWriter tw;
                    tw = File.CreateText(@"S:\Gmail\" + textBox3.Text + @"\" + textBox3.Text + ".txt");
                    tw.WriteAsync(textBox3.Text + "," + textBox5.Text + ",");
                    tw.Dispose();
                    DialogResult dr = new DialogResult();
                    dr = MessageBox.Show("Email Id created Successfully", "Gmail", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dr == DialogResult.OK)
                    {
                        this.Hide();
                        Form1 frm1 = new Form1();
                        frm1.Show();
                    }

                }
                Form1 f1 = new Form1();
                f1.ShowDialog();

            }
        }
        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged_1(object sender, EventArgs e)
        {

        }

    }
}