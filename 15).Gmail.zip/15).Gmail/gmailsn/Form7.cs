﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace gmailsn
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           // DirectoryInfo df1 = new DirectoryInfo("D:\\gmail\\" + textBox1.Text + "\\Draft");
           //foreach (String o in df1.GetFiles())
           // {
           //     listBox1.Items.Add(o);
           // }


            TextReader tr1;
            tr1 = File.OpenText("S:\\gmail\\" + textBox1.Text + "\\Draft\\" + listBox1.SelectedItem);
            label1.Text = tr1.ReadToEnd();
            tr1.Dispose();
            }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                File.Move("S:\\gmail\\" + textBox1.Text + "\\Draft\\" + listBox1.SelectedItem, "S:\\gmail\\" + textBox1.Text + "\\Trash\\" + listBox1.SelectedItem);
                DirectoryInfo dft = new DirectoryInfo("S:\\gmail\\" + textBox1.Text + "\\Draft");
                listBox1.Items.Clear();
                foreach (object o in dft.GetFiles())
                {
                    listBox1.Items.Add(o);

                }
                label1.Text = "";
                checkBox1.Checked = false;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        }
    }

