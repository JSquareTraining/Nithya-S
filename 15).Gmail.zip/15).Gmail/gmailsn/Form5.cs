﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace gmailsn
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
       AutoCompleteStringCollection asc = new AutoCompleteStringCollection();

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //String d = textBox1.Text;
            //asc.Add(d);
            //textBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            //textBox1.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //textBox1.AutoCompleteCustomSource = asc;
            //textBox1.Text = "";
        }
        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "")
            {
                MessageBox.Show("please give id to send and receive");
            }

            //else
            //{
            //    String d = textBox1.Text;
            //    asc.Add(d);
            //    textBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            //    textBox1.AutoCompleteSource = AutoCompleteSource.CustomSource;
            //    textBox1.AutoCompleteCustomSource = asc;
            //    textBox1.Text = "";
            //}

            string s1 = textBox1.Text;
            asc.Add(s1);
            textBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            textBox1.AutoCompleteSource = AutoCompleteSource.CustomSource;
            textBox1.AutoCompleteCustomSource = asc;
           




            string s2 = textBox4.Text;








            if (Directory.Exists(@"S:\Gmail\" + s1) == true)
            {
                TextWriter tw;
                TextWriter tw1;
                tw = File.CreateText(@"S:\Gmail\" + s1 + @"\Inbox\" + textBox3.Text + ".txt");
                tw1 = File.CreateText(@"S:\Gmail\" + s2 + @"\Sent Items\" + textBox3.Text + ".txt");
                tw.WriteLine(richTextBox1.Text);
                tw1.WriteLine(richTextBox1.Text);
                tw.Dispose();
                tw1.Dispose();
           }
            DialogResult dr = new DialogResult();
            dr = MessageBox.Show("Message Sent Successfully", "Gmail", MessageBoxButtons.OK, MessageBoxIcon.Information);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            richTextBox1.Text = "";
            if (dr == DialogResult.OK)
            {
                this.Close();
            }
            else
            {
              MessageBox.Show("Give Correct Email Id", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
             //string s1 = textBox1.Text;

            // if (Directory.Exists(@"D:\Gmail\" + s1) == true)
             //{
                 TextWriter tw4;
                 tw4 = File.CreateText(@"S:\Gmail\" + textBox4.Text+ @"\Draft\" + textBox3.Text + ".txt");
                 tw4.WriteLine(richTextBox1.Text);
                 tw4.Dispose();
                 this.Close();

                 textBox1.Text = "";
                 textBox2.Text = "";
                 textBox3.Text = "";
                 richTextBox1.Text = "";

             //}





             //TextReader tr1;
             //tr1 = File.OpenText("D:\\gmail\\" + textBox1.Text + "\\Draft\\");
             //richTextBox1.Text = tr1.ReadToEnd();
             //tr1.Dispose();
        }
    }
}
