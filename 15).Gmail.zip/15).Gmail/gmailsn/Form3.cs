﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace gmailsn
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        Form6 f6 = new Form6();
        Form5 f5 = new Form5();
        Form7 f7 = new Form7();
        Form8 f8 = new Form8();
        Form4 f4 = new Form4();


        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
               
                f6.textBox1.Text = textBox2.Text;
                DirectoryInfo d1 = new DirectoryInfo("S:\\Gmail\\" + textBox2.Text + "\\Sent Items");
                f6.listBox1.Items.Clear();
                foreach (object o in d1.GetFiles())
                {
                    f6.listBox1.Items.Add(o);
                    radioButton2.Checked = false;
                }
               
                f6.ShowDialog();
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
              
               f5.textBox4.Text = textBox2.Text;
               f5.ShowDialog();
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
               f7.textBox1.Text = textBox2.Text;
               DirectoryInfo d1 = new DirectoryInfo("S:\\Gmail\\" + textBox2.Text + "\\Draft");
               f7.listBox1.Items.Clear();
                foreach (object o in d1.GetFiles())
                {
                    f7.listBox1.Items.Add(o);
                    radioButton3.Checked = false;
                }
                 f7.ShowDialog();
            }
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
             if (radioButton4.Checked == true)
            {
                   f8.textBox1.Text = textBox2.Text;
                   DirectoryInfo d1 = new DirectoryInfo("S:\\Gmail\\" + textBox2.Text + "\\Trash");
                   f8.listBox1.Items.Clear();
                   foreach (object o in d1.GetFiles())
                   {
                       f8.listBox1.Items.Add(o);
                       radioButton4.Checked = false;
                   }
                f8.ShowDialog();
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                f4.textBox1.Text = textBox2.Text;
                DirectoryInfo d = new DirectoryInfo("S:\\Gmail\\" + textBox2.Text + "\\Inbox");
                f4.listBox1.Items.Clear();
                foreach (object o in d.GetFiles())
                {
                    f4.listBox1.Items.Add(o);
                    radioButton1.Checked = false;
                }

                f4.ShowDialog();
            }
                 

            }
        }

        

        
    
}
