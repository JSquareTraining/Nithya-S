﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace gmailsn
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        Form1 f1 = new Form1();
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            TextReader tr1;
            tr1 = File.OpenText("S:\\Gmail\\" +textBox1.Text + "\\Inbox\\" + listBox1.SelectedItem);
            label1.Text = tr1.ReadToEnd();
            tr1.Dispose();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            this.Close();
            listBox1.Items.Clear();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                File.Move("S:\\Gmail\\" + textBox1.Text + "\\Inbox\\" + listBox1.SelectedItem, "S:\\Gmail\\" + textBox1.Text + "\\Trash\\" + listBox1.SelectedItem);
                DirectoryInfo dft=new DirectoryInfo("S:\\Gmail\\" + textBox1.Text + "\\Inbox");
                listBox1.Items.Clear();
                foreach (object o in dft.GetFiles())
                {
                    listBox1.Items.Add(o);
                    
                 }
                label1.Text = "";
                checkBox1.Checked = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
        }
    }
}
