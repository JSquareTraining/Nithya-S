﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace userpwd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int i;

        private void btn_Click(object sender, EventArgs e)
        {
            if (txt1.Text == "admin" && txt2.Text == "admin")
            {
                MessageBox.Show("login successfuly", "Login page");
            }

            else if (txt1.Text == "" && txt2.Text == "")
            {
                MessageBox.Show("please enter data", "Login page");
            } 
            else if (txt1.Text != "admin" && txt2.Text == "admin")
            {
                i++;
                MessageBox.Show("check data username wrong","Login page");
                if (i == 3)
                {
                    MessageBox.Show("Sorry chance get over","Login page");
                    this.Close();
                }
                else if (i == 2)
                {
                    MessageBox.Show("one more chance for you","Login page");
                }
                else if (i == 1)
                {
                    MessageBox.Show("Two chance are more", "Login page");
                }
            }
            else if (txt1.Text != "admin" && txt2.Text != "admin")
            {
                i++;
                MessageBox.Show("username and password are wrong", "Login page");
                if (i == 3)
                {
                    MessageBox.Show("Sorry chance get over", "Login page");
                    this.Close();
                }
                else if (i == 2)
                {
                    MessageBox.Show("one more chance for you", "Login page");
                }
                else if (i == 1)
                {
                    MessageBox.Show("Two chance are more", "Login page");
                }
            }
             else if (txt1.Text == "admin" && txt2.Text != "admin")
             {
                 i++;
                 MessageBox.Show("wrong password", "Login page");

                 if (i == 3)
                 {
                     MessageBox.Show("Sorry chance get over", "Login page");
                     this.Close();
                 }
                 else if (i == 2)
                 {
                     MessageBox.Show("one more chance for you", "Login page");
                 }
                 else if (i == 1)
                 {
                     MessageBox.Show("Two chance are more", "Login page");
                 }
               }
            }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
          }
       }
    

         //   for(i=0;i<=3;i++)
         //   {
         //   if(txt1.Text != "admin" && txt2.Text != "admin" || txt1.Text == "admin" && txt2.Text != "admin" || txt1.Text != "admin" && txt2.Text == "admin")
         //    { 
               
         //       {
         //          MessageBox.Show("enter correct format");
         //         }
         //          if(i==1)
         //               {
         //                  MessageBox.Show("you have two chance");
         //                if(i==2)
         //                {
         //              MessageBox.Show("you have one chance");
         //              }
         //                if(i==3)
         //                {
         //                    MessageBox.show("you have one chance");
         //                 }  
         //          }
         //           else  if(i==1)
         //           {   
         //            MessageBox.Show("1 cha");
         //            i++;
         //            }
         //           else if (i == 2)
         //           {
         //            MessageBox.Show("2nd cha");
         //           }
               
         //}
                       



         //       // else if(txt1.Text != "admin" && txt2.Text !="admin")
         //        //{
         //        //        MessageBox.Show("sorry not valid try again");
         //        // }
         //        //else if(txt1.Text =="admin" && txt2.Text !="admin");



                
           
        
    
    
