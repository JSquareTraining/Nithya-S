﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace registration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            //Form2 nn = new Form2();
            //nn.ShowDialog();
            InitializeComponent();

        }
        int i;

        private void btn2_click(object sender, EventArgs e)
        {
            Form2 nn = new Form2();
           
            nn.txt6.Text = txt3.Text;
            nn.txt7.Text = txt4.Text;
            nn.Show();

            //nn.txt3.Text = txt6.text;
        }



        private void btn1_Click(object sender, EventArgs e)
        {
            if (txt1.Text == "admin" && txt2.Text == "admin")
            {
                MessageBox.Show("login successfully");
            }
            else
            {
                MessageBox.Show("User name and password wrongly typed try again");
                i++;
               if (i == 3)
                {
                    MessageBox.Show("Sorry chance get over", "Login page");
                    this.Close();
                }
                else if (i == 2)
                {
                    MessageBox.Show("one more chance for you", "Login page");
                }
                else if (i == 1)
                {
                    MessageBox.Show("Two chance are more", "Login page");
                }

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
                    }

        private void txt3_TextChanged(object sender, EventArgs e)
        {
           txt3.Text = "admin";
           txt4.Text = "admin";
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

    }
}


           // nn.textbox1.Text = lbl1.Text;
            //nn.textbox2.text = lbl2.Text;
        
    


       // int i;

        //private void btn_Click(object sender, EventArgs e)
        //{
        //    if (txt1.Text == "admin" && txt2.Text == "admin")
        //    {
        //        MessageBox.Show("login successfuly", "Login page");
        //    }

        //    else if (txt1.Text == "" && txt2.Text == "")
        //    {
        //        MessageBox.Show("please enter data", "Login page");
        //    } 
        //    else if (txt1.Text != "admin" && txt2.Text == "admin")
        //    {
        //        i++;
        //        MessageBox.Show("check data username wrong","Login page");
        //        if (i == 3)
        //        {
        //            MessageBox.Show("Sorry chance get over","Login page");
        //            this.Close();
        //        }
        //        else if (i == 2)
        //        {
        //            MessageBox.Show("one more chance for you","Login page");
        //        }
        //        else if (i == 1)
        //        {
        //            MessageBox.Show("Two chance are more", "Login page");
        //        }
        //    }
        //    else if (txt1.Text != "admin" && txt2.Text != "admin")
        //    {
        //        i++;
        //        MessageBox.Show("username and password are wrong", "Login page");
        //        if (i == 3)
        //        {
        //            MessageBox.Show("Sorry chance get over", "Login page");
        //            this.Close();
        //        }
        //        else if (i == 2)
        //        {
        //            MessageBox.Show("one more chance for you", "Login page");
        //        }
        //        else if (i == 1)
        //        {
        //            MessageBox.Show("Two chance are more", "Login page");
        //        }
        //    }
        //     else if (txt1.Text == "admin" && txt2.Text != "admin")
        //     {
        //         i++;
        //         MessageBox.Show("wrong password", "Login page");

        //         if (i == 3)
        //         {
        //             MessageBox.Show("Sorry chance get over", "Login page");
        //             this.Close();
        //         }
        //         else if (i == 2)
        //         {
        //             MessageBox.Show("one more chance for you", "Login page");
        //         }
        //         else if (i == 1)
        //         {
        //             MessageBox.Show("Two chance are more", "Login page");
        //         }
        //       }
        
        //}

      
            
    //}
//}
