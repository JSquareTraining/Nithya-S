﻿namespace registration
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.txt5 = new System.Windows.Forms.TextBox();
            this.txt6 = new System.Windows.Forms.TextBox();
            this.txt7 = new System.Windows.Forms.TextBox();
            this.txt8 = new System.Windows.Forms.TextBox();
            this.bbtn1 = new System.Windows.Forms.Button();
            this.txt10 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(274, 99);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(106, 20);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Name";
            // 
            // lbl2
            // 
            this.lbl2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(274, 142);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(98, 26);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "UserName";
            // 
            // lbl3
            // 
            this.lbl3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(274, 188);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(100, 23);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "Password";
            // 
            // lbl4
            // 
            this.lbl4.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.Location = new System.Drawing.Point(274, 238);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(100, 23);
            this.lbl4.TabIndex = 3;
            this.lbl4.Text = "City";
            // 
            // txt5
            // 
            this.txt5.Location = new System.Drawing.Point(408, 99);
            this.txt5.Name = "txt5";
            this.txt5.Size = new System.Drawing.Size(100, 20);
            this.txt5.TabIndex = 4;
            this.txt5.TextChanged += new System.EventHandler(this.txt5_TextChanged);
            // 
            // txt6
            // 
            this.txt6.Location = new System.Drawing.Point(408, 142);
            this.txt6.Name = "txt6";
            this.txt6.Size = new System.Drawing.Size(100, 20);
            this.txt6.TabIndex = 5;
            this.txt6.TextChanged += new System.EventHandler(this.txt6_TextChanged);
            // 
            // txt7
            // 
            this.txt7.Location = new System.Drawing.Point(408, 191);
            this.txt7.Name = "txt7";
            this.txt7.Size = new System.Drawing.Size(100, 20);
            this.txt7.TabIndex = 6;
            this.txt7.UseSystemPasswordChar = true;
            // 
            // txt8
            // 
            this.txt8.Location = new System.Drawing.Point(408, 238);
            this.txt8.Name = "txt8";
            this.txt8.Size = new System.Drawing.Size(100, 20);
            this.txt8.TabIndex = 7;
            // 
            // bbtn1
            // 
            this.bbtn1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bbtn1.Location = new System.Drawing.Point(335, 304);
            this.bbtn1.Name = "bbtn1";
            this.bbtn1.Size = new System.Drawing.Size(173, 49);
            this.bbtn1.TabIndex = 8;
            this.bbtn1.Text = "REGISTRATION";
            this.bbtn1.UseVisualStyleBackColor = true;
            this.bbtn1.Click += new System.EventHandler(this.bbtn_click);
            // 
            // txt10
            // 
            this.txt10.Location = new System.Drawing.Point(533, 99);
            this.txt10.Name = "txt10";
            this.txt10.Size = new System.Drawing.Size(100, 20);
            this.txt10.TabIndex = 9;
            this.txt10.Text = "admin";
            this.txt10.Visible = false;
            this.txt10.TextChanged += new System.EventHandler(this.txt10_TextChanged);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Bisque;
            this.ClientSize = new System.Drawing.Size(892, 485);
            this.Controls.Add(this.txt10);
            this.Controls.Add(this.bbtn1);
            this.Controls.Add(this.txt8);
            this.Controls.Add(this.txt7);
            this.Controls.Add(this.txt6);
            this.Controls.Add(this.txt5);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.TextBox txt8;
        private System.Windows.Forms.Button bbtn1;
        public System.Windows.Forms.TextBox txt6;
        public System.Windows.Forms.TextBox txt7;
        public System.Windows.Forms.TextBox txt5;
        private System.Windows.Forms.TextBox txt10;
    }
}