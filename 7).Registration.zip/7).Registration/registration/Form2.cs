﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace registration
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
              
                }

        private void bbtn_click(object sender, EventArgs e)
        {
            Form3 n3 = new Form3();
            n3.txt9.Text = txt10.Text;
            n3.ShowDialog();
                      
          
        }

        private void txt5_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txt6_TextChanged(object sender, EventArgs e)
        {
           // txt6.Text = "admin";
        }

        private void txt10_TextChanged(object sender, EventArgs e)
        {
            //txt10.Text ="admin";
        }

        //private void textBox2_TextChanged(object sender, EventArgs e)
        //{
        //    textBox2.Text = lbl1.Text;
        //}

        //private void bbtn1_Click(object sender, EventArgs e)
        //{

        //}
    }
}
