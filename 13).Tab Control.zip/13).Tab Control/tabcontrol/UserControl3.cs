﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

namespace tabcontrol
{
    public partial class UserControl3 : UserControl
    {
        private Properties.Settings pp;
        private ResourceManager r;
        public UserControl3()
        {
            InitializeComponent();
            pp = new Properties.Settings();
            r = new ResourceManager("tabcontrol.Resource3", Assembly.GetExecutingAssembly());
        }
        private void UserControl3_Load(object sender, EventArgs e)
        {
            if (pp.sub == 1)
            {
                groupBox1.Text = r.GetString("q1");
                radioButton1.Text = r.GetString("r1");
                radioButton2.Text = r.GetString("r2");
                radioButton3.Text = r.GetString("r3");
                radioButton4.Text = r.GetString("r4");


                groupBox2.Text = r.GetString("q2");
                radioButton5.Text = r.GetString("r5");
                radioButton6.Text = r.GetString("r6");
                radioButton7.Text = r.GetString("r7");
                radioButton8.Text = r.GetString("r8");

                groupBox3.Text = r.GetString("q3");
                radioButton9.Text = r.GetString("r9");
                radioButton10.Text = r.GetString("r10");
                radioButton11.Text = r.GetString("r11");
                radioButton12.Text = r.GetString("r12");

                groupBox4.Text = r.GetString("q4");
                radioButton13.Text = r.GetString("r13");
                radioButton14.Text = r.GetString("r14");
                radioButton15.Text = r.GetString("r15");
                radioButton16.Text = r.GetString("r16");


                groupBox5.Text = r.GetString("q5");
                radioButton17.Text = r.GetString("r17");
                radioButton18.Text = r.GetString("r18");
                radioButton19.Text = r.GetString("r19");
                radioButton20.Text = r.GetString("r20");


            }
            else if (pp.sub == 2)
            {
                groupBox1.Text = r.GetString("q6");
                radioButton1.Text = r.GetString("r21");
                radioButton2.Text = r.GetString("r22");
                radioButton3.Text = r.GetString("r23");
                radioButton4.Text = r.GetString("r24");


                groupBox2.Text = r.GetString("q7");
                radioButton5.Text = r.GetString("r25");
                radioButton6.Text = r.GetString("r26");
                radioButton7.Text = r.GetString("r27");
                radioButton8.Text = r.GetString("r28");

                groupBox3.Text = r.GetString("q8");
                radioButton9.Text = r.GetString("r29");
                radioButton10.Text = r.GetString("r30");
                radioButton11.Text = r.GetString("r31");
                radioButton12.Text = r.GetString("r32");



                groupBox4.Text = r.GetString("q9");
                radioButton13.Text = r.GetString("r33");
                radioButton14.Text = r.GetString("r34");
                radioButton15.Text = r.GetString("r35");
                radioButton16.Text = r.GetString("r36");

                groupBox5.Text = r.GetString("q10");
                radioButton17.Text = r.GetString("r37");
                radioButton18.Text = r.GetString("r38");
                radioButton19.Text = r.GetString("r39");
                radioButton20.Text = r.GetString("r40");

            }
            else if (pp.sub == 3)
            {
                groupBox1.Text = r.GetString("q11");
                radioButton1.Text = r.GetString("r41");
                radioButton2.Text = r.GetString("r42");
                radioButton3.Text = r.GetString("r43");
                radioButton4.Text = r.GetString("r44");

                groupBox2.Text = r.GetString("q12");
                radioButton5.Text = r.GetString("r45");
                radioButton6.Text = r.GetString("r46");
                radioButton7.Text = r.GetString("r47");
                radioButton8.Text = r.GetString("r48");

                groupBox3.Text = r.GetString("q13");
                radioButton9.Text = r.GetString("r49");
                radioButton10.Text = r.GetString("r50");
                radioButton11.Text = r.GetString("r51");
                radioButton12.Text = r.GetString("r52");

                groupBox4.Text = r.GetString("q14");
                radioButton13.Text = r.GetString("r53");
                radioButton14.Text = r.GetString("r54");
                radioButton15.Text = r.GetString("r55");
                radioButton16.Text = r.GetString("r56");

                groupBox5.Text = r.GetString("q15");
                radioButton17.Text = r.GetString("r57");
                radioButton18.Text = r.GetString("r58");
                radioButton19.Text = r.GetString("r59");
                radioButton20.Text = r.GetString("r60");
            }


        }
        public static int q11;
        public static int q12;
        public static int q13;
        public static int q14;
        public static int q15;

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked != true && radioButton2.Checked != true && radioButton3.Checked != true && radioButton4.Checked != true)
            {
                MessageBox.Show("please answer question no 1");
            }


            if (radioButton5.Checked != true && radioButton6.Checked != true && radioButton7.Checked != true && radioButton8.Checked != true)
            {
                MessageBox.Show("please answer question no 2");
            }
           if (radioButton9.Checked != true && radioButton10.Checked != true && radioButton11.Checked != true && radioButton12.Checked != true)
            {
                MessageBox.Show("please answer question no 3");
            }

            if (radioButton13.Checked != true && radioButton14.Checked != true && radioButton15.Checked != true && radioButton16.Checked != true)
            {
                MessageBox.Show("please answer question no 4");
            }
            if (radioButton17.Checked != true && radioButton18.Checked != true && radioButton19.Checked != true && radioButton20.Checked != true)
            {
                MessageBox.Show("please answer question no 5");
            }

            if (pp.sub == 1)
            {
                foreach (RadioButton rdb1 in groupBox1.Controls)
                {
                    if (rdb1.Checked == true)
                    {
                        if (rdb1.Text == "Framework")
                        {
                            l3.BackColor = Color.Green;
                            q11 = 1;
                        }
                        else
                        {
                           l3.BackColor = Color.Red;
                           q11 = 0;
                        }
                    }
                }
                foreach (RadioButton rdb2 in groupBox2.Controls)
                {
                    if (rdb2.Checked == true)
                    {
                        if (rdb2.Text == "Native code")
                        {
                           l4.BackColor = Color.Green;
                           q12 = 1;
                        }
                        else
                        {
                           l4.BackColor = Color.Red;
                           q12 = 0;
                        }
                    }

                }



                foreach (RadioButton rdb3 in groupBox3.Controls)
                {
                    if (rdb3.Checked == true)
                    {
                        if (rdb3.Text == "Assembly")
                        {
                           l5.BackColor = Color.Green;
                           q13 = 1;

                        }
                        else
                        {
                           l5.BackColor = Color.Red;
                           q13 = 0;
                        }
                    }
                }




                foreach (RadioButton rdb4 in groupBox4.Controls)
                {
                    if (rdb4.Checked == true)
                    {
                        if (rdb4.Text == "XML")
                        {
                            l6.BackColor = Color.Green;
                            q14 = 1;
                        }
                        else
                        {
                            l6.BackColor = Color.Red;
                            q14 = 0;
                        }
                    }
                }


                foreach (RadioButton rdb5 in groupBox5.Controls)
                {
                    if (rdb5.Checked == true)
                    {
                        if (rdb5.Text == "f9")
                        {
                            l7.BackColor = Color.Green;
                            q15 = 1;
                        }
                        else
                        {
                           l7.BackColor = Color.Red;
                           q15 = 0;
                        }
                    }
                }
                pp.sub = 2;
                pp.Save();
            }

            else if (pp.sub == 2)
            {

                foreach (RadioButton rdb6 in groupBox1.Controls)
                {
                    if (rdb6.Checked == true)
                    {
                        if (rdb6.Text == "f4")
                        {
                            l3.BackColor = Color.Green;
                        }
                        else
                        {
                            l3.BackColor = Color.Red;
                        }
                    }
                }



                foreach (RadioButton rdb7 in groupBox2.Controls)
                {
                    if (rdb7.Checked == true)
                    {
                        if (rdb7.Text == "animation")
                        {
                             l4.BackColor = Color.Green;
                        }
                        else
                        {
                            l4.BackColor = Color.Red;
                        }
                    }

                }



                foreach (RadioButton rdb8 in groupBox3.Controls)
                {
                    if (rdb8.Checked == true)
                    {
                        if (rdb8.Text == "44")
                        {
                             l5.BackColor = Color.Green;
                        }
                        else
                        {
                            l5.BackColor = Color.Red;
                        }
                    }
                }




                foreach (RadioButton rdb9 in groupBox4.Controls)
                {
                    if (rdb9.Checked == true)
                    {
                        if (rdb9.Text == "common lang specification")
                        {
                            l6.BackColor = Color.Green;
                        }
                        else
                        {
                            l6.BackColor = Color.Red;
                        }
                    }

                }


                foreach (RadioButton rdb10 in groupBox5.Controls)
                {
                    if (rdb10.Checked == true)
                    {
                        if (rdb10.Text == "microsoft")
                        {
                            l7.BackColor = Color.Green;
                        }
                        else
                        {
                            l7.BackColor = Color.Red;
                        }

                    }
                }

                pp.sub = 3;
                pp.Save();


            }

            else if (pp.sub == 3)
            {
                foreach (RadioButton rdb11 in groupBox1.Controls)
                {
                    if (rdb11.Checked == true)
                    {
                        if (rdb11.Text == "2002")
                        {
                            l3.BackColor = Color.Green;
                        }
                        else
                        {
                            l3.BackColor = Color.Red;
                        }
                    }
                }



                foreach (RadioButton rdb12 in groupBox2.Controls)
                {
                    if (rdb12.Checked == true)
                    {
                        if (rdb12.Text == "multi language")
                        {
                           l4.BackColor = Color.Green;
                        }
                        else
                        {
                          l4.BackColor = Color.Red;
                        }
                    }

                }



                foreach (RadioButton rdb13 in groupBox3.Controls)
                {
                    if (rdb13.Checked == true)
                    {
                        if (rdb13.Text == "compiler")
                        {
                            l5.BackColor = Color.Green;
                        }
                        else
                        {
                            l5.BackColor = Color.Red;
                        }
                    }
                }




                foreach (RadioButton rdb14 in groupBox4.Controls)
                {
                    if (rdb14.Checked == true)
                    {
                        if (rdb14.Text == "compiler")
                        {
                            l6.BackColor = Color.Green;
                        }
                        else
                        {
                           l6.BackColor = Color.Red;
                        }
                    }

                }


                foreach (RadioButton rdb15 in groupBox5.Controls)
                {
                    if (rdb15.Checked == true)
                    {
                        if (rdb15.Text == "3.0")
                        {
                          l7.BackColor = Color.Green;
                        }
                        else
                        {
                          l7.BackColor = Color.Red;
                        }
                }
               }
                pp.sub = 1;
                pp.Save();
            }

        }
    }
}
