﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Resources;
using System.Reflection;

namespace tabcontrol
{
    public partial class UserControl1 : UserControl
    {
        private ResourceManager or;
        private Properties.Settings ps;
        public UserControl1()
        {
            InitializeComponent();
            ps = new Properties.Settings();
            or = new ResourceManager("tabcontrol.Resource1", Assembly.GetExecutingAssembly());
        }
               
         private void UserControl1_Load(object sender, EventArgs e)
        {
            if (ps.couple == 1)
            {
                groupBox1.Text = or.GetString("q1");
                radioButton1.Text = or.GetString("r1");
                radioButton2.Text = or.GetString("r2");
                radioButton3.Text = or.GetString("r3");
                radioButton4.Text = or.GetString("r4");
                groupBox2.Text = or.GetString("q2");
                radioButton5.Text = or.GetString("r5");
                radioButton6.Text = or.GetString("r6");
                radioButton7.Text = or.GetString("r7");
                radioButton8.Text = or.GetString("r8");
                groupBox3.Text = or.GetString("q3");
                radioButton9.Text = or.GetString("r9");
                radioButton10.Text = or.GetString("r10");
                radioButton11.Text = or.GetString("r11");
                radioButton12.Text = or.GetString("r12");
                groupBox4.Text = or.GetString("q4");
                radioButton13.Text = or.GetString("r13");
                radioButton14.Text = or.GetString("r14");
                radioButton15.Text = or.GetString("r15");
                radioButton16.Text = or.GetString("r16");
                groupBox5.Text = or.GetString("q5");
                radioButton17.Text = or.GetString("r17");
                radioButton18.Text = or.GetString("r18");
                radioButton19.Text = or.GetString("r19");
                radioButton20.Text = or.GetString("r20");
            }
            else if (ps.couple == 2)
            {
                groupBox1.Text = or.GetString("q6");
                radioButton1.Text = or.GetString("r21");
                radioButton2.Text = or.GetString("r22");
                radioButton3.Text = or.GetString("r23");
                radioButton4.Text = or.GetString("r24");
                groupBox2.Text = or.GetString("q7");
                radioButton5.Text = or.GetString("r25");
                radioButton6.Text = or.GetString("r26");
                radioButton7.Text = or.GetString("r27");
                radioButton8.Text = or.GetString("r28");
                groupBox3.Text = or.GetString("q8");
                radioButton9.Text = or.GetString("r29");
                radioButton10.Text = or.GetString("r30");
                radioButton11.Text = or.GetString("r31");
                radioButton12.Text = or.GetString("r32");
                groupBox4.Text = or.GetString("q9");
                radioButton13.Text = or.GetString("r33");
                radioButton14.Text = or.GetString("r34");
                radioButton15.Text = or.GetString("r35");
                radioButton16.Text = or.GetString("r36");
                groupBox5.Text = or.GetString("q10");
                radioButton17.Text = or.GetString("r37");
                radioButton18.Text = or.GetString("r38");
                radioButton19.Text = or.GetString("r39");
                radioButton20.Text = or.GetString("r40");
            }
            else if (ps.couple == 3)
            {
                groupBox1.Text = or.GetString("q11");
                radioButton1.Text = or.GetString("r41");
                radioButton2.Text = or.GetString("r42");
                radioButton3.Text = or.GetString("r43");
                radioButton4.Text = or.GetString("r44");
                groupBox2.Text = or.GetString("q12");
                radioButton5.Text = or.GetString("r45");
                radioButton6.Text = or.GetString("r46");
                radioButton7.Text = or.GetString("r47");
                radioButton8.Text = or.GetString("r48");
                groupBox3.Text = or.GetString("q13");
                radioButton9.Text = or.GetString("r49");
                radioButton10.Text = or.GetString("r50");
                radioButton11.Text = or.GetString("r51");
                radioButton12.Text = or.GetString("r52");
                groupBox4.Text = or.GetString("q14");
                radioButton13.Text = or.GetString("r53");
                radioButton14.Text = or.GetString("r54");
                radioButton15.Text = or.GetString("r55");
                radioButton16.Text = or.GetString("r56");
                groupBox5.Text = or.GetString("q15");
                radioButton17.Text = or.GetString("r57");
                radioButton18.Text = or.GetString("r58");
                radioButton19.Text = or.GetString("r59");
                radioButton20.Text = or.GetString("r60");
            }
        }
         public static int q1;
         public static int q2;
         public static int q3;
         public static int q4;
         public static int q5;
         private void btn2_Click(object sender, EventArgs e)
         {
                      {
                 if (radioButton1.Checked != true && radioButton2.Checked != true && radioButton3.Checked != true && radioButton4.Checked != true)
                 {
                     MessageBox.Show("please answer question no 1");
                 }
                 if (radioButton5.Checked != true && radioButton6.Checked != true && radioButton7.Checked != true && radioButton8.Checked != true)
                 {
                     MessageBox.Show("please answer question no 2");
                 }
                 if (radioButton9.Checked != true && radioButton10.Checked != true && radioButton11.Checked != true && radioButton12.Checked != true)
                 {
                     MessageBox.Show("please answer question no 3");
                 }
                 if (radioButton13.Checked != true && radioButton14.Checked != true && radioButton15.Checked != true && radioButton16.Checked != true)
                 {
                     MessageBox.Show("please answer question no 4");
                 }
                 if (radioButton17.Checked != true && radioButton18.Checked != true && radioButton19.Checked != true && radioButton20.Checked != true)
                 {
                     MessageBox.Show("please answer question no 5");
                 }
             }

             if (ps.couple == 1)
             {
                 foreach (RadioButton rdb1 in groupBox1.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r1"))
                         {
                             l3.BackColor = Color.Green;
                             q1 = 1;
                         }
                         else
                         {
                             l3.BackColor = Color.Red;
                             q1 = 0;
                         }
                     }
                 }

                 foreach (RadioButton rdb1 in groupBox2.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r6"))
                         {
                             l4.BackColor = Color.Green;
                             q2 = 1;
                         }
                         else
                         {
                             l4.BackColor = Color.Red;
                             q2 = 0;
                         }
                     }
                 }


                 foreach (RadioButton rdb1 in groupBox3.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r11"))
                         {
                                                   
                             l5.BackColor = Color.Green;
                             q3 = 1;
                          }
                         else
                         {
                             l5.BackColor = Color.Red;
                             q3 = 0;
                         }
                     }
                 }

                 foreach (RadioButton rdb1 in groupBox4.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r14"))
                         {
                             l6.BackColor = Color.Green;
                             q4 = 1;
                         }
                         else
                         {
                             l6.BackColor = Color.Red;
                             q4 = 0;
                         }
                     }
                 }




                 foreach (RadioButton rdb1 in groupBox5.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r17"))
                         {
                             l7.BackColor = Color.Green;
                             q5 = 1;
                         }
                         else
                         {
                             l7.BackColor = Color.Red;
                             q5 = 0;
                         }
                     }
                 }
                 ps.couple = 2;
                 ps.Save();
             }
             else if (ps.couple == 2)
             {
                 foreach (RadioButton rdb1 in groupBox1.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r21"))
                         {
                             l3.BackColor = Color.Green;
                             q1 = 1;
                         }
                         else
                         {
                             l3.BackColor = Color.Red;
                             q1 = 0;
                         }
                     }
                 }


                 foreach (RadioButton rdb1 in groupBox2.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r27"))
                         {
                             l4.BackColor = Color.Green;
                             q2 = 1;
                         }
                         else
                         {                             
                             l4.BackColor = Color.Red;
                             q2 = 0;
                         }
                     }
                 }

                 foreach (RadioButton rdb1 in groupBox3.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r29"))
                         {
                             l5.BackColor = Color.Green;
                             q3 = 1;

                         }
                         else
                         {
                             l5.BackColor = Color.Red;
                             q3 = 0;
                         }
                     }
                 }

                 foreach (RadioButton rdb1 in groupBox4.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r33"))
                         {
                             l6.BackColor = Color.Green;
                             q4 = 1;

                         }
                         else
                         {
                             l6.BackColor = Color.Red;
                             q4 = 0;

                         }
                     }
                 }


                 foreach (RadioButton rdb1 in groupBox5.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r38"))
                         {
                             l7.BackColor = Color.Green;
                             q5 = 1;
                         }
                         else
                         {
                             l7.BackColor = Color.Red;
                             q5 = 0;
                         }
                     }
                 }

                 ps.couple = 3;
                 ps.Save();


             }
             else if (ps.couple == 3)
             {
                 foreach (RadioButton rdb1 in groupBox1.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r44"))
                         {
                             l3.BackColor = Color.Green;
                             q1 = 1;
                        }
                         else
                         {
                             l3.BackColor = Color.Red;
                             q1 = 0;
                         }
                     }
                 }

                 foreach (RadioButton rdb1 in groupBox2.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r45"))
                         {
                             l4.BackColor = Color.Green;
                             q2 = 1;
                         }
                         else
                         {
                            l4.BackColor = Color.Red;
                             q2 = 0;
                         }
                     }
                 }

                 foreach (RadioButton rdb1 in groupBox3.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r51"))
                         {
                             l5.BackColor = Color.Green;
                             q3 = 1;
                         }
                         else
                         {
                             l5.BackColor = Color.Red;
                             q3 = 0;
                         }
                     }
                 }

                 foreach (RadioButton rdb1 in groupBox4.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r54"))
                         {
                               l6.BackColor = Color.Green;
                               q4 = 1;
                         }
                         else
                         {
                             l6.BackColor = Color.Red;
                             q4 = 0;
                         }
                     }
                 }

                 foreach (RadioButton rdb1 in groupBox5.Controls)
                 {
                     if (rdb1.Checked == true)
                     {
                         if (rdb1.Text == or.GetString("r58"))
                         {
                             l7.BackColor = Color.Green;
                             q5 = 1;
                         }
                         else
                         {
                             l7.BackColor = Color.Red;
                             q5 = 0;
                         }
                     }
                 }
                 ps.couple = 1;
                 ps.Save();
             }
            
                              
         }

         private void button1_Click(object sender, EventArgs e)
         {
             
         }

         private void l5_Click(object sender, EventArgs e)
         {

         }

         private void l4_Click(object sender, EventArgs e)
         {

         }

         private void l3_Click(object sender, EventArgs e)
         {

         }

         private void l6_Click(object sender, EventArgs e)
         {

         }

         private void l7_Click(object sender, EventArgs e)
         {

         }
    }
}
