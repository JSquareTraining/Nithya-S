﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace tabcontrol
{
    public partial class Form1 : Form
    {
        UserControl1 un1 = new UserControl1();
        UserControl2 un2 = new UserControl2();
        UserControl3 un3 = new UserControl3();
       // private ResourceManager or;
        private Properties.Settings ps;
        
        public Form1()
        {
            InitializeComponent();
            ps = new Properties.Settings();
           // or = new ResourceManager("tabcontrol.Resource1", Assembly.GetExecutingAssembly());
        }

        private void btn1_Click(object sender, EventArgs e)
        {
             if (textBox1.Text != "")
            {
                if (checkBox1.Checked || checkBox2.Checked || checkBox3.Checked)
                {
                    if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == false)
                    {
                        UserControl1 un1 = new UserControl1();
                        tabControl1.TabPages[1].Controls.Add(un1);
                        un1.textBox1.Text = this.textBox1.Text;
                        un1.checkBox1.Checked = this.checkBox1.Checked;
                        un1.checkBox2.Checked = this.checkBox2.Checked;
                        un1.checkBox3.Checked = this.checkBox3.Checked;
                    }
                    else if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == false)
                    {
                        UserControl2 un2 = new UserControl2();
                        tabControl1.TabPages[1].Controls.Add(un2);
                        un2.textBox1.Text = this.textBox1.Text;
                        un2.checkBox1.Checked = this.checkBox1.Checked;
                        un2.checkBox2.Checked = this.checkBox2.Checked;
                        un2.checkBox3.Checked = this.checkBox3.Checked;
                    }
                    else if (checkBox1.Checked == false && checkBox2.Checked == false && checkBox3.Checked == true)
                    {
                        UserControl3 un3 = new UserControl3();
                        tabControl1.TabPages[1].Controls.Add(un3);
                        un3.textBox1.Text = this.textBox1.Text;
                        un3.checkBox1.Checked = this.checkBox1.Checked;
                        un3.checkBox2.Checked = this.checkBox2.Checked;
                        un3.checkBox3.Checked = this.checkBox3.Checked;
                    }
                    else if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == false)
                    {
                        UserControl1 un1 = new UserControl1();
                        tabControl1.TabPages[1].Controls.Add(un1);
                        un1.textBox1.Text = this.textBox1.Text;
                        un1.checkBox1.Checked = this.checkBox1.Checked;
                        un1.checkBox2.Checked = this.checkBox2.Checked;
                        un1.checkBox3.Checked = this.checkBox3.Checked;
                        
                    }
                    else if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == true)
                    {
                        UserControl1 un1 = new UserControl1();
                        tabControl1.TabPages[1].Controls.Add(un1);
                        un1.textBox1.Text = this.textBox1.Text;
                        un1.checkBox1.Checked = this.checkBox1.Checked;
                        un1.checkBox2.Checked = this.checkBox2.Checked;
                        un1.checkBox3.Checked = this.checkBox3.Checked;
                    }
                    else if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
                    {
                        UserControl2 un2 = new UserControl2();
                        tabControl1.TabPages[1].Controls.Add(un2);
                        un2.textBox1.Text = this.textBox1.Text;
                        un2.checkBox1.Checked = this.checkBox1.Checked;
                        un2.checkBox2.Checked = this.checkBox2.Checked;
                        un2.checkBox3.Checked = this.checkBox3.Checked;
                    }
                    else if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
                    {
                        UserControl1 un1 = new UserControl1();
                        tabControl1.TabPages[1].Controls.Add(un1);
                        un1.textBox1.Text = this.textBox1.Text;
                        un1.checkBox1.Checked = this.checkBox1.Checked;
                        un1.checkBox2.Checked = this.checkBox2.Checked;
                        un1.checkBox3.Checked = this.checkBox3.Checked;
                    }
                   tabControl1.SelectedTab = tabControl1.TabPages[1];
                }
                else
                {
                    MessageBox.Show("select any subject");
                }
            }
            else
            {
                MessageBox.Show("enter your name");
                textBox1.Text = textBox1.Text;
            }
        }



        private void checkBox18_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void checkBox17_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void checkBox16_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Layout(object sender, LayoutEventArgs e)
        {
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Layout(object sender, LayoutEventArgs e)
        {
        }
                          

        private void button2_Click_1(object sender, EventArgs e)
        {
           // if (ps.couple == 1)
           // {
                if (UserControl1.q1 == 1)
                {
                    lbl5.BackColor = Color.Green;
                }
                else
                {
                    lbl5.BackColor = Color.Red;
                }
                if (UserControl1.q2 == 1)
                {
                    lbl6.BackColor = Color.Green;
                }
                else
                {
                    lbl6.BackColor = Color.Red;
                }
                if (UserControl1.q3 == 1)
                {
                    lbl7.BackColor = Color.Green;
                }
                else
                {
                    lbl7.BackColor = Color.Red;
                }
                if (UserControl1.q4 == 1)
                {
                    lbl8.BackColor = Color.Green;
                }
                else
                {
                    lbl8.BackColor = Color.Red;
                }
                if (UserControl1.q5 == 1)
                {
                    lbl9.BackColor = Color.Green;
                }
                else
                {
                    lbl9.BackColor = Color.Red;
                }

               if (UserControl2.q6 == 1)
                {
                    lbl10.BackColor = Color.Green;
                }
                else
                {
                    lbl10.BackColor = Color.Red;
                }
                if (UserControl2.q7 == 1)
                {
                    lbl11.BackColor = Color.Green;
                }
                else
                {
                    lbl11.BackColor = Color.Red;
                }
                if (UserControl2.q8 == 1)
                {
                    lbl12.BackColor = Color.Green;
                }
                else
                {
                    lbl12.BackColor = Color.Red;
                }
                if (UserControl2.q9 == 1)
                {
                    lbl13.BackColor = Color.Green;
                }
                else
                {
                    lbl13.BackColor = Color.Red;
                }
                if (UserControl2.q10 == 1)
                {
                    lbl14.BackColor = Color.Green;
                }
                else
                {
                    lbl14.BackColor = Color.Red;
                }
                if (UserControl3.q11 == 1)
                {
                    lbl14.BackColor = Color.Green;
                }
                else
                {
                    lbl14.BackColor = Color.Red;
                }
                if (UserControl3.q12 == 1)
                {
                    lbl14.BackColor = Color.Green;
                }
                else
                {
                    lbl14.BackColor = Color.Red;
                }
                if (UserControl3.q13 == 1)
                {
                    lbl14.BackColor = Color.Green;
                }
                else
                {
                    lbl14.BackColor = Color.Red;
                }
                if (UserControl3.q14 == 1)
                {
                    lbl14.BackColor = Color.Green;
                }
                else
                {
                    lbl14.BackColor = Color.Red;
                }
                if (UserControl3.q15 == 1)
                {
                    lbl14.BackColor = Color.Green;
                }
                else
                {
                    lbl14.BackColor = Color.Red;
                }
            
           tabControl1.SelectedTab = tabControl1.TabPages[2];
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == false)
            {
                tabControl1.TabPages[1].Controls.Clear();
                tabControl1.TabPages[1].Controls.Add(un2);
                un2.textBox1.Text = this.textBox1.Text;
                un2.checkBox1.Checked = this.checkBox1.Checked;
                un2.checkBox2.Checked = this.checkBox2.Checked;
                un2.checkBox3.Checked = this.checkBox3.Checked;
            }
            if (checkBox1.Checked == true && checkBox2.Checked == false && checkBox3.Checked == true)
            {
                tabControl1.TabPages[1].Controls.Clear();
                tabControl1.TabPages[1].Controls.Add(un3);
                un2.textBox1.Text = this.textBox1.Text;
                un2.checkBox1.Checked = this.checkBox1.Checked;
                un2.checkBox2.Checked = this.checkBox2.Checked;
                un2.checkBox3.Checked = this.checkBox3.Checked;
            }
            if (checkBox1.Checked == false && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                tabControl1.TabPages[1].Controls.Clear();
                tabControl1.TabPages[1].Controls.Add(un3);
                un2.textBox1.Text = this.textBox1.Text;
                un2.checkBox1.Checked = this.checkBox1.Checked;
                un2.checkBox2.Checked = this.checkBox2.Checked;
                un2.checkBox3.Checked = this.checkBox3.Checked;
            }
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true)
            {
                tabControl1.TabPages[1].Controls.Clear();
                tabControl1.TabPages[1].Controls.Add(un2);
                un2.textBox1.Text = this.textBox1.Text;
                un2.checkBox1.Checked = this.checkBox1.Checked;
                un2.checkBox2.Checked = this.checkBox2.Checked;
                un2.checkBox3.Checked = this.checkBox3.Checked;
                button4.Visible = true;
              }
        }

       private void button4_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages[1].Controls.Clear();
            tabControl1.TabPages[1].Controls.Add(un3);
            un2.textBox1.Text = this.textBox1.Text;
            un2.checkBox1.Checked = this.checkBox1.Checked;
            un2.checkBox2.Checked = this.checkBox2.Checked;
            un2.checkBox3.Checked = this.checkBox3.Checked;
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            tabControl1.TabPages[1].Controls.Clear();
            tabControl1.TabPages[1].Controls.Add(un3);
            un2.textBox1.Text = this.textBox1.Text;
            un2.checkBox1.Checked = this.checkBox1.Checked;
            un2.checkBox2.Checked = this.checkBox2.Checked;
            un2.checkBox3.Checked = this.checkBox3.Checked;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}








