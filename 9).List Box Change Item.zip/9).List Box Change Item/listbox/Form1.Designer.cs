﻿namespace listbox
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listboxone = new System.Windows.Forms.ListBox();
            this.listboxtwo = new System.Windows.Forms.ListBox();
            this.se_btn = new System.Windows.Forms.Button();
            this.all_btn = new System.Windows.Forms.Button();
            this.rse_btn = new System.Windows.Forms.Button();
            this.rall_btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listboxone
            // 
            this.listboxone.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listboxone.FormattingEnabled = true;
            this.listboxone.ItemHeight = 19;
            this.listboxone.Items.AddRange(new object[] {
            "C",
            "C++",
            "JAVA",
            "J2EE",
            "VB",
            "VB.NET",
            "ASP.NET",
            "ADO.NET",
            "ORACLE",
            "SQL",
            "JAVASCRIPT",
            "VBSCRIPT"});
            this.listboxone.Location = new System.Drawing.Point(148, 79);
            this.listboxone.Name = "listboxone";
            this.listboxone.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listboxone.Size = new System.Drawing.Size(120, 289);
            this.listboxone.TabIndex = 0;
            // 
            // listboxtwo
            // 
            this.listboxtwo.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listboxtwo.FormattingEnabled = true;
            this.listboxtwo.ItemHeight = 19;
            this.listboxtwo.Location = new System.Drawing.Point(492, 91);
            this.listboxtwo.Name = "listboxtwo";
            this.listboxtwo.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listboxtwo.Size = new System.Drawing.Size(120, 270);
            this.listboxtwo.TabIndex = 1;
            // 
            // se_btn
            // 
            this.se_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.se_btn.Location = new System.Drawing.Point(352, 91);
            this.se_btn.Name = "se_btn";
            this.se_btn.Size = new System.Drawing.Size(60, 50);
            this.se_btn.TabIndex = 2;
            this.se_btn.Text = ">";
            this.se_btn.UseVisualStyleBackColor = true;
            this.se_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // all_btn
            // 
            this.all_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.all_btn.Location = new System.Drawing.Point(352, 166);
            this.all_btn.Name = "all_btn";
            this.all_btn.Size = new System.Drawing.Size(60, 50);
            this.all_btn.TabIndex = 3;
            this.all_btn.Text = ">>";
            this.all_btn.UseVisualStyleBackColor = true;
            this.all_btn.Click += new System.EventHandler(this.all_btn_Click);
            // 
            // rse_btn
            // 
            this.rse_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rse_btn.Location = new System.Drawing.Point(352, 234);
            this.rse_btn.Name = "rse_btn";
            this.rse_btn.Size = new System.Drawing.Size(60, 50);
            this.rse_btn.TabIndex = 4;
            this.rse_btn.Text = "<";
            this.rse_btn.UseVisualStyleBackColor = true;
            this.rse_btn.Click += new System.EventHandler(this.rse_btn_Click);
            // 
            // rall_btn
            // 
            this.rall_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rall_btn.Location = new System.Drawing.Point(352, 318);
            this.rall_btn.Name = "rall_btn";
            this.rall_btn.Size = new System.Drawing.Size(60, 50);
            this.rall_btn.TabIndex = 5;
            this.rall_btn.Text = "<<";
            this.rall_btn.UseVisualStyleBackColor = true;
            this.rall_btn.Click += new System.EventHandler(this.rall_btn_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(264, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(296, 44);
            this.label1.TabIndex = 6;
            this.label1.Text = "List Box Change Item";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(812, 468);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rall_btn);
            this.Controls.Add(this.rse_btn);
            this.Controls.Add(this.all_btn);
            this.Controls.Add(this.se_btn);
            this.Controls.Add(this.listboxtwo);
            this.Controls.Add(this.listboxone);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listboxone;
        private System.Windows.Forms.ListBox listboxtwo;
        private System.Windows.Forms.Button se_btn;
        private System.Windows.Forms.Button all_btn;
        private System.Windows.Forms.Button rse_btn;
        private System.Windows.Forms.Button rall_btn;
        private System.Windows.Forms.Label label1;
    }
}

