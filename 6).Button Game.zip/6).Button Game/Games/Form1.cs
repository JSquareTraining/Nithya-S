﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Games
{
    public partial class form1 : Form
    {
        public form1()
        {
            InitializeComponent();
        }
       private void form1_Load(object sender, EventArgs e)
        {
        }
       private void btn1_click(object sender, EventArgs e)
       {
          if (btn1.Enabled == true)
           {
               btn1.Text = "A";
               MessageBox.Show("Select Your Pair");
               btn1.Enabled = false;
           }
              
       }
        private void btn8_click(object sender, EventArgs e)
        {
            //if (btn8.Text == "")
                if (btn2.Enabled == false && btn2.Visible == true)
                {
                    btn8.Text = "Baby";
                    MessageBox.Show("Matchable Pair");
                    btn2.Visible = false;
                    btn8.Visible = false;
                }

                else
                {
                    MessageBox.Show("Sorry");
                }   
        }

             private void btn2_Click(object sender, EventArgs e)
             {
                 if (btn2.Enabled == true)
                 {
                     btn2.Text = "B";
                     MessageBox.Show("Select Your Pair");
                     btn2.Enabled = false;
                 }
             }

             private void btn7_click(object sender, EventArgs e)
             {
               if (btn1.Enabled == false && btn1.Visible==true)
                        {
                         btn7.Text = "Apple";
                         MessageBox.Show("Matchable Pair");
                         btn1.Visible = false;
                         btn7.Visible = false;
                         }

                     else
                     {
                         MessageBox.Show("Sorry Try Again");
                     }
             }

             private void btn3_Click(object sender, EventArgs e)
             {
                 if (btn3.Enabled == true)
                 {
                     btn3.Text = "C";
                     MessageBox.Show("Select Your Pair");
                     btn3.Enabled = false;
                 }
             }

             private void btn18_Click(object sender, EventArgs e)
             {
                 if (btn3.Enabled == false && btn3.Visible == true)
                 {
                     btn18.Text = "Car";
                     MessageBox.Show("Matchable Pair");
                     btn3.Visible = false;
                     btn18.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }
             }

             private void btn4_Click(object sender, EventArgs e)
             {
                 if (btn4.Enabled == true)
                 {
                     btn4.Text = "D";
                     MessageBox.Show("Select Your Pair");
                     btn4.Enabled = false;
                 }
             }

             private void btn12_Click(object sender, EventArgs e)
             {
                 if (btn4.Enabled == false && btn12.Visible == true)
                 {
                     btn12.Text = "Dall";
                     MessageBox.Show("Matchable Pair");
                     btn4.Visible = false;
                     btn12.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }
              }

             private void btn5_Click(object sender, EventArgs e)
             {
                 if (btn5.Enabled == true)
                 {
                     btn5.Text = "E";
                     MessageBox.Show("Select Your Pair");
                     btn5.Enabled = false;
                 }

             }

             private void btn19_Click(object sender, EventArgs e)
             {
                 if (btn5.Enabled == false && btn5.Visible == true)
                 {
                     btn19.Text = "Ear";
                     MessageBox.Show("Matchable Pair");
                     btn5.Visible = false;
                     btn19.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }
             }

             private void btn6_Click(object sender, EventArgs e)
             {
                 if (btn6.Enabled == true)
                 {
                     btn6.Text = "F";
                     MessageBox.Show("Select your pair");
                     btn6.Enabled = false;
                 }

             }

             private void btn9_Click(object sender, EventArgs e)
             {
                 if (btn6.Enabled == false && btn6.Visible == true)
                 {
                     btn9.Text = "Fox";
                     MessageBox.Show("Matchable Pair");
                     btn6.Visible = false;
                     btn9.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }
             }

             private void btn11_Click(object sender, EventArgs e)
             {
                 if (btn11.Enabled == true)
                 {
                     btn11.Text = "G";
                     MessageBox.Show("Select Your Pair");
                     btn11.Enabled = false;
                 }

             }

             private void btn15_Click(object sender, EventArgs e)
             {

                 if (btn11.Enabled == false && btn11.Visible == true)
                 {
                     btn15.Text = "God";
                     MessageBox.Show("Matchable Pair");
                     btn11.Visible = false;
                     btn15.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }
             }

             private void btn16_Click(object sender, EventArgs e)
             {
                 if (btn16.Enabled == true)
                 {
                     btn16.Text = "H";
                     MessageBox.Show("Select Your Pair");
                     btn16.Enabled = false;
                 }

             }

             private void btn13_Click(object sender, EventArgs e)
             {
                 if (btn16.Enabled == false && btn16.Visible == true)
                 {
                     btn13.Text = "Hello";
                     MessageBox.Show("Matchable Pair");
                     btn13.Visible = false;
                     btn16.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }
             }

             private void btn17_Click(object sender, EventArgs e)
             {
                 if (btn21.Enabled == false && btn21.Visible == true)
                 {
                     btn17.Text = "Ink";
                     MessageBox.Show("Matchable Pair");
                     btn21.Visible = false;
                     btn17.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }
             }

             private void btn21_Click(object sender, EventArgs e)
             {
                 if (btn21.Enabled == true)
                 {
                     btn21.Text = "I";
                     MessageBox.Show("Select Your Pair");
                     btn21.Enabled = false;
                 }
             }

             private void btn10_Click(object sender, EventArgs e)
             {
                 if (btn22.Enabled == false && btn22.Visible == true)
                 {
                     btn10.Text = "Jar";
                     MessageBox.Show("Matchable Pair");
                     btn10.Visible = false;
                     btn22.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }
             }

             private void btn22_Click(object sender, EventArgs e)
             {
                 if (btn22.Enabled == true)
                 {
                     btn22.Text = "J";
                     MessageBox.Show("Select Your Pair");
                     btn22.Enabled = false;
                 }
             }

             private void btn23_Click(object sender, EventArgs e)
             {
                 if (btn23.Enabled == true)
                 {
                     btn23.Text = "K";
                     MessageBox.Show("select your pair");
                     btn23.Enabled = false;
                 }
             }

             private void btn14_Click(object sender, EventArgs e)
             {
                 if (btn23.Enabled == false && btn23.Visible == true)
                 {
                     btn14.Text = "Kight";
                     MessageBox.Show("Matchable Pair");
                     btn14.Visible = false;
                     btn23.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }

             }

             private void btn24_Click(object sender, EventArgs e)
             {
                 if (btn24.Enabled == true)
                 {
                     btn24.Text = "L";
                     MessageBox.Show("Select Your Pair");
                     btn24.Enabled = false;
                 }
             }

             private void btn20_Click(object sender, EventArgs e)
             {
                 if (btn24.Enabled == false && btn24.Visible == true)
                 {
                     btn20.Text = "Logic";
                     MessageBox.Show("Matchable Pair");
                     btn20.Visible = false;
                     btn24.Visible = false;
                 }

                 else
                 {
                     MessageBox.Show("Sorry Try Again");
                 }
             }

             private void label2_Click(object sender, EventArgs e)
             {

             }

             private void btn25_Click(object sender, EventArgs e)
             {
                 //if (btn25.Enabled == true)
                 //{
                   //  btn25.Text = "A";
                     MessageBox.Show("GAME OVER");
                     btn25.Visible =false;
                     this.Close();
                     //btn25.Enabled = false;
                 //}
             }
        
             //private void btn7_click(object sender, EventArgs e)
             //{
             //    if (btn25.Enabled == false && btn25.Visible == true)
             //    {
             //        btn7.Text = "Apple";
             //        MessageBox.Show("matchable pair");
             //        btn25.Visible = false;
             //        btn7.Visible = false;
             //    }

             //    else
             //    {
             //        MessageBox.Show("sorry");
             //    }
            // }


         




   
           }

        
    }
