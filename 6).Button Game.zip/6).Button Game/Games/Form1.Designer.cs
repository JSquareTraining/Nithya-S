﻿namespace Games
{
    partial class form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn10 = new System.Windows.Forms.Button();
            this.btn11 = new System.Windows.Forms.Button();
            this.btn12 = new System.Windows.Forms.Button();
            this.btn13 = new System.Windows.Forms.Button();
            this.btn14 = new System.Windows.Forms.Button();
            this.btn15 = new System.Windows.Forms.Button();
            this.btn16 = new System.Windows.Forms.Button();
            this.btn17 = new System.Windows.Forms.Button();
            this.btn18 = new System.Windows.Forms.Button();
            this.btn19 = new System.Windows.Forms.Button();
            this.btn20 = new System.Windows.Forms.Button();
            this.btn21 = new System.Windows.Forms.Button();
            this.btn22 = new System.Windows.Forms.Button();
            this.btn23 = new System.Windows.Forms.Button();
            this.btn24 = new System.Windows.Forms.Button();
            this.btn25 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.Khaki;
            this.btn1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(143, 78);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(50, 50);
            this.btn1.TabIndex = 0;
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.Khaki;
            this.btn2.ForeColor = System.Drawing.Color.Green;
            this.btn2.Location = new System.Drawing.Point(199, 78);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(50, 50);
            this.btn2.TabIndex = 1;
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.Khaki;
            this.btn3.Location = new System.Drawing.Point(255, 78);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(50, 50);
            this.btn3.TabIndex = 2;
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.Khaki;
            this.btn4.ForeColor = System.Drawing.Color.Green;
            this.btn4.Location = new System.Drawing.Point(311, 78);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(50, 50);
            this.btn4.TabIndex = 3;
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.Khaki;
            this.btn5.ForeColor = System.Drawing.Color.Green;
            this.btn5.Location = new System.Drawing.Point(367, 78);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(50, 50);
            this.btn5.TabIndex = 4;
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.Khaki;
            this.btn6.ForeColor = System.Drawing.Color.Green;
            this.btn6.Location = new System.Drawing.Point(143, 134);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(50, 50);
            this.btn6.TabIndex = 5;
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(199, 134);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(50, 50);
            this.btn7.TabIndex = 6;
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.btn7_click);
            // 
            // btn8
            // 
            this.btn8.ForeColor = System.Drawing.Color.Green;
            this.btn8.Location = new System.Drawing.Point(255, 134);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(50, 50);
            this.btn8.TabIndex = 7;
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.btn8_click);
            // 
            // btn9
            // 
            this.btn9.ForeColor = System.Drawing.Color.Green;
            this.btn9.Location = new System.Drawing.Point(311, 134);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(50, 50);
            this.btn9.TabIndex = 8;
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn10
            // 
            this.btn10.ForeColor = System.Drawing.Color.Green;
            this.btn10.Location = new System.Drawing.Point(367, 134);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(50, 50);
            this.btn10.TabIndex = 9;
            this.btn10.UseVisualStyleBackColor = true;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // btn11
            // 
            this.btn11.BackColor = System.Drawing.Color.Khaki;
            this.btn11.ForeColor = System.Drawing.Color.Green;
            this.btn11.Location = new System.Drawing.Point(143, 190);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(50, 50);
            this.btn11.TabIndex = 10;
            this.btn11.UseVisualStyleBackColor = false;
            this.btn11.Click += new System.EventHandler(this.btn11_Click);
            // 
            // btn12
            // 
            this.btn12.ForeColor = System.Drawing.Color.Green;
            this.btn12.Location = new System.Drawing.Point(199, 190);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(50, 50);
            this.btn12.TabIndex = 11;
            this.btn12.UseVisualStyleBackColor = true;
            this.btn12.Click += new System.EventHandler(this.btn12_Click);
            // 
            // btn13
            // 
            this.btn13.Location = new System.Drawing.Point(255, 190);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(50, 50);
            this.btn13.TabIndex = 12;
            this.btn13.UseVisualStyleBackColor = true;
            this.btn13.Click += new System.EventHandler(this.btn13_Click);
            // 
            // btn14
            // 
            this.btn14.Location = new System.Drawing.Point(311, 190);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(50, 50);
            this.btn14.TabIndex = 13;
            this.btn14.UseVisualStyleBackColor = true;
            this.btn14.Click += new System.EventHandler(this.btn14_Click);
            // 
            // btn15
            // 
            this.btn15.ForeColor = System.Drawing.Color.Green;
            this.btn15.Location = new System.Drawing.Point(367, 190);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(50, 50);
            this.btn15.TabIndex = 14;
            this.btn15.UseVisualStyleBackColor = true;
            this.btn15.Click += new System.EventHandler(this.btn15_Click);
            // 
            // btn16
            // 
            this.btn16.BackColor = System.Drawing.Color.Khaki;
            this.btn16.Location = new System.Drawing.Point(143, 246);
            this.btn16.Name = "btn16";
            this.btn16.Size = new System.Drawing.Size(50, 50);
            this.btn16.TabIndex = 15;
            this.btn16.UseVisualStyleBackColor = false;
            this.btn16.Click += new System.EventHandler(this.btn16_Click);
            // 
            // btn17
            // 
            this.btn17.ForeColor = System.Drawing.Color.Green;
            this.btn17.Location = new System.Drawing.Point(199, 246);
            this.btn17.Name = "btn17";
            this.btn17.Size = new System.Drawing.Size(50, 50);
            this.btn17.TabIndex = 16;
            this.btn17.UseVisualStyleBackColor = true;
            this.btn17.Click += new System.EventHandler(this.btn17_Click);
            // 
            // btn18
            // 
            this.btn18.Location = new System.Drawing.Point(255, 246);
            this.btn18.Name = "btn18";
            this.btn18.Size = new System.Drawing.Size(50, 50);
            this.btn18.TabIndex = 17;
            this.btn18.UseVisualStyleBackColor = true;
            this.btn18.Click += new System.EventHandler(this.btn18_Click);
            // 
            // btn19
            // 
            this.btn19.ForeColor = System.Drawing.Color.Green;
            this.btn19.Location = new System.Drawing.Point(311, 246);
            this.btn19.Name = "btn19";
            this.btn19.Size = new System.Drawing.Size(50, 50);
            this.btn19.TabIndex = 18;
            this.btn19.UseVisualStyleBackColor = true;
            this.btn19.Click += new System.EventHandler(this.btn19_Click);
            // 
            // btn20
            // 
            this.btn20.ForeColor = System.Drawing.Color.Green;
            this.btn20.Location = new System.Drawing.Point(367, 246);
            this.btn20.Name = "btn20";
            this.btn20.Size = new System.Drawing.Size(50, 50);
            this.btn20.TabIndex = 19;
            this.btn20.UseVisualStyleBackColor = true;
            this.btn20.Click += new System.EventHandler(this.btn20_Click);
            // 
            // btn21
            // 
            this.btn21.BackColor = System.Drawing.Color.Khaki;
            this.btn21.ForeColor = System.Drawing.Color.Green;
            this.btn21.Location = new System.Drawing.Point(143, 302);
            this.btn21.Name = "btn21";
            this.btn21.Size = new System.Drawing.Size(50, 50);
            this.btn21.TabIndex = 20;
            this.btn21.UseVisualStyleBackColor = false;
            this.btn21.Click += new System.EventHandler(this.btn21_Click);
            // 
            // btn22
            // 
            this.btn22.BackColor = System.Drawing.Color.Khaki;
            this.btn22.ForeColor = System.Drawing.Color.Green;
            this.btn22.Location = new System.Drawing.Point(199, 302);
            this.btn22.Name = "btn22";
            this.btn22.Size = new System.Drawing.Size(50, 50);
            this.btn22.TabIndex = 21;
            this.btn22.UseVisualStyleBackColor = false;
            this.btn22.Click += new System.EventHandler(this.btn22_Click);
            // 
            // btn23
            // 
            this.btn23.BackColor = System.Drawing.Color.Khaki;
            this.btn23.Location = new System.Drawing.Point(255, 302);
            this.btn23.Name = "btn23";
            this.btn23.Size = new System.Drawing.Size(50, 50);
            this.btn23.TabIndex = 22;
            this.btn23.UseVisualStyleBackColor = false;
            this.btn23.Click += new System.EventHandler(this.btn23_Click);
            // 
            // btn24
            // 
            this.btn24.BackColor = System.Drawing.Color.Khaki;
            this.btn24.ForeColor = System.Drawing.Color.Green;
            this.btn24.Location = new System.Drawing.Point(311, 302);
            this.btn24.Name = "btn24";
            this.btn24.Size = new System.Drawing.Size(50, 50);
            this.btn24.TabIndex = 23;
            this.btn24.UseVisualStyleBackColor = false;
            this.btn24.Click += new System.EventHandler(this.btn24_Click);
            // 
            // btn25
            // 
            this.btn25.BackColor = System.Drawing.Color.Khaki;
            this.btn25.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn25.Location = new System.Drawing.Point(367, 302);
            this.btn25.Name = "btn25";
            this.btn25.Size = new System.Drawing.Size(50, 50);
            this.btn25.TabIndex = 24;
            this.btn25.Text = "STOP";
            this.btn25.UseVisualStyleBackColor = false;
            this.btn25.Click += new System.EventHandler(this.btn25_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Khaki;
            this.button1.Location = new System.Drawing.Point(559, 134);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 25;
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(646, 134);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 40);
            this.label1.TabIndex = 26;
            this.label1.Text = "Just Click Yellow Button";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(559, 223);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 50);
            this.button2.TabIndex = 27;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(648, 237);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 22);
            this.label2.TabIndex = 28;
            this.label2.Text = "Pair Display";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(308, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(301, 24);
            this.label3.TabIndex = 29;
            this.label3.Text = "Alphabatic Games Using Buttons";
            // 
            // form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(925, 471);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btn25);
            this.Controls.Add(this.btn24);
            this.Controls.Add(this.btn23);
            this.Controls.Add(this.btn22);
            this.Controls.Add(this.btn21);
            this.Controls.Add(this.btn20);
            this.Controls.Add(this.btn19);
            this.Controls.Add(this.btn18);
            this.Controls.Add(this.btn17);
            this.Controls.Add(this.btn16);
            this.Controls.Add(this.btn15);
            this.Controls.Add(this.btn14);
            this.Controls.Add(this.btn13);
            this.Controls.Add(this.btn12);
            this.Controls.Add(this.btn11);
            this.Controls.Add(this.btn10);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.ForeColor = System.Drawing.Color.Red;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "form1";
            this.Text = "Games";
            this.Load += new System.EventHandler(this.form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn10;
        private System.Windows.Forms.Button btn11;
        private System.Windows.Forms.Button btn12;
        private System.Windows.Forms.Button btn13;
        private System.Windows.Forms.Button btn14;
        private System.Windows.Forms.Button btn15;
        private System.Windows.Forms.Button btn16;
        private System.Windows.Forms.Button btn17;
        private System.Windows.Forms.Button btn18;
        private System.Windows.Forms.Button btn19;
        private System.Windows.Forms.Button btn20;
        private System.Windows.Forms.Button btn21;
        private System.Windows.Forms.Button btn22;
        private System.Windows.Forms.Button btn23;
        private System.Windows.Forms.Button btn24;
        private System.Windows.Forms.Button btn25;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

